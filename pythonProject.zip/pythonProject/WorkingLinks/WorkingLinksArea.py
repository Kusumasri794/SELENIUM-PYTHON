from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC



class WorkinLinksAreaExample():

    def isFramePresent(self,driver, locatorval):
        listFrameXPATH = driver.find_elements(By.XPATH, locatorval)
        if(listFrameXPATH == 0):
            print("Frame not present")
            return False
        else:
            print("Frame is present")
            return True



    def outOFFrame(self,driver):
        driver.switch_to.default_content()

    def isPopUpPresent(self, driver, locatorVal):
        listElements = driver.find_elements(By.XPATH, locatorVal)
        intNumnerOFELements = len(listElements)
        if (intNumnerOFELements == 0):
            print("POP up does not exist does not exist")
            return False
        else:
            print("POP up does exist")
            return True


    def Links(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"
        # Use the OS packages environment property
        # Using the chrome driver tpo find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation
        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        # Controlling the chrome browser --> find elements in the browser and perform action
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and elenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to BBC website
        driver.get("https://www.bbc.com")

        #Dynamic wait - implicit wait and explicit wait
        # implicit wait is applied in the codes where we use find_element() or find_elements() methods
        # if the element is not found in 20 seconds, it will throw Timeout error
        driver.implicitly_wait(20)

        # Find the pop up  and click on close buttton
        # b = self.isPopUpPresentWithFrame(driver, "//*[@id='responsive-news']/body/div[10]/div/button")
        # if (b is True):  # Click if the element is found
        #     driver.find_element(By.XPATH, "//*[@id='responsive-news']/body/div[10]/div/button").click()

        # Define the explicit wait = Dynamic wait
        # explicitW = WebDriverWait(driver, 20)


        # 1. The pop-up is seen in the website and which grades out the landing page as so the text is not thrown out. POP up is not constant.
        # Switch to the frame as the the element containing the text "    News you can trust is news you can use. " is present inside a frame
        # We can switch to frame by the ID/NAME attribute preent in the html script of the frame. If ID or name attribute is not present in html script of frame , we use the address of the frame
        # Address of the frame can be these locating strategies : id, name, tagname, classname, xpath, cssSelector
        # driver.switch_to.frame("offer_ab8d34f0886f1e2c2681-0"); # By id
        # driver.switch_to.frame("offer_ab8d34f0886f1e2c2681-0");  # By name
        # Address of an element is always kept in WebElement package
        # addressFrameID = driver.find_element(By.ID, "offer_ab8d34f0886f1e2c2681-0")
        # addressFrameNAME = driver.find_element(By.NAME, "offer_ab8d34f0886f1e2c2681-0")
        # addressFrameXPATH = driver.find_element(By.XPATH, "//*[@id='offer_ab8d34f0886f1e2c2681-0']")
        # addressFrameCSSSelector = driver.find_element(By.CSS_SELECTOR, "#offer_ab8d34f0886f1e2c2681-0")
        # driver.switch_to.frame(addressFrameXPATH); #Moving focus of Selenium to the frame

        # use a validation point  - text to be present is "News you can trust is news you can use."
        # Validation with Selenium is done using EXPLICIT wait - dynamic wait
        # Explicit wait is for a specific element
        # until these condtions are met --> https://www.selenium.dev/selenium/docs/api/py/webdriver_support/selenium.webdriver.support.expected_conditions.html?highlight=expectedconditions

        # explicitW.until(EC.text_to_be_present_in_element((By.XPATH, "//*[@id='template-container']/div/div[2]/div/div[2]"), "News you can trust is news you can use."))
        # print("Text is present")

        #Move the focus from frame to pop-up
        # driver.switch_to.default_content()

        # Close the pop up
        # driver.find_element(By.XPATH, "//*[@id='responsive-news']/body/div[10]/div/button").click()

        # Find the address of the area - LATEST BUSINESS NEW
        # Address is kept in WebElement
        addressAreaLatestBusinessNews = driver.find_element(By.CSS_SELECTOR, "#page > section.module.module--collapse-images.module--collapse-images.module--highlight.module--editors-picks > div > div > div.most-popular")
        # Number of links in the area - Latest business News
        listLinksArea = addressAreaLatestBusinessNews.find_elements(By.TAG_NAME, "a")
        numLinks = len(listLinksArea)
        print("The number of links in Latest Business News area are",numLinks)

        # To click on the links of the area, get the title of the link page and come back to BBC Website
        # All links in the has to be clicked and all links title should be printed , until all links are processed.
        # variable "x" defines the index number of the items in the list
        x = 0
        while(x<numLinks):
            time.sleep(4)
            # Recreating the cache memory
            addressAreaLatestBusinessNews = driver.find_element(By.CSS_SELECTOR,
                                                                "#page > section.module.module--collapse-images.module--collapse-images.module--highlight.module--editors-picks > div > div > div.most-popular")
            listLinksArea = addressAreaLatestBusinessNews.find_elements(By.TAG_NAME, "a")

            time.sleep(4)

            # Click on the link with x= 0
            listLinksArea[x].click()

            time.sleep(4)


            # Find the pop up  and click on close buttton
            # b =  self.isPopUpPresent(driver, "//*[@id='responsive-news']/body/div[10]/div/button")
            # if (b is True):  # Click if the element is found
            #     driver.find_element(By.XPATH, "//*[@id='responsive-news']/body/div[10]/div/button").click()


            # Get the title of the link page
            titlePage = driver.title
            print("The title of the link with index number",x, "is",titlePage)

            time.sleep(4)

            # Coming back to landing page
            driver.get("https://www.bbc.com")


            time.sleep(4)

            x = x+1


        time.sleep(3)

        # Close the app
        driver.quit()


w = WorkinLinksAreaExample()
w.Links()


"""
1.It gets the title of first link and then execution of script stops
2. Shows StaleElementReferenceException
3. Please do not handle the excepotion using TRY EXCEPT block
4. StaleElementReferenceException - comes because of loss of cache memory
Explaination:
a) At line 60 we are landing to www.bbc.com
b) In the landing page, we are creating address of the area - line 105 - cache memory at landing page
c) In the landing page , we are getting also number of links in the area - line 107 - cache memory at landing page
d) At line 119, we are moving out from landing page to the links pages - here we are loosing the cache memory
e) After coming bacl to BBC website at line 136, recreate the cache memory
"""
import unittest


class TestClass3(unittest.TestCase):


    # Will run once before the class file
    # Set up fixture at class level
    @classmethod
    def setUpClass(self):
        print("*" * 20)
        print("Open the browser")
        print("*" * 20)

    # Setup fixture for test case level
    def setUp(self):
        print("*"*20)
        print("Navigate to Gmail application")
        print("*" * 20)

    # TearDown fixture for test case level
    def tearDown(self):
        print("*" * 20)
        print("Logout from Gmail")
        print("*" * 20)

    #TEst Case 1
    def test_methodA(self):
        print("Login to gmail")
    #TestCase 2
    def test_methodB(self):
        print("Login and sending email")

    # Will run once after the class file
    # Tear Down up fixture at class level
    @classmethod
    def tearDownClass(self):
        print("*" * 20)
        print("Closing the browser")
        print("*" * 20)


"""
Open the browser - class level fixture - setup
Navigate to Gmail application - Test CAse level fixture - setup
Login to gmail - Test case 1
Logout from Gmail - Test CAse level fixture - teardown
Navigate to Gmail application - Test CAse level fixture - setup
Login and sending email - test case 2
Logout from Gmail = Test CAse level fixture - teardown
Closing the browser - class level fixture - teardown
"""

# We need to create an object
if __name__ == '__main__':
    unittest.main(verbosity=2)
import pytest

# As the set up file for test case method level

@pytest.fixture()
def SetUp():
    print("*"*10)
    print("This will run before the test case")
    yield
    print("*" * 10)
    print("This will run after the test case")


# py.test pyTestPackage1/test_fixture_class2.py
# py.test -v -s pyTestPackage1/test_fixture_class2.py

def test_methodA():
    print("Running test case test_methodA of test_fixture_class2 python file/module")
def test_methodB():
    print("Running test case test_methodB of test_fixture_class2 python file/module")

import pytest

# Package level running -->  py.test test_demo_class1.py
# To print the body of the test case method: py.test -v -s test_demo_class1.py

# Run from Project level -->py.test pyTestPackage1/test_demo_class1.py
# To print the body of the test case method: py.test -v -s pyTestPackage1/test_demo_class1.py


def test_methodA():
    print("Running test case test_methodA of test_demo_class1 python file/module")
def test_methodB():
    print("Running test case test_methodB of test_demo_class1 python file/module")

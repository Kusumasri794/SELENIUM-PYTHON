# is used for single line commenting
"""
Multi Line commenting is to comment multiple lines
"""

# Call the function - interpretation working behaviour - from left to right followed by top to down
# ModulFunction()

# Creating a functon is always outside of class body
# Function withour parameter
def ModulFunction():
    a1 = 90
    b1 = 100
    c1 = a1+b1
    print(c1)

# Call the function
ModulFunction() # 190

def ModulFunction():
    a1 = "Hi!"
    b1 = "Learning Python"
    c1 = a1+b1
    print(c1)
    a1 = 90
    #c1= a1+b1  # Type error - strings cannot be concatenated (combined with number formats. We need to convert number formats to string using the str() function
    c1 = str(a1)+b1
    print(c1)

# Note - Functions name can be duplicated
# Note the local variable name can be duplicated.
# Note In other languages we can duplicate function name with different signatures and that is called as METHOD OVERLOADING.
# Note: In python we can duplicate function name and so there is no concept of method overloading /static polymorphism/compile time pplymorphism

# Call the ModulFunction()
ModulFunction()  # Hi!Learningf Python



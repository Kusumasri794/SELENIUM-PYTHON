import math



# using the issqrt() function of math module
# Build in modules  --> https://docs.python.org/3/py-modindex.html
print(math.isqrt(100))

# Use the exponential function
print(math.exp(100))

from math import exp
print(exp(50))


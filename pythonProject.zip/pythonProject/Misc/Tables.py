from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains

class Tables():

    def WorkingTables(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"

        # Use the OS packages environment property
        # Using the chrome driver to find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation

        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and selenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to draggable part
        driver.get("https://money.rediff.com/gainers/bse/daily/groupa?src=gain_lose")

        time.sleep(10)

        print("*" * 40)
        # xpath of first row first column of body of table - //*[@id="leftcontainer"]/table/tbody/tr[1]/td[1]/a
        print("Data from first row first column of body of table")
        firstrowFirstColumBodyData = driver.find_element(By.XPATH, "//div[@id='leftcontainer']/table/tbody/tr[1]/td[1]/a").text
        print(firstrowFirstColumBodyData)


        print("*" * 40)
        print("Data from all rows of the first column of the body of the table")
        # To get data from all rows of the first column of the body of the table
        # Manipulate the xpath for first row, first column, body of the table
        # //*[@id='leftcontainer']/table/tbody/tr/td[1]/a
        # allrowFirstColumBodyData = driver.find_element(By.XPATH,"//*[@id='leftcontainer']/table/tbody/tr/td[1]/a").text
        # print(allrowFirstColumBodyData)
        listVal1 = driver.find_elements(By.XPATH, "//div[@id='leftcontainer']/table/tbody/tr/td[1]/a")
        numRowsBody = len(listVal1)
        print("Number of rows in the body are",numRowsBody)
        x = 0
        while(x<len(listVal1)):
            print(listVal1[x].text)
            x=x+1

        print("*" * 40)
        print("Data from all rows of the first column of the body of the table")
        # Css Selector of first row , first column of the body --> #leftcontainer > table > tbody > tr:nth-child(1) > td:nth-child(1) > a
        # Css Selector of second row , first column of the body -->#leftcontainer > table > tbody > tr > td:nth-child(1) > a
        # manipulate --> leftcontainer > table > tbody > tr > td:nth - child(1) > a
        # #leftcontainer > table > tbody > tr:nth-child(1) > td:nth-child(1) > a
        # Css Selector of first row , first column of the body -->#leftcontainer>table>tbody>tr:nth-child(1)>td:nth-child(1)>a
        listVal2 = driver.find_elements(By.CSS_SELECTOR, "#leftcontainer>table>tbody>tr>td:nth-child(1)>a")
        numRowsBody = len(listVal2)
        print("Number of rows in the body are", numRowsBody)
        x = 0
        while (x < len(listVal2)):
            print(listVal1[x].text)
            x = x + 1


        print("*" * 40)
        #  #leftcontainer>table>tbody>
        print("All Columns and all rows of the body of the table: ")
        Val2 = driver.find_element(By.CSS_SELECTOR, "#leftcontainer>table>tbody").text
        print(Val2)





        print("*" * 40)
        # //*[@id="leftcontainer"]/table/tbody/tr[1]/td[1]/a
        print("All Columns and all rows of the body of the table: ")
        val3 =  driver.find_element(By.XPATH, "//*[@id='leftcontainer']/table/tbody")
        print(Val2)

        # Close the app
        driver.quit()

t = Tables()
t.WorkingTables()
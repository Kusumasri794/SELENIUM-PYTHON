from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains

class Simulation():

    # Working with dynamic attribute values and working with other web elements

    def JQueryUI(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"

        # Use the OS packages environment property
        # Using the chrome driver to find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation

        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and selenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to draggable part
        driver.get("https://jqueryui.com/draggable/")

        # Dynamic wait - implicit wait and explicit wait
        driver.implicitly_wait(20)

        # Define the explicit wait = Dynamic wait
        explicitW = WebDriverWait(driver, 20)

        # We cannot switch to the frame by class attribute value - id attribute value of name attribute value
        # We can switch to the frame by the address of the frame (WebElement)
        # We can also switch to the frame by index number
        addressFrame = driver.find_element(By.XPATH, "//*[@id='content']/iframe")
        driver.switch_to.frame(addressFrame)

        time.sleep(4)

        # ActionChains class does simulation of mouse movements and keystrokes
        # When the script is run, avoid touching mouse or keypad,; may create problem with simulation
        # ActionChains class always finds element at the middle of it
        # Please use the PERFORM() method to perform the simulation - compulsory
        addressElementDrag = driver.find_element(By.XPATH, "//*[@id='draggable']")
        act = ActionChains(driver)
        act.drag_and_drop_by_offset(addressElementDrag, 50, 60)
        act.perform()

        # Switch to main page from frame in order to click on DROPPABLE link
        driver.switch_to.default_content()

        # Click on droppable link - using the text() function in XPATH
        driver.find_element(By.XPATH, "//a[text() = 'Droppable']").click()

        time.sleep(5)

        # Switch to the frame to work with elements of drag and drop
        lisFrames = driver.find_elements(By.TAG_NAME, "iframe")
        # Number of frames in the webpage
        numFrames = len(lisFrames)
        print("Number of frames in the web page are",numFrames)
        # Switch to frame by index number
        # driver.switch_to.frame(0)
        x = 0 # index nuber variable
        expectedSRC = "https://jqueryui.com/resources/demos/droppable/default.html"
        actualSRC = driver.find_element(By.XPATH, "//*[@id='content']/iframe").get_attribute("src")  # //*[@id="content"]/iframe
        print(actualSRC) # https://jqueryui.com/resources/demos/droppable/default.html
        while(x<numFrames):
            # src = https://jqueryui.com/resources/demos/droppable/default.html
            if(actualSRC == expectedSRC):
                driver.switch_to.frame(x)
            x = x+1


        time.sleep(4)

        # Drag and drop the element
        addressSource = driver.find_element(By.XPATH, "//*[@id='draggable']") #//*[@id="draggable"]
        addressDestination = driver.find_element(By.XPATH,"//*[@id='droppable']")
        act = ActionChains(driver)
        act.drag_and_drop(addressSource,addressDestination)
        act.perform()

        time.sleep(5)

        # Close the app
        driver.quit()


s = Simulation()
s.JQueryUI()
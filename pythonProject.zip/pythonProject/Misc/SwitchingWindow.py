from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains




class Screenshot():

    def takingScreenshot(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"

        # Use the OS packages environment property
        # Using the chrome driver to find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation

        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and selenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to draggable part
        driver.get("https://news.google.com/")



        # Dynamic wait - implicit wait and explicit wait
        driver.implicitly_wait(20)

        # Define the explicit wait = Dynamic wait
        explicitW = WebDriverWait(driver, 20)

        # Get the title of the landing page
        titleLandingPage = driver.title
        print("Title of the landing page is", titleLandingPage)

        # Get the session id of the current page/landing page/page opened by Selenium
        sessionIDLandingPage = driver.current_window_handle
        print("Session id of the landing page", sessionIDLandingPage)

        # Click on the first main news
        driver.find_element(By.CSS_SELECTOR,
                            "#yDmH0d > c-wiz.zQTmif.SSPGKf.ZYcfVd > div > div.FVeGwb.CVnAc.Haq2Hf.bWfURe > div.ajwQHc.BL5WZb.RELBvb.zLBZs > div > main > c-wiz > div.lBwEZb.BL5WZb.xP6mwf > div:nth-child(1) > div.NiLAwe.mi8Lec.gAl5If.sMVRZe.Oc0wGc.R7GTQ.keNKEd.j7vNaf.nID9nc > div > div > article > a").click()

        time.sleep(5)



        # Find the session ID of tabbed window/new window/pop up
        sessionIDTabbedWindow = driver.window_handles[1]  # The session id of tabbed window
        print("Session id of the tabbed window page", sessionIDTabbedWindow)

        # Switch the focus of selenium from main window to tabbed window
        driver.switch_to.window(sessionIDTabbedWindow)

        # Get the title of the tabbed window opened by clicking on the link
        titleLinkPage = driver.title
        print("Title of the tabbed window is", titleLinkPage)

        # Move focus back to main window
        driver.switch_to.window(sessionIDLandingPage)


        # Get the title of the main window
        titleLandingPage = driver.title
        print("Title of the main window is", titleLandingPage)

        time.sleep(5)

        # Close the app
        # Close() method is going to close the window in focus only
        # driver.close()
        # quit() - it closes all windows of the browser and kiils the objects
        driver.quit()




sw= Screenshot()
sw.takingScreenshot()
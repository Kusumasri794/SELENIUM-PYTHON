# FileName - test_selenium_grid_firefox_chrome.py

# Import the 'modules' that are required for the execution

import pytest
# import pytest_html
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from time import sleep


# Fixture for Firefox
@pytest.fixture(params=["chrome", "firefox"], scope="class")
def driver_init(request):
    if request.param == "firefox":
        # Local webdriver implementation
        # web_driver = webdriver.Firefox()

        # Remote WebDriver implementation
        web_driver = webdriver.Remote(
            command_executor='http://192.168.0.194:4444/wd/hub',
            desired_capabilities={'browserName': 'firefox'})
    if request.param == "chrome":
        # Local webdriver implementation
        # web_driver = webdriver.Chrome()
        # Remote WebDriver implementation
        web_driver = webdriver.Remote(
            command_executor='http://192.168.0.194:4444/wd/hub',
            desired_capabilities={'browserName': 'chrome','javascriptEnabled': True})

        request.cls.driver = web_driver
    yield
    sleep(5)
    web_driver.close()


@pytest.mark.usefixtures("driver_init")
class BasicTest:
    # The pass statement is used as a placeholder for future code. When the pass
    # statement is executed, nothing happens, but you avoid getting an error when
    # empty code is not allowed. Empty code is not allowed in loops, function definitions,
    # class definitions, or in if statements.
    pass


class Test_URL(BasicTest):
    def test_open_url(self):
        self.driver.maximize_window()
        self.driver.get("https://www.google.com/")
        print(self.driver.title)

        sleep(5)
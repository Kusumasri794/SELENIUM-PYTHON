from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.action_chains import ActionChains
import sys, string, os


class UploadFiles():

    # Working with dynamic attribute values and working with other web elements

    def Upload(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"

        # Use the OS packages environment property
        # Using the chrome driver to find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation

        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and selenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to Google Search Website
        driver.get("file:///C:/Users/lenovo/Desktop/Upload.html")

        # Click on Upload button
        # driver.find_element(By.ID, "Hi1").click()
        act = ActionChains(driver)
        eleAddress = driver.find_element(By.ID, "Hi1")
        act.move_to_element(eleAddress).click()
        act.perform()

        time.sleep(10)

        # Integrate the (autoit) executable with Python
        # Install autoiT - https://www.autoitscript.com/site/autoit/downloads/
        # Install Script Editor --> https://www.autoitscript.com/site/autoit-script-editor/downloads/
        os.system("C:\\Users\\lenovo\\Desktop\\autoit\\browser.exe")

        time.sleep(10)

        #Close the app
        driver.quit()


c= UploadFiles()
c.Upload()
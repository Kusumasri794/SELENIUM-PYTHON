from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.alert import Alert


class DynamicValues():

    # Working with dynamic attribute values and working with other web elements

    def RediffmailAccountCreation(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"

        # Use the OS packages environment property
        # Using the chrome driver to find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation

        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and selenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to Google Search Website
        driver.get("https://register.rediff.com/register/register.php?FormName=user_details")

        # Dynamic wait - implicit wait and explicit wait
        driver.implicitly_wait(20)

        # Define the explicit wait = Dynamic wait
        explicitW = WebDriverWait(driver, 20)

        # Hightlight the FULL NAME edit box element - javascript language.
        # In selenium we have a method called as execute_script("Javascript command")
        # In selenium we have a method called as execute_aync_script("Javascript async command")
        # If the html script of the element contains ID attribute, border highlighting --> document.getElementById('email').style.border = '2px solid red'
        # For elements not having ID attribute, border highlighter --> arguments[0].style.border='2px solid red', Webelement
        # For background highlighting --> arguments[0].style.background = 'red'
        addressFullname = driver.find_element(By.XPATH, "//input[contains(@name, 'name')]")
        driver.execute_script("arguments[0].style.border='4px solid red'", addressFullname)

        time.sleep(2)

        # Type on the FULL NAME edit box
        # driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[3]/td[3]/input").send_keys("Kaushik Mukherjee")
        # NO SUCH ELEMENT EXCEPTION as name value is dynamic - name value at runtime --> nameffbc3cbe,name7c759df7
        # driver.find_element(By.XPATH, "//input[@name = 'namebd47fa85']").send_keys("Kaushik Mukherjee")

        # To tackle it we can use XPATH'S function - starts-with, contains
        # driver.find_element(By.XPATH, "//input[starts-with(@name, 'name')]").send_keys("Kaushik Mukherjee")
        # driver.find_element(By.XPATH, "//input[contains(@name, 'name')]").send_keys("Kaushik Mukherjee")
        # To tackle it we can use CSSSELECTOR'S regular expression - *, $, ^
        # driver.find_element(By.CSS_SELECTOR, "input[name^='name']").send_keys("Kaushik Mukherjee")
        driver.find_element(By.CSS_SELECTOR, "input[name*='name']").send_keys("Kaushik Mukherjee")

        # Type on "Choose a Rediffmail ID" edit box - name attribute - loginbd47fa85
        driver.find_element(By.XPATH, "//input[starts-with(@name, 'login')]").send_keys("testautomate")

        # Click on the "Check availability" button - name attribute  - btnchkavailbd47fa85
        driver.find_element(By.XPATH, "//input[starts-with(@name, 'btnchkavail')]").click()

        # To verification if TEXT "Yippie! The ID you've chosen is available." is present
        expectedText = "Yippie! The ID you've chosen is available."
        actualText = driver.find_element(By.XPATH, "//*[@id='check_availability']/font/b").text
        print("Actual Text is", actualText)
        if(actualText == expectedText):
            print("Text is present")

        # To validate if TEXT "Yippie! The ID you've chosen is available." is present
        explicitW.until(EC.text_to_be_present_in_element((By.XPATH, "//*[@id='check_availability']/font/b"),"Yippie! The ID you've chosen is available."))
        print("Text is present")

        # Type in the password edit box - name atribute - passwda04ba649
        driver.find_element(By.XPATH, "//input[starts-with(@name,'passwd')]").send_keys("test@1234")

        # Type in the Retype password edit box - name atribute - confirm_passwda04ba649
        driver.find_element(By.XPATH, "//input[starts-with(@name,'confirm_passwd')]").send_keys("test@1234")

        # To check if the check box is ticked /check
        # is_selected() can be used to check if checkbox or radio button is selected
        b1 = driver.find_element(By.XPATH, "//input[starts-with(@name,'chk_altemail')]").is_selected()
        print("Is the checkbox checked?",b1) # False

        # Click on the checkbox "click on alternate email id" - name attribute - chk_altemaila04ba649
        driver.find_element(By.XPATH, "//input[starts-with(@name,'chk_altemail')]").click()

        # is_selected() can be used to check if checkbox or radio button is selected
        b1 = driver.find_element(By.XPATH, "//input[starts-with(@name,'chk_altemail')]").is_selected()
        print("Is the checkbox checked?", b1) # True

        # Drop down created with SELECT tag
        # If the drop down is created with SELECT tag , we need to use the select class - hintqa04ba649
        addressSecurityQuestionDropDown= driver.find_element(By.CSS_SELECTOR, "#div_hintQS > table > tbody > tr:nth-child(2) > td:nth-child(3) > select")
        s1 = Select(addressSecurityQuestionDropDown)
        # Find all options
        listOptions = s1.options
        x= 0
        while(x<len(listOptions)):
            print(listOptions[x].text)
            x = x+1

        # Select the option "What is your favourite pass-time?"
        # s1.select_by_index(2)
        # s1.select_by_value("What is your favourite pass-time?")
        s1.select_by_visible_text("What is your favourite pass-time?")

        # Type on the Select an danswer edit box - hinta307804d9
        driver.find_element(By.XPATH, "//input[starts-with(@name, 'hinta')]").send_keys("Cricket")

        # Type on Mother's maiden name - mothername307804d9
        driver.find_element(By.XPATH, "//input[contains(@name, 'mothername')]").send_keys("Shalini")

        # Choose the option of UNITED Kingdom from mobile number drop down - no created with SLEECT TAG
        #1)Click on the drop down
        driver.find_element(By.XPATH, "//*[@id='div_mob']/table/tbody/tr/td[3]/div[2]").click()
        #2 To click on the option  - UNITED KINGDON
        driver.find_element(By.XPATH, "//*[@id='country_id']/ul/li[3]").click()

        # To type on the mobile number edit box - mobno307804d9
        driver.find_element_by_xpath("//input[starts-with(@name, 'mobno')]").send_keys("12345")

        # Choose the option from DAY drop down - DOB_Day307804d9 - Select tag is used - 4th day selected
        addressDay = driver.find_element(By.XPATH, "//select[starts-with(@name, 'DOB_Day')]");
        s1 = Select(addressDay)
        s1.select_by_value("04")

        # Choose the option from MONTH drop down - DOB_Month307804d9 - Select tag is used - March is selected
        addressMonth = driver.find_element(By.XPATH, "//select[starts-with(@name, 'DOB_Month')]");
        s1 = Select(addressMonth)
        s1.select_by_visible_text("MAR")

        # Choose the option from YEAR drop down - DOB_Year307804d9 - Select tag is used - 2022 Selected
        addressYear = driver.find_element(By.XPATH, "//select[starts-with(@name, 'DOB_Year')]");
        s1 = Select(addressYear)
        s1.select_by_index(1)

        # Working with Radio button
        # Want to check which radio button is selected by default
        addressAreaContainingRadioButtons = driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[24]/td[3]")
        listRadioButtons = addressAreaContainingRadioButtons.find_elements(By.TAG_NAME, "input")
        numRadioButtons = len(listRadioButtons)
        print("Number of radio buttons:",numRadioButtons)
        listRadio = addressAreaContainingRadioButtons.find_elements(By.XPATH, "//input[@type = 'radio']")
        numRadio = len(listRadio)
        print("Number of radio buttons:", numRadio)
        x = 0
        while(x<numRadio):
            # There is no closing tag for input - so no text will be printed
            # textRadio = listRadio[x].text
            atrributeVal = listRadio[x].get_attribute("value")
            b = listRadio[x].is_selected()
            print(atrributeVal, "--", b)
            x = x+1

        #Choose the FEMALE radio button
        driver.find_element(By.CSS_SELECTOR, "#tblcrtac > tbody > tr:nth-child(25) > td:nth-child(3) > input[type=radio]:nth-child(2)").click()
        # To check which radio button is selected?
        x = 0
        while (x < numRadio):
            # There is no closing tag for input - so no text will be printed
            # textRadio = listRadio[x].text
            atrributeVal = listRadio[x].get_attribute("value")
            b = listRadio[x].is_selected()
            print(atrributeVal, "--", b)
            x = x + 1

        #Static Wait
        time.sleep(4)

        # Working with Captcha
        # expectedSRCAttributeVal = "https://register.rediff.com/register/tb135/tb_getimage.php?uid=1649391884&start=JTNFJTI1"
        actualSRCAttributeVal = driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[30]/td[2]/img").get_attribute("src")
        print(actualSRCAttributeVal)
        # Find if a substring is present
        if actualSRCAttributeVal.find("https://register.rediff.com/register/tb135") == -1:
            print("Not Present")
        else:
            print("Found 'https://register.rediff.com/register/tb135' in the string.")
            # driver.execute_script("window.prompt(\"Please enter the captcha\", \"ABCD1\")")
            driver.execute_script("window.alert(\"Hello! Captcha Present!\");")
            alert = Alert(driver)
            valtring = alert.text
            print(valtring)
            # In ordeer to read the text from edit box of Javascript prompt, use Sikuli
            # Sikuli supoorts JYTHON, not plain Python
            # Sikuli supoorts Python 2.7
            # So Workaround will be to have java file created with Sikuli codes
            # And then call the Java class file from Python in Selenium Script

        time.sleep(30)
        # Close the app
        driver.quit()

rd = DynamicValues()
rd.RediffmailAccountCreation()
from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By



# Function to find the element - Google Search Edit box
def isELementPresent(driver,locatorVal):
    listElements = driver.find_elements(By.NAME, locatorVal)
    intNumnerOFELements = len(listElements)
    print(intNumnerOFELements)
    if(intNumnerOFELements == 0):
        print("Elements does not exist")
        return False
    else:
        print("Elements does exist")
        return True

class ChromeBrowser():
    
    def GoogleSearch(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"
        # Use the OS packages environment property
        # Using the chrome driver tpo find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation
        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        #Controlling the chrome browser --> find elements in the browser and perform action
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and elenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # To set up the window size
        # Window Handle is the session id of the browser window
        #driver.set_window_size(width, height, windowHandlke)

        # Navigate to Google Search Website
        # If protocol is not given , will throw error
        driver.get("https://www.google.com/");

        # Find the element and click on it
        b = isELementPresent(driver,"q")
        if(b is True): # Click if the element is found
            driver.find_element(By.NAME, "q").send_keys("Selenium")


        # Initiate a process to wait for sometime and then close - time package
        time.sleep(5)

        #Close the webbrowser - use the quit() method
        driver.quit()




# Create an object of ChromeBrowser class
ch = ChromeBrowser()
ch.GoogleSearch()





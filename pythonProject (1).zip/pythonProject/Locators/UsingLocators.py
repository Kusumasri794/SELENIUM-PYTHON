from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class Locators():

    def GoogleSearch(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"

        # Use the OS packages environment property
        # Using the chrome driver to find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation

        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and selenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to Google Search Website
        driver.get("https://www.google.com/")

        # Dynamic wait - implicit wait and explicit wait
        driver.implicitly_wait(20)

        # Define the explicit wait = Dynamic wait
        explicitW = WebDriverWait(driver, 20)

        # validation point for Google image to be present
        explicitW.until(EC.title_is("Google"))
        explicitW.until(EC.title_contains("ogle"))

        # VALIDATION THAT THE TEXT GMAIL IS PRESENT IN GMAIL LINK
        explicitW.until(
            EC.text_to_be_present_in_element((By.LINK_TEXT, "Gmail"),
                                             "Gmail"))

        # Locating strategies which can be applied to Google Edit box
        # Edit box has COMPOUND CLASS VALUE  -compound class value is not supported by class name locating strategy
        # Compound class values are supported by XPATH and CSSSELECTOR
        # Name locator can be used as name attribute is een in HTML script
        # driver.find_element(By.NAME, "q").send_keys("Selenium Grid")
        # Tagname locator - Either the tag is the only tag or this input tag is the first from top of DOM
        # driver.find_element(By.TAG_NAME, "input").send_keys("Selenium Grid")
        # using XPATh - inspect element
        # driver.find_element(By.XPATH, "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input").send_keys("Selenium Grid")
        #USe customised XPATh - using compumnd class value
        # driver.find_element(By.XPATH,"//*[@class = 'gLFyf gsfi']" ).send_keys("Selenium Grid")
        # USe customised XPATh - using compumnd class value
        # driver.find_element(By.XPATH, "//input[@class = 'gLFyf gsfi']").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//input[@name = 'q']").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//input[@title = 'Search']").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//div[@class='a4bIc']/input").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//div[@class='a4bIc']/input[1]").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//div[@class = 'SDkEP']/div[2]/input").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//div[@class = 'SDkEP']/div[2]/input[1]").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//div[@class = 'RNNXgb']/div/div[2]/input").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH, "//div[@class = 'RNNXgb']/div[1]/div[2]/input[1]").send_keys("Selenium Grid")
        #Using AND operator
        # driver.find_element(By.XPATH, "//div[@jscontroller='cnjECf' and @class = 'A8SBwf']/div/div/div[2]/input").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH,"//div[@jscontroller='cnjECf' and @class = 'A8SBwf']/div[1]/div[1]/div[2]/input[1]").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH,"//div[@jscontroller='cnjECf' and @class = 'A8SBwf']/div[@class = 'RNNXgb']/div[@class = 'SDkEP']/div[@class = 'a4bIc']/input[@name = 'q']").send_keys("Selenium Grid")
        # using OR operator
        # driver.find_element(By.XPATH,"//div[@jscontroller='cnjECf' or @class = 'A8SBwf']/div/div/div[2]/input").send_keys("Selenium Grid")
        # driver.find_element(By.XPATH,"//div[@jscontroller = 'HGv0mf']/div[3]/form[1]/div/div[1]/div[1]/div[1]/div[2]/input[1]").send_keys("Selenium Grid")
        # Customised Full Xpath  or Absolute Xpath
        driver.find_element(By.XPATH,"html/body[1]/div[1]/div[3]/form[1]/div/div[1]/div[1]/div[1]/div[2]/input[1]").send_keys("Selenium Grid")

        # Locating strategies which can be applied to Google Search Button
        # Use the class name locator
        # Two ways to click on button : click(), submit()
        # click() method  - when button is not part of form tag
        # submit() method when button are part of form tag
        # driver.find_element(By.CLASS_NAME, "gNO89b").submit()
        # driver.find_element(By.NAME, "btnK").submit()
        # Get the xpath from inspect element
        # driver.find_element(By.XPATH, "html / body / div[1] / div[3] / form / div[1] / div[1] / div[3] / center / input[1]").submit()
        # Get the CssSelector from inspect element
        # driver.find_element(By.CSS_SELECTOR, "body > div.L3eUgb > div.o3j99.ikrT4e.om7nvf > form > div:nth-child(1) > div.A8SBwf > div.FPdoLc.lJ9FBc > center > input.gNO89b").submit()
        # Customoisation of CSS SELECTOR
        # driver.find_element(By.CSS_SELECTOR, "input.gNO89b").submit()
        # driver.find_element(By.CSS_SELECTOR, " *[class = 'gNO89b']").submit()
        # driver.find_element(By.CSS_SELECTOR, "input[class = 'gNO89b']").submit()
        # driver.find_element(By.CSS_SELECTOR, "input[value = 'Google Search']").submit()
        # driver.find_element(By.CSS_SELECTOR, "input[name = 'q']").submit()
        # Compound class value with Css Selector
        # driver.find_element(By.CSS_SELECTOR, "div[class = 'FPdoLc lJ9FBc']>center:nth-child(1)>input:nth-child(1)").submit()
        # driver.find_element(By.CSS_SELECTOR, "div[class = 'FPdoLc lJ9FBc'] center:nth-child(1) input:nth-child(1)").submit()
        # driver.find_element(By.CSS_SELECTOR, "div.FPdoLc lJ9FBc>center:nth-child(1)>input:nth-child(1)").submit()
        # driver.find_element(By.CSS_SELECTOR, "div.FPdoLc>center:nth-child(1)>input:nth-child(1)").submit()
        # driver.find_element(By.CSS_SELECTOR, "div[jscontroller = 'cnjECf']>div:nth-child(5)>center:nth-child(1)>input:nth-child(1)").submit()
        # driver.find_element(By.CSS_SELECTOR, "div[jscontroller = 'HGv0mf']>div:nth-child(3)>form:nth-child(3)>div:nth-child(1)>div:nth-child(1)>div:nth-child(5)>center:nth-child(1)>input:nth-child(1)").submit()
        # Full customised CssSelector
        driver.find_element(By.CSS_SELECTOR, "html>body:nth-child(2)>div:nth-child(2)>div:nth-child(3)>form:nth-child(3)>div:nth-child(1)>div:nth-child(1)>div:nth-child(5)>center:nth-child(1)>input:nth-child(1)").submit()




        time.sleep(2)

        # Click on the I AM FEELING LUCKY button with TAGNAME - Selenium lost focus
        # driver.find_element(By.TAG_NAME, "input").click()

        time.sleep(2)

        # Close the app
        driver.quit()


l  = Locators()
l.GoogleSearch()


import pytest

# USe the decorator to make it as Test Fixture for Set up and tear down
# Fixture to run before the test case level and after the test case level
@pytest.fixture()
def SetUp():
    print("Run before each test method")
    yield
    print("Run after each test method")


# Fixture to run before the module or after the module
# The argument browser will be defined in the perminal
# That argument has tobe picked up by conftest.py file
# Based on the argument values defined in the termimal , ONETIMESETUP fixture will react
@pytest.fixture(scope="session")
def OneTimeSetUp(browser):
    print("Run one time before the sesison")
    if browser == "firefox":
        print("Open the firefox browser")
    else:
        print("Open the Chrome browser")
    yield
    print("Run one time after the session")
    if browser == "firefox":
        print("Close the firefox browser")
    else:
        print("Close the Chrome browser")

# To add argument option--> the option/argument will be added. The argument is "browser".
# in this method, we can declare what arguments/options we want to add.
# We can add more than one argument and these argument can be passed in command line prompt.
def pytest_addoption(parser):
    # First option for browser
    parser.addoption("--browser")
    # Second option for osType
    parser.addoption("--osType", help = "Type of Operating System")

# Then we need to get the value of the argument . If the value of the argument "browser" is "firefox", this value has to be returned so that the conftest  understand it.
# Based on the argument , create a fixture
# Read these fixtures inside another fixture  -  will read it in OneTimeSetUp fixture which is scoped at session level
# Define the same scope as defined for ONE TIME SETUP fixture
@pytest.fixture(scope = "session")
def browser(request):
    # Return the value of the option called browser so that pytest understands it
    return request.config.getoption("--browser")

# Read these fixtures inside another fixture  -  will read it in OneTimeSetUp fixture which is scoped at session level
# Define the same scope as defined for ONE TIME SETUP fixture
@pytest.fixture(scope = "session")
def osType(request):
    # Return the value of the option called osType so that pytest understands it
    return request.config.getoption("--osType")
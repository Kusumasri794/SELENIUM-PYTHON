import pytest


@pytest.fixture()
def SetUp():
    print("Will run before the conftest test case methods")
    yield
    print("Will run after the conftest test case methods")

# Assume that both class files test_order_class1.py and test_order_class2.py have same class level set up and tear down process
# Scope can be module, session, class
# Hierarchy of scope: Session> module > class

@pytest.fixture(scope="module")
def OneTimeSetUp():
    print("Run one time before the module")
    yield
    print("Run one time after the module")
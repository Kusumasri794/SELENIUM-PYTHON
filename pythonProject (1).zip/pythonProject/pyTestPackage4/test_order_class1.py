import pytest

# Interpretation happens from top to down
"""
test_orders_methodE
test_orders_methodB
test_orders_methodD
test_orders_methodC
test_orders_methodA
"""

# Note: Order number should not be duplicated in multiple python files

@pytest.mark.run(order = 2)
def test_orders_methodB(OneTimeSetUp,SetUp):
    print("Running test case method B in order package")

@pytest.mark.run(order = 4)
def test_orders_methodC(OneTimeSetUp,SetUp):
    print("Running test case method C in order package")

@pytest.mark.run(order = 3)
def test_orders_methodD(OneTimeSetUp,SetUp):
    print("Running test case method D in order package")

@pytest.mark.run(order = 1)
def test_orders_methodE(OneTimeSetUp,SetUp):
    print("Running test case method E in order package")

@pytest.mark.run(order = 5)
def test_orders_methodA(OneTimeSetUp,SetUp):
    print("Running test case method A in order package")
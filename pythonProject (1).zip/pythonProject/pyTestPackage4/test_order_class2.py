import pytest

@pytest.mark.run(order = 6)
def test_orders_methodF(OneTimeSetUp,SetUp):
    print("Running test case method F in order package of second python file")

@pytest.mark.run(order = 7)
def test_orders_methodG(OneTimeSetUp,SetUp):
    print("Running test case method G in order package of second python file")
import pytest

#  The set up  and tear down settings for test case method level
@pytest.fixture()
def SettingTestCase():
    print("*"*10)
    print("This will run before the test case - fixture class file")
    # Use "yield" keyword and whatever is after "yield" will be considered as tear down process
    yield
    print("*" * 10)
    print("This will run after the test case - fixture  class file")

# @pytest.yield_fixture() - Decorator has been deprecated
# @pytest.yield_fixture()
# def SettingTestCase():
#     print("*"*10)
#     print("This will run before the test case")
#     # Use "yield" keyword and whatever is after "yield" will be considered as tear down process
#     yield
#     print("*" * 10)
#     print("This will run after the test case")

"""
Run from terminal:
py.test -v -s test_fixture_class2.py
py.test -v -s pyTestPackage1/test_fixture_class2.py
"""

"""
Multiple ways of running:
1) From package level run a specific python file - py.test -v -s test_demo_class1.py  or py.test -v -s test_fixture_class2.py
2) From project level, run a specific python file - py.test -v -s pyTestPackage1/test_demo_class1.py  or py.test -v -s pyTestPackage1/test_fixture_class2.py
3) From package level run all python file --> py.test -v -s

"""

# py.test pyTestPackage1/test_fixture_class2.py
# py.test -v -s pyTestPackage1/test_fixture_class2.py

def test_methodA(SettingTestCase):
    print("Running test case test_methodA of test_fixture_class2 python file/module")
def test_methodB(SettingTestCase):
    print("Running test case test_methodB of test_fixture_class2 python file/module")

"""
1) Exceptions are errors
2) Exception handling can have ELSE part too
3) ELSE part will be executed if the codes do not have exception.
4) FINALLY part will be executed whether the code have exception or not
"""
"""
Example with NO EXCEPTION. ELSE and FINALLY would be executed. EXCEPT part will not
execute as no exception
"""
def exceptionHandling():
    try:
        a = 10
        b = 20
        c = 2

        d = (a + b) / c
        print(d)
    except:
        print("In the except block")
    else:
        print("Because there was no exception, else is executed")
    finally:
        print("Finally, always executed")

exceptionHandling()

print("*************************************************************")

"""
Example with EXCEPTION. EXCEPT and FINALLY would be executed. ELSE part will not
execute as exceptionis there
"""
def exceptionHandling1():
    try:
        a = 10
        b = 20
        c = 0
        d = (a + b) / c
        print(d)
    except:
        print("In the except block")
    else:
        print("Because there was no exception, else is executed")
    finally:
        print("Finally, always executed")

exceptionHandling1()



print("*************************************************************")

"""
If exceptionHandling2 method is used in any other method and we want other method to know
that there is an exception in exceptionHandling2 method , we use the RAISE keyword as
below
"""
def exceptionHandling2():
    try:
        a = 10
        b = 20
        c = 0
        d = (a + b) / c
        print(d)
    except:
        print("In the except block")
        raise Exception("Raised exception")
    else:
        print("Because there was no exception, else is executed")
    finally:
        print("Finally, always executed")

# exceptionHandling2()

print("**************************************************************")

def exceptionHandling3():
    exceptionHandling2()

exceptionHandling3()
from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC



class WorkinLinksExample():
    def Links(self):
        # Driver location needs to be specified
        driverlocation = "C:\driver\chromedriver.exe"
        # Use the OS packages environment property
        # Using the chrome driver tpo find the chrome browser and open it up
        os.environ["webdriver.chrome.driver"] = driverlocation
        # The chrome() method to open the chrome browser and control it. chrome method is a method of webdriver class
        # Controlling the chrome browser --> find elements in the browser and perform action
        driver = webdriver.Chrome()

        # maximise the window so that elements are not hidden and elenium does not throw NO SUCH ELEMENT ERROR
        driver.maximize_window()

        # Navigate to BBC website
        driver.get("https://www.bbc.com/news")

        #Dynamic wait - implicit wait and explicit wait
        # implicit wait is applied in the codes where we use find_element() or find_elements() methods
        # if the element is not found in 20 seconds, it will throw Timeout error
        driver.implicitly_wait(20)

        # Define the explicit wait = Dynamic wait
        explicitW = WebDriverWait(driver, 20)

        listLinks = driver.find_elements(By.TAG_NAME, "a");
        #  1) Count the number of links in BBC website
        numOfLinks = len(listLinks)
        print("The number of links are "+str(numOfLinks))
        print("The number of links are ",numOfLinks)

        # 1. The pop-up is seen in the website and which grades out the landing page as so the text is not thrown out. POP up is not constant.
        # Switch to the frame as the the element containing the text "    News you can trust is news you can use. " is present inside a frame
        # We can switch to frame by the ID/NAME attribute preent in the html script of the frame. If ID or name attribute is not present in html script of frame , we use the address of the frame
        # Address of the frame can be these locating strategies : id, name, tagname, classname, xpath, cssSelector
        # driver.switch_to.frame("offer_ab8d34f0886f1e2c2681-0"); # By id
        # driver.switch_to.frame("offer_ab8d34f0886f1e2c2681-0");  # By name
        # Address of an element is always kept in WebElement package
        # addressFrameID = driver.find_element(By.ID, "offer_ab8d34f0886f1e2c2681-0")
        # addressFrameNAME = driver.find_element(By.NAME, "offer_ab8d34f0886f1e2c2681-0")
        addressFrameXPATH = driver.find_element(By.XPATH, "//*[@id='offer_ab8d34f0886f1e2c2681-0']")
        # addressFrameCSSSelector = driver.find_element(By.CSS_SELECTOR, "#offer_ab8d34f0886f1e2c2681-0")
        driver.switch_to.frame(addressFrameXPATH); #Moving focus of Selenium to the frame

        # use a validation point  - text to be present is "News you can trust is news you can use."
        # Validation with Selenium is done using EXPLICIT wait - dynamic wait
        # Explicit wait is for a specific element
        # until these condtions are met --> https://www.selenium.dev/selenium/docs/api/py/webdriver_support/selenium.webdriver.support.expected_conditions.html?highlight=expectedconditions

        explicitW.until(EC.text_to_be_present_in_element((By.XPATH, "//*[@id='template-container']/div/div[2]/div/div[2]"), "News you can trust is news you can use."))
        print("Text is present")

        #Move the focus from frame to pop-up
        driver.switch_to.default_content()

        # Close the pop up
        driver.find_element(By.XPATH, "//*[@id='responsive-news']/body/div[10]/div/button").click()

        #  2) Get the text of all links
        x = 0 #variable "x" represents the index number variable. Value is 0 as the index number starts with 0
        while(x<len(listLinks)):

            # Certain text are missing:
            #1. The pop-up is seen in the website and which grades out the landing page as so the text is not thrown out. POP up is not constant.
            """#2. Display property is switched off 
            
            Why Display property is off?
            a) The visibility property is switchedd of in design doc and so the display property is automatically off.
            b) The height and width of the element(link) is 0 (zer) pixel.
            c) The x and y cordinates of the element (link ) is zero(0).
            
            Any three of the above condition met, will switch off the display property.
            If the Display is off, text will not be thrown out
            
            if is_displayed()  is TRUE, the DISPLAY property is switched on - text
            if is_displayed()  is FALSE, the DISPLAY property is switched off - no text
            
            """

            # text property - to get text of web elements/control/ui
            # time.sleep(1)  # Static Wait
            textLinks = listLinks[x].text
            # To check the display property of every link
            bValue = listLinks[x].is_displayed()
            # Get the attribute value of id
            attID = listLinks[x].get_attribute("id")
            # Get the attribute value of class
            attCLASS = listLinks[x].get_attribute("class")
            # Get the attribute value of name
            attNAME = listLinks[x].get_attribute("name")
            # time.sleep(1) # Static Wait
            print("The link with index number",x,"is",textLinks,"-- and the display property of the links is", bValue)
            print("The link with index number", x, "is", textLinks, "--ID attribute value is",attID, "--CLASS attribute value is",attCLASS,"--NAme attribute value is",attNAME )
            time.sleep(1)
            x = x+1

l = WorkinLinksExample()
l.Links()
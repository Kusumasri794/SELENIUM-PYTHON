# Assert method have to be used at test case
# IF an assertion fails , that means validation, fails
# The point at which assertion fails is the point at which the interpretation stops
# We can have multiple assertions in a test case


import unittest


class TestClass4(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        print("*" * 20)
        print("This will run before the class file 'TestClass4'.")
        print("*" * 20)

    def setUp(self):
        print("*" * 20)
        print("This will run before each test case - TestClass4")
        print("*" * 20)

    def tearDown(self):
        print("*" * 20)
        print("This will run after each test case - TestClass4")
        print("*" * 20)

    def test_methodC(self):
        # The message will get throw out when the expectation does not match with actual result
        # The message will not get throw out when the expectation does match with actual result

        self.assertEqual(30,30, msg = 'a is not equal to b')
        self.assertEqual(30, 30, msg='Second assertion in method c failed')
        self.assertNotEqual(30,40, msg = 'Assert not equal to failed')
        print("This is the first test case 'test_methodC' in the class file TestClass4")
        self.assertTrue(True, msg = 'assertion true has failed')
        self.assertFalse(False, msg = 'assertion false has failed ')

    def test_methodD(self):
        # self.assertEqual(30, 30, msg='a is not equal to b')
        # self.assertEqual(30, 30, msg='a is not equal to b')
        # self.assertNotEqual(30, 40, msg='a is equal to b')
        print("This is the second  test case 'test_methodD' in the class file TestClass4")
        # self.assertTrue(True, msg='Actual result is false')
        # self.assertFalse(False, msg='Actual result is true')

    @classmethod
    def tearDownClass(self):
        print("*" * 20)
        print("This will run after the class file 'TestClass4'.")
        print("*" * 20)


# We need to create an object
if __name__ == '__main__':
    unittest.main(verbosity=2)
import unittest


class TestClass2(unittest.TestCase):



    # Tese Case Level Fixture - presetting before the test case
    def setUp(self):
        print("*"*20)
        print("Open the browser, maximize the window")
        print("*" * 20)

    # Test Case Level Fixture - post settings after the test case
    def tearDown(self):
        print("*" * 20)
        print("Close the browser")
        print("*" * 20)

    #Test Cases 1
    def test_methodA(self):
        print("This is the first test case 'test_methodA' in the class file TestClass2")

    #Test Case 2
    def test_methodB(self):
        print("This is the second  test case 'test_methodB' in the class file TestClass2")




# We need to create an object
if __name__ == '__main__':
    unittest.main(verbosity=2)

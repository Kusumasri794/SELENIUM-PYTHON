import pytest
# import pytest_html
from selenium import webdriver
# from selenium.webdriver.chrome.options import Option
from selenium.webdriver.common.keys import Keys
import time
from time import sleep
import sys


@pytest.mark.usefixtures("driver_init_2")
class BasicTest:
    pass


class Test_URL_Firefox(BasicTest):

    def test_google_search(self):
        self.driver.get('https://www.google.com/')
        self.driver.maximize_window()
        title = "Google"
        assert title == self.driver.title
        time.sleep(5)
        assert title == self.driver.title
        time.sleep(2)

    def test_google_load(self):
        self.driver.get('https://www.google.com/')
        self.driver.maximize_window()
        expected_title = "Google"
        assert expected_title == self.driver.title
        print("Google")
        time.sleep(5)

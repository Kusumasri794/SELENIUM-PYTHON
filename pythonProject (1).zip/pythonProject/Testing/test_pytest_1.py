import pytest
# import pytest_html
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import time
from time import sleep
import sys


@pytest.mark.usefixtures("driver_init_1")
class BasicTest:
    pass


class Test_URL_Chrome(BasicTest):


    def test_rediffmail_login_app(self):
        self.driver.get('https://mail.rediff.com/cgi-bin/login.cgi')
        self.driver.maximize_window()
        self.driver.find_element_by_id("login1").send_keys("selenium.testmay2017")
        self.driver.find_element_by_id("password").send_keys("test@1234")
        self.driver.find_element_by_name("proceed").submit()
        title = "Rediffmail - Rediff.com"
        assert title == self.driver.title
        time.sleep(5)


    def test_rediffmail_inbox(self):
        self.driver.get('https://mail.rediff.com/cgi-bin/login.cgi')
        self.driver.maximize_window()
        self.driver.find_element_by_id("login1").send_keys("selenium.testmay2017")
        self.driver.find_element_by_id("password").send_keys("test@1234")
        self.driver.find_element_by_name("proceed").submit()
        expected_title = "Rediffmail - Rediff.com"
        assert expected_title == self.driver.title
        print("Send email")
        time.sleep(5)

# Run Selenium tests in parallel with Python for Selenium Python tutorial
import pytest
from selenium import webdriver

# Run with following command: pytest -s -v -n=2
# Where n = 2 is the maximum number of core of the cpu in the local system that pytest will use to do parallel testing
# Flag should be only used for parallel testing
# For parallel testing --> pip install pytest-xdist


@pytest.fixture(scope="class")
def driver_init_1(request):
    web_driver = webdriver.Chrome()
    """
    "request" in "driver_init" fixture has the information of the requesting test function 
    (which would be a method to open the browser). From the line "request.cls.driver = web_driver", 
    it is clear that we are assigning driver value for the invoke test function. So, before opening 
    an URL we need a browser which is driver and it is assigned using fixture with scope on class level.

    When we execute the script - For that particular instance, driver_init declares the request.cls.driver 
    value as "webdriver.Chrome("C:/chromedriver.exe")". So it sets up the driver as chrome for the test 
    execution using the fixture parameter request.cls.driver.Without this assignment, request.cls.driver 
    has no values and your script would fail for driver assignment as None.

    If the scope of the fixture changed, for example from class to method- driver value would be assigned 
    to None for the next method in order and the sequence would get failed. Instead if it is changed from 
    class to module, there wont be any driver.quit or close methods. So you would run your scripts on 
    existing session.
    """
    request.cls.driver = web_driver
    yield
    web_driver.close()


@pytest.fixture(scope="class")
def driver_init_2(request):
    web_driver = webdriver.Firefox()
    request.cls.driver = web_driver
    yield
    web_driver.close()

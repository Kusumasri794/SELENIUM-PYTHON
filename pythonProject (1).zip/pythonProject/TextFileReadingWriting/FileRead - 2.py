"""
File I/O
Reading a file -> .read()
Reading line by line -> .readline()
"""

# my_file = open("FileRead.txt", 'r')

# Read() method will read all line from FileRead.txt
# print(str(my_file.read()))
# my_file.close()

print("Line by line ========>>")

my_file_line = open("FileRead.txt", 'r')
# Readline() method will read each line at a time
print(str(my_file_line.readline()))
print(str(my_file_line.readline()))
print(str(my_file_line.readline()))
print(str(my_file_line.readline()))


my_file_line.close()
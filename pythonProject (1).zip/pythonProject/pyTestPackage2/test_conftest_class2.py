import pytest

# Both the python files test_conftest.class2.py and test_conftest.class1.py have same tear down and set up
# process which works at test case method level
# Under this circumstances, we can have a separate file called as CONFTEST where we can keep same ficxtures
# used across multiple python files.
# conftest.py file should be in the same root/path as the python files

# @pytest.fixture()
# def SetUp():
#     print("Will run before the conftest test case methods")
#     yield
#     print("Will run after the conftest test case methods")


def test_methodC(SetUp):
    print("Running test case test_methodC of test_conftest_class2 python file/module")
def test_methodD(SetUp):
    print("Running test case test_methodD of test_conftest_class2 python file/module")
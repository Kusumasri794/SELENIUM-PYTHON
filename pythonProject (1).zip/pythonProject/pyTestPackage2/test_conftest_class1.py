import pytest


# Both the python files test_conftest.class2.py and test_conftest.class1.py have same tear down and set up
# process which works at test case method level.
# Under this circumstances, we can have a separate file called as CONFTEST where we can keep same ficxtures
# used across multiple python files

# @pytest.fixture()
# def SetUp():
#     print("Will run before the conftest test case methods")
#     yield
#     print("Will run after the conftest test case methods")




def test_methodA(SetUp):
    print("Running test case test_methodA of test_conftest_class1 python file/module")
def test_methodB(SetUp):
    print("Running test case test_methodB of test_conftest_class1 python file/module")
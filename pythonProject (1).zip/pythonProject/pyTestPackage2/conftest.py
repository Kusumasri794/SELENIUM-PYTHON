import pytest


@pytest.fixture()
def SetUp():
    print("Will run before the conftest test case methods")
    yield
    print("Will run after the conftest test case methods")
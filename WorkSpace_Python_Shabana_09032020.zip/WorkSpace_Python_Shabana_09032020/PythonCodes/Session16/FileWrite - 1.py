"""
File I/O
'w' -> Write-Only Mode
'r' -> Read-only Mode
'r+' -> Read And Write Mode
'a' -> Append Mode
"""

# Creating a LIST
my_list = [1,2,3,4,5,6]

# The open method is used to create the text file 'Filename.txt' in the current package
# We can give any other path to create the file in that path
# Mdde is 'w' whgich means write mode
# my_file= open('C:\\Users\\lenovo\\Desktop\\Filename.txt', 'w')
my_file= open('Filename.txt', 'w')

# FOR loop to iterate over items over the LIST
# Variable items to iterate over the FOR loop
for items in my_list:
    # Items iterate over integers
    # write method only accepts STring so castibg to string
    # Below line will write all the items in 'Filename.txt' in a single line
    #my_file.write(str(items))
    # TO write '1,,3,4,5,6' in new line , the be;low line is fine
    my_file.write(str(items)+ '\n')

# It is important to close the file which will kill the buffer memory
# Buffer memory gets created when the open method is used
# If we do not close the file, the buffer memory will not be killed and fishy result will come
my_file.close()
"""
1) Selenium has focus on the web page which is opened by it. This means Selenium would be able to find elements and perform
actions (typing, Clicking) on the element.
2) If we want to move focus of Selenium on a tabbed window or new window or pop-window , we need to use the switch technique.
3) To move focus means to work on the elements present in the tabbed window or new window or pop-up window.
4) Window switching happens by taking the session id of the window( tabbed window or new window or pop-up window).
5) The session iD is auto generated when the client establishes a connection with the server. Session id is actually not seen.
Session ID gets lost when the client ceases to have connection with the server.
6) Session ID is  number or a combination of alphabets and numbers.


"""


from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.action_chains import ActionChains

class WindowSwitch():
    def __init__(self, driver):
        self.driver = driver

    def StepwiseScfreenshot(self, fileName):
        self.driver.get_screenshot_as_file("C:\\Users\\lenovo\\Desktop\\WorkSpace_Python_09032020\\PythonCodes\\Selenium7\\StepwiseScreenshot\\" + fileName + ".png")

    def WorkingWindows(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        self.driver
        # Maximize the Browser Window
        self.driver.maximize_window()
        # Navigate to URl
        self.driver.get("https://news.google.com/")
        time.sleep(10)

        # Calling stepwise screenshot
        self.StepwiseScfreenshot("NewsGoogleWebsite")

        titlePage = self.driver.title
        print("Title of the page: ",titlePage)
        # Click on Corona virus Update: Covid!9 cases in India crosses 50000 - After this point tabbed window is opening
        self.driver.find_element(By.XPATH, "//*[@id='yDmH0d']/c-wiz/div/div[2]/div[2]/div/main/c-wiz/div[1]/div[4]/div/article/a").click()
        time.sleep(10)
        # After the above event, where the tabbed window is opening, find out the Session IDs of both main page and tabbed window
        #1 Window_Handles - This will give the session ID of both windows i.e. main page window and tabbed window , relevant to this application step
        #The first session id will be the ID of the main page window and teh secoond session ID will be the ID of tabbed window
        # 2.current_window_handle - Gives the ID of one window i.e. the window which is in focus
        sessionIDs = self.driver.window_handles
        print(sessionIDs)
        print(type(sessionIDs))
        # A variable to hold the index number
        # _varIndex = 0
        # # Keeping the Session id to a variable
        # while _varIndex<len(sessionIDs):
        #     sessionMainPage = sessionIDs[_varIndex]
        #     # print(sessionMainPage)
        #     sessionTabbedPage = sessionIDs[_varIndex]
        #     # print(sessionTabbedPage)
        #     _varIndex = _varIndex+1
        sessionMainPage = sessionIDs[0]
        sessionTabbedPage = sessionIDs[1]

        # Switch the focus from main page to tabbed window 0 use the switch_to property and the window method
        self.driver.switch_to.window(sessionTabbedPage)

        # Calling stepwise screenshot
        self.StepwiseScfreenshot("TabbedWindow")

        titleLinkPage = self.driver.title
        print("Title of the link page: ", titleLinkPage)
        time.sleep(10)

        # Switch back the focus from tabbed window to main page to clikc on COVID 19 link
        self.driver.switch_to.window(sessionMainPage)
        time.sleep(10)

        # Click on COVID 19 link of the main page
        self.driver.find_element(By.XPATH, "//*[@id='gb']/div[4]/div[2]/div/c-wiz/div/div[5]/div[2]/a").click()
        time.sleep(10)




w1 = WindowSwitch(webdriver.Chrome())
w1.WorkingWindows()
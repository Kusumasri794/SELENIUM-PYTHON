"""
Nested Dictionary:
d = {'k1': {'nestk1':'nestvalue1', 'nestk2': 'nestvalue2'}}
d['k1']['nestk1']
"""

# Nested Dictionary of cars
cars = {'BMW': {'Model': '550i', 'Year': 2016}, 'Benz': {'Model': 'E350', 'Year': 2015}}
# To get the year of manufacturing of BMW
bmw_year = cars['BMW']['Year']
# To print the year of manufacturing of BMW
print(bmw_year)
# To print the model of Benz
print(cars['Benz']['Model'])
# To print the year of manufacturing of Benz
print(cars['Benz']['Year'])
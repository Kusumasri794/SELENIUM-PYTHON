"""
1) Data type to store more than one value in one variable name, in terms of key value pairs
2) Dictionary items are in curly braces {} in key:value pairs, separated with "," -->{'k1':'v1', 'k2':'v2'}
3) Keys should not be duplicated. Compiler will not show any syntax error if duplicate keys are defined;
4) Compiler will ignore duplicate key and its value and the result will also not show the duplicate key and its value
5) Values can be duplicated
6) Not sequenced, no indexing -> Mapping
7) Value can be integer, String, etc.
8) Keys should be always of String
"""



# Dictionary of distinct keys and distinct value. Value can be of mixed type
car_c1 = {'make': 'bmw', 'model': '550i', 'year': 2016}
#To print all values in the dictionary
print(car_c1)
print(len(car_c1))

# Dictionary of duplicate keys and unique value. Value can be of mixed type
car_c2 = {'make': 'bmw', 'model': '550i', 'year': 2016, 'make': 'hummer'}
#To print all values in the dictionary
print(car_c2)
print(len(car_c2))

# Dictionary of duplicate keys and duplicate value. Value can be of mixed type
car_c23 = {'make': 'bmw', 'model': '550i', 'year': 2016, 'make': 'bmw'}
#To print all values in the dictionary
print(car_c23)
print(len(car_c23))


# Dictionary of distinct keys and duplicate value. Value can be of mixed type
car_c3 = {'make': 'bmw', 'model': '550i', 'year': 2016, 'Make': 'bmw'}
#To print all values in the dictionary
print(car_c3)
print(len(car_c3))

# To print value of the key model
model = car_c3['model']
print(model)
print(car_c3["model"])
print(car_c3["year"])



# Empty Dictionary
d = {}
print(d)
# To fill the empty dictionary d with key - value pairs
d['one'] = 1
d['two'] = 2
# To print Dictionary d after filling
print(d)
# To add eight with value at key "two"
sum_1 = d['two'] + 8
# To print sum_1
print(sum_1)
# To print value in the D dictionary
print(d)
# To change the value of the key "two"
d['two'] = d['two'] + 8  #=10
# To print value in the D dictionary after changing the value of the key "two"
print(d)
"""
1) List is a Data type to store more than one value in one variable name
2) List items are in square brackets, separated with comma and items are within
double quotes, if String or may not be under double quotes if integer or float
3) List allows duplication of data and indexing
"""



"""
List of cars with values - String list
"""
cars = [ "BMW", "Honda", "Audi", "Suzuki", "BMW"]
print(type(cars))
#Print the list of value in cars variable
print(cars)
# An empty list
empty_list = []
# Print an empty list
print(empty_list)


# Print out 20 HASH in two ways:
print("#"*20)
print("####################")

# To print honda at index number 1 from the list of cars
print(cars[1])

print("#"*20)

"""
To create another list of numbers - integer list
"""
num_list = [1, 2, 3]
# To add the value at index number 0 and 1 of number list
sum_num = num_list[0] + num_list[1]
# To print the value at index number 0 and 1 of number list
print(sum_num)
# To add the value at index number 0,1 and 2 of number list
sum_num_1 = num_list[0] + num_list[1] + num_list[2]
# To print value at index number 0,1 and 2 of number list
print(sum_num_1)

print("#"*20)

"""
To replace Honda with Benz
"""
more_cars = [ "BMW", "Honda", "Audi"]
# To print value at index number 1
print(more_cars[1])
# TO replace honda with Benz at index number 1
more_cars[1] = "Benz"
# To print value at index number 1
print(more_cars[1])
# To print all values in the list of cars
print(more_cars)

print("#"*20)

"""
To create another list of numbers - float list
"""
float_num_list = [1.1, 2.0, 3.3]
# To print all values from the list of floating numbers
print(float_num_list)
# Below will show error
# print(float_num_list[])
# To print value at index number 2 from the list of floating numbers
print(float_num_list[2])
# Replace value 3.3 at index number 2 to value 4.9
float_num_list[2] = 4.9
# To print value at index number 2 from the list of floating numbers
print(float_num_list[2])
# To print all values from the list of floating numbers
print(float_num_list)

print("#"*20)

"""
To create another list of numbers & String - Mixed list
"""
Mixed_num_list = [1, 2.0, 3.3, "Hi"]
# To print all values from the list of mixed numbers
print(Mixed_num_list)
# Replace value 1 at index number 0 to value 4.9
Mixed_num_list[3] = 4.9
# To print value at index number 2 from the list of floating numbers
print(Mixed_num_list[3])
# To print all values from the list of floating numbers
print(Mixed_num_list)
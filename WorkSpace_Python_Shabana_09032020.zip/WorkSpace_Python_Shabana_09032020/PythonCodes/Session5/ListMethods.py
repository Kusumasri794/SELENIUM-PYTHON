"""
Built-in methods to help manipulating a list:
1) len() - To get the size of the list
2) append()- To add a value to the list at the last
3) insert() - TO insert a value to the list at a specific index number
4) pop() - To remove value from the last index number
5) remove(} - To remove a specific value
6) sort() - To sort the value of the list in alphabetical order
7) Slicing - does change the values in the list
8) index() - To find the index number of a value from the list

"""

# List of cars
cars = [ "BMW", "Honda", "Audi", "Suzuki","Suzuki"]

x = cars.count("Suzuki")
print(x)

# Del function
# del cars[1]
# print(cars)


# To find length/size of the list
length = len(cars)
print(length)
print(len(cars))

print("*****************************")

# To append value at the last
cars.append("Benz")
print(cars)
cars.append("MiniCooper")
print(cars)
# The below line will show None
print(cars.append("Jaguar"))
# cars.append("Jaguar")
# print(cars)


# print("*****************************")

# To insert value in the list at a specific index number
# "Honda', 'Audi', 'Suzuki', 'Benz', 'MiniCooper' - all will shift one place towards right
# Shifting the existing item one step right with INSERT method
cars.insert(1, "Polo")
print(cars)
# Replacing POLO by HUMMER
cars[1] = "Hummer"
print(cars)
# The below line will show None
print(cars.insert(0, "Jetta"))
print(cars)


print("*****************************")

# To find the index number
x = cars.index("Honda")
print(x)
print(cars.index("Honda"))

print("*****************************")

# To remove the last value
y = cars.pop()
# To print the last value removed i.e. "MiniCooper
print(y)
# To print the value in the list of cars - will print all except MiniCooper
print(cars)
# To print the last value removed and i.e.MiniCooper as list of cars contain ['Jetta', 'BMW', 'Hummer', 'Honda', 'Audi', 'Suzuki', 'Benz', 'MiniCooper']
print(cars.pop())
# To print the value in the list of cars - will print all except Benz
print(cars)

print("*****************************")

# To remove a specific value from the list - BMW
u = cars.remove("BMW")
print(u)
# The below line will show - > ['BMW', 'Honda', 'Audi', 'Suzuki']
print(cars)
# The below line will show None
print(cars.remove("Honda"))


print("*****************************")



# Slicing
# Values in the list of cars
print(cars)
# To print value from index 0 to 2 , including 1 and excluding 2
a = cars[0:2]
print(a)
# To print value from index 1 to all
b = cars[1:]
print(b)
# To print all values
c = cars[:]
print(c)
# To print all except the last value defined by index number -1
d = cars[:-1]
print(d)


print("*****************************")


# To sort all values of the list in alphabetical order
# Values in the list of cars
print(cars)
y = cars.sort()
# The below line will print None as Y is not a list
print(y)
print (cars)
# Sorting changes the index number of items permanently
print(cars.index("Suzuki"))

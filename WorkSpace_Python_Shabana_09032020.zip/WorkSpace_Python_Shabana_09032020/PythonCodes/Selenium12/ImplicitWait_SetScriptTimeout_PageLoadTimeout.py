"""
1) The time packages sleep function that we use is a STATIC wait.
2)Static wait means even if the element is fount , the selenium script will still wait until the time period defined
time.sleep(10) --> If the element is found by Selenium in 2 secs , it will still wait for 8 seconds more before executing the
next line of the code.This behaviour make the resources to wait until the time period is over. Resources means memory and the
process.
3) Using static wait is not good until we navigate from one page to another or there is stale element exception.
4) Selenium provides dynamic wait. This is used to wait for an element so that the script finds and execute. In this knd of wait,
if we have give 10 second and the element is found in 2 seconds, the selenium script will not wait for another 8 seconds. It
will go to the next line of the script.
5) Dynamic wait are of two types: a)Implicit wait  b)Explicit wait
6) Implicit wait  - is for all elements which we use in a selenium script. A maximum time period is defined and if the element is
not found out will throw exception/error.

"is for all elements" means where ever in the Selenium script, we use the find_element method OR find_elements method , IMPLICIT
WAIT will come into force

7)Explicit Wait - is utilised for specific element . The will make the script to wait until a condition is achieved for an element.
"condition achieved for an element"  --> cam mean if the element is visible in the specific time period defined in explicit wait,
cam mean if the element is invisible in the specific time period defined in explicit wait, cam mean if the element is clickable in
the specific time period defined in explicit wait,etc.
URL to check the conditions --> https://www.selenium.dev/selenium/docs/api/py/webdriver_support/selenium.webdriver.support.expected_conditions.html?highlight=wait

Example of EXPLICIT WAIT --> WebDriverWAit (class)
for conditons, the following method --> until, until_not


"""

from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class ImplicitWait():
    def usingImplicit(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://money.rediff.com/gainers/bse/daily/groupa?src=gain_lose")
        # time.sleep(7)

        # Page load timeout - To see that the URL load in a specific time
        #Set the amount of time to wait for a page load to complete before throwing an error. Time out exception
        driver.set_page_load_timeout(1)


        # Implicit wait - Time defined is in seconds
        # Here 10 seconds is the maximum time period for the eleemnt or elements to be found out. If not found, will show error/exception
        driver.implicitly_wait(10)

        # For AJAX based components, we use set_script_timeout method. TIme period will be in seconds.This is used to see that script does not fail before the AJAX component gets loaded
        # Set the amount of time that the script should wait during an execute_async_script call before throwing an error.
        # driver.set_script_timeout(10)

        # 1) Get the text from First row first column of the heading of the table
        str1 = driver.find_element(By.CSS_SELECTOR, "#leftcontainer > table > thead > tr > th:nth-child(1)").text
        print("Text from First row first column of the heading of the table is ", str1)

        print("**********************************")

        # 2) Get all data from the first row all column of the heading of the table - Row-wise
        str2 = driver.find_elements(By.CSS_SELECTOR, "#leftcontainer > table > thead > tr > th")
        x1 = 0
        while x1 < len(str2):
            headingText = str2[x1].text
            print(headingText)
            x1 = x1 + 1

        print("**********************************")

        # 3) Get all data from the first row all column of the heading of the table - Column-wise
        str3 = driver.find_element(By.CSS_SELECTOR, "#leftcontainer > table > thead > tr").text
        print(str3)


i1 = ImplicitWait()
i1.usingImplicit()
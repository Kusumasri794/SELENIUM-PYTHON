from selenium import webdriver
import time
import os

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from datetime import datetime
from datetime import timedelta
from datetime import date
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC

# driver = webdriver.Chrome()
# def calendarFunction():
#     # To check the system date, get out month from system date
#     today = date.today()
#     # Textual month, day and year
#     d2 = today.strftime("%B %d, %y")
#     print("d2 =", d2)
#     print(type(d2))
#     listWords = d2.split(" ")
#     print(listWords)
#     monthValue = listWords[0]
#     print(monthValue)
#
#     # Add 1 day
#     # if (year ==2020 and above and month is May and above and date is todays date and above plus visible )
#
#
#     # data = datetime.now() + timedelta(days=1)
#     # d3 = data.strftime(("%B %d, %y"))
#     # print(d3)
#
#     part1 = "//div[@class = 'cal-body BE_flight_origin_date']/div[2]/div[3]/div[2]/div[1]/div[2]/table[1]/tbody[1]/tr["
#     part2 = "]/td["
#     part3 = "]"
#     # xpathCreation = part1+str(aRow)+part2+str(aColumn)+part3
#     # print(xpathCreation)
#     aRow = 1
#     while aRow<=5 :
#         # print(aRow)
#         aColumn = 1
#         while aColumn<=7:
#             # print(aColumn)
#             xpathCreation = part1 + str(aRow) + part2 + str(aColumn) + part3
#             # Check the Month value
#             textValue = driver.find_element(By.XPATH, "//*[@id='BE_flight_form_wrapper']/div[1]/div[2]/ul/li[2]/ul/li[1]/section/div/div[2]/div[2]/div[1]/div[1]").text
#             print(textValue)
#             boolValue = driver.find_element(By.XPATH, xpathCreation).is_enabled()
#             print(xpathCreation)
#             aColumn = aColumn + 1
#             # print("Column:",aColumn)
#
#         aRow = aRow+1
#         # print("Row:",aRow)
#

# calendarFunction()

class ExplicitWait():
    def usingExplicit(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        # driver = webdriver.Chrome()
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://www.yatra.com/")

        # Set the page load timeout
        driver.set_page_load_timeout(20)

        # USe the Implicit wait
        driver.implicitly_wait(20)


        # Click and Type on Departure
        # driver.find_element(By.XPATH, "//*[@id='BE_flight_origin_city']").click()
        # time.sleep(10)
        driver.find_element(By.XPATH, "//*[@id='BE_flight_origin_city']").clear()
        time.sleep(10)
        deptAddress = driver.find_element(By.XPATH, "//*[@id='BE_flight_origin_city']")
        act1 = ActionChains(driver)
        act1.move_to_element(deptAddress).click()
        # act1.move_to_element(deptAddress).click().send_keys("Bangalore")
        act1.move_to_element(deptAddress).key_down("B")
        act1.move_to_element(deptAddress).key_up("B")
        act1.move_to_element(deptAddress).key_down("a")
        act1.move_to_element(deptAddress).key_up("a")
        act1.move_to_element(deptAddress).key_down("n")
        act1.move_to_element(deptAddress).key_up("n")
        act1.move_to_element(deptAddress).key_down("g")
        act1.move_to_element(deptAddress).key_up("g")
        act1.move_to_element(deptAddress).key_down("a")
        act1.move_to_element(deptAddress).key_up("a")
        act1.move_to_element(deptAddress).key_down("l")
        act1.move_to_element(deptAddress).key_up("l")
        act1.move_to_element(deptAddress).key_down("o")
        act1.move_to_element(deptAddress).key_up("o")
        act1.move_to_element(deptAddress).key_down("r")
        act1.move_to_element(deptAddress).key_up("r")
        act1.move_to_element(deptAddress).key_down("e")
        act1.move_to_element(deptAddress).key_up("e")
        act1.perform()
        # driver.find_element(By.XPATH, "//*[@id='BE_flight_origin_city']").send_keys("Bangalore")
        time.sleep(10)
        driver.find_element(By.XPATH, "//*[@id='BE_flight_origin_city']").send_keys(Keys.RETURN)

        # Click and Type on Arrival
        driver.find_element(By.XPATH, "//*[@id='BE_flight_arrival_city']").clear()
        time.sleep(10)
        arrivalAddress = driver.find_element(By.XPATH, "//*[@id='BE_flight_arrival_city']")
        act2 = ActionChains(driver)
        act2.move_to_element(arrivalAddress).click()
        # act1.move_to_element(deptAddress).click().send_keys("Bangalore")
        act2.move_to_element(deptAddress).key_down("M")
        act2.move_to_element(deptAddress).key_up("M")
        act2.move_to_element(deptAddress).key_down("u")
        act2.move_to_element(deptAddress).key_up("u")
        act2.move_to_element(deptAddress).key_down("m")
        act2.move_to_element(deptAddress).key_up("m")
        act2.move_to_element(deptAddress).key_down("b")
        act2.move_to_element(deptAddress).key_up("b")
        act2.move_to_element(deptAddress).key_down("a")
        act2.move_to_element(deptAddress).key_up("a")
        act2.move_to_element(deptAddress).key_down("i")
        act2.move_to_element(deptAddress).key_up("i")
        act2.perform()
        # driver.find_element(By.XPATH, "//*[@id='BE_flight_arrival_city']").click()
        # driver.find_element(By.XPATH, "//*[@id='BE_flight_arrival_city']").send_keys("Mumbai")
        # time.sleep(5)
        driver.find_element(By.XPATH, "//*[@id='BE_flight_arrival_city']").send_keys(Keys.RETURN)

        # Work on Calendar - Departure Date
        driver.find_element(By.XPATH, "//*[@id='BE_flight_origin_date']").click()

        # Textual month, day and year - Getting the System time
        today = date.today()
        d2 = today.strftime("%m, %d, %y")
        print("d2 =", d2)


        # Check to see the Calendar month is equal to or more than the system month
        # Click the Date of Departure
        driver.find_element(By.XPATH, "//*[@id='30/05/2020']").click()

        # time.sleep(7)

        # Click onm the SEARCH FLIGHTS button
        driver.find_element(By.XPATH, "//*[@id='BE_flight_flsearch_btn']").click()

        time.sleep(7)

        # Click mon the STOP 1 - Clicking on the STOP options will trigger the AJAX components to work
        driver.find_element(By.XPATH, "//*[@id='Flight-APP']/section/section[1]/div/div[1]/div/div[2]/div[2]/label[2]/p").click()

        time.sleep(7)

        #Will click on VISTARA UK-820/943 BOOK button - if the number UK-820/943 is visible , We will book , else no booking - HERE we can use WedDriver Wait 0 can e used for
        # specific element
        # address of UK-820/943
        # addressVistara = driver.find_element(By.XPATH, "//*[@id='BLRDELUK820WM20200530DELBOMUK943WM20200531_1AWS4']/div/div[1]/div[1]/div/div[2]/p/span")
        elementVistara = WebDriverWait(driver, 30, 3, (NoSuchElementException))
        elementVistara.until(EC.text_to_be_present_in_element((By.XPATH,"//*[@id='BLRDELUK820WM20200530DELBOMUK943WM20200531_1AWS4']/div/div[1]/div[1]/div/div[2]/p/span"), "UK-820/943"))

        # Click BOOK button of Indigo 6e-755
        driver.find_element(By.XPATH, "//*[@id='BLRDELUK820WM20200530DELBOMUK943WM20200531_1AWS4']/div/div[1]/div[4]/div/div[2]/button").click()

        time.sleep(10)

e = ExplicitWait()
e.usingExplicit()
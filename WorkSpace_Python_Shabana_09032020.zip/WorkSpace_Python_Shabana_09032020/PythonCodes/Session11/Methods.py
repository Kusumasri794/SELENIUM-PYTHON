"""
1) A group of code statements which can perform some specific task/functionality is called a method
2) Methods are reusable and can be called when needed in the code.
3) def is the keyword used to define a method.def is followed by single indent and then the method name

4) METHODS OUTSIDE OF A CLASS IN PYTHON IS CALLED AS FUNCTION
5)METHODS ARE CALLED METHODS IN PYTHON, WHEN IT IS DEFINED INSIDE A CLASS
"""


"""
FUNCTION Defined without parameter:
1)FUNCTION without parameters is not a dynamic function as the result will be same when calling the function more than once.
"""

# Can we call the function before it is defined ? NO
# Addition()


# Addtion function
def Addition():
    a = 100
    b = 200
    c = a+b
    print("The value of addition function is "+str(c))

# Calling the Addition function
#Addition()
Addition()

""" 
Duplicate the function name in Java and C#  --> allowed with OVERLOADING
# In Java & c#, function name can be same if signature is different. 
# Signature can be different in jave or c# --> if the number of parameter is different OR type of parameter is different, OR the sequesnce of the type of parameter is different

# 1)Number of parameters --> 2 or 3 parameters in the argument of function
# Addition(int a, int b)
# Addition(int a, int b, int c)

# 2)Type of parameter --> int, string, float
#Addition(int a, string b)

# 3) sequesnce of the type of parameter --> Addition(int a, int b)
#Addition(string a, int b)

# The process in JAVA AND C# is called as OVERLOADING -> Concept of POLYMORPHISM of Object oriented programminmg


IS OVERLOADING ALLOWED IN PYTHON? 
THRERE IS NO CONCEPT OF OVERLOADING IN PYTHON. THAT MEANS WE CAN HAVE DUPLICATE FUNCTION NAME WITH SAME SIGNATURE.

"""
def Addition():
    a1 = 200
    b1 = 400
    c1 = a1+b1
    print("The value of addition function is "+str(c1))

# Calling the Addition function
Addition() #600
Addition() #600
"""
1) A function without parameter is always static i..e the function gives the same result when called again
2) In order to make FUNCTION dynamic, we need to use FUNCTION WITH PARAMETER
3) In PYthon, we only define the parameter variable and not its TYPE/DATATYPE(int, string, flaot) . When the function is called and we
PASS the parameter value, that is when the interpretor understands that the parameter variable is referencing object of which class.

"""

# c is a local variable --> defoine inside the function body
# A local variable is defined inside a function body
# A parameter variable for e.g a & b , are also local variable
def Addition(a, b):
    c = a+b
    print("The value of the addition function is "+str(c))

Addition(20,30)
Addition(30,10)
Addition(20, 20.3)

def Addition(a, b):
    c = str(a)+b
    print("The value of the addition function is "+c)

Addition(100, "Hi!")

def sub_nums(n1, n2):
    print(n1 - n2)

# Calling the sum_nums method
sub_nums(8, 2)

# Calling the sum_nums method again
sub_nums(5.0, 1)

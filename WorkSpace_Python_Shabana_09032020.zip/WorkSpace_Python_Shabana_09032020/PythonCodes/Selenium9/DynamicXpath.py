"""
1 Sometimes the ID values or  the NAME value keeps on changing. They change on refereshing the application or opening
the same application later on.
2) If the ID value or name value changes at runtime, it will not match with values defined in script ; and the script will fail.
3) These kind of dynamic values can be handles by XPATH or CssSelector. That's why we call them as dynamic XPATH or dynamic Css Selector.
4) Dynamic XPath uses functions like starts-with or contains
5) starts-with can be used if the starting value for ID or NAME is constant
6) contains can be used if the starting value for ID or NAME is constant, or the middle value is constant or the end value is contant.



"""



from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class Xpath():
    def DynamicXpath(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://register.rediff.com/register/register.php?FormName=user_details")
        time.sleep(10)
        # Type in the Full Name edit box
        #  driver.find_element(By.NAME, "name562b31e6").send_keys("Kaushik") #  named9bbdb7d --Runtime Value so the script show NO SUCH ELEMENT ERROR
        # Using Dynamic Xpath
        # driver.find_element(By.XPATH, "//input[starts-with(@name, 'name')]").send_keys("Kaushik")
        driver.find_element(By.XPATH, "//input[contains(@name, 'name')]").send_keys("Kaushik")
        time.sleep(5)
        # Type in the Choose a Rediffmail  edit box
        # driver.find_element(By.XPATH, "//input[starts-with(@name, 'login')]").send_keys("kaushik.aryan")
        driver.find_element(By.XPATH, "//input[contains(@name, 'login')]").send_keys("kaushik.aryan")
        time.sleep(5)
        # Close the browser
        driver.quit()





x1 = Xpath()
x1.DynamicXpath()
from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class Xpath():
    def XpathFunction(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://in.yahoo.com/?p=us")
        time.sleep(10)
        # Click on NEWS menu button  - text() function
        # driver.find_element(By.XPATH, "//a[text() = 'News']").click()

        # Click on NEWS menu button  - Logical Values
        # Sometimes the attribute and its value is not able to finc the element , then we can uses multiple attribute and involve the AND or OR logic
        # driver.find_element(By.XPATH, "//a[@href = 'https://in.news.yahoo.com/' and @class='C(#4d00ae) Fz(14px) Fw(b) Lh(2.1) Pos(r) Td(n) Td(u):h']").click()
        # driver.find_element(By.XPATH,"//a[@href = 'https://in.news.yahoo.com/' and text()='News']").click()
        # driver.find_element(By.XPATH,"//a[@href = 'https://in.news.yahoo.com/' or @class='C(#4d00ae) Fz(14px) Fw(b) Lh(2.1) Pos(r) Td(n) Td(u):h']").click()
        driver.find_element(By.XPATH, "//a[@href = 'https://in.news.yahoo.com/' or text()='Cricket']").click()

        time.sleep(10)
        # Title of the Link page
        titlePage = driver.title
        print("Title of the link page is",titlePage)



x1 = Xpath()
x1.XpathFunction()
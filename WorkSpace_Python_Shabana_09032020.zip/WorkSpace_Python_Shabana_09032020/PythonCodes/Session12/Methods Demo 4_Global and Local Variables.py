"""
Variable Scope:

!) Local variable have scope within the body of method. They are defined inside the particular method body
2) Global variable have scope globally
3) We need to used GLOBAL keyword to use it inside method body
4) Global variable are defined outside of methods
"""
"""Not Changing the value of GLOBAL VARIABLE"""
# Global variable
a = 10

def test_method(a):
    b = a
    print("Value of local variable 'a' is: " + str(a)) # Local variable
    print("Value of local variable 'b' is: " + str(b)) # Local variable

# The value od parameter variable a is passed as 12 which will be printed
test_method(12) # paas the patrameter variable value. Parameter variable is a local variable

print("*****************************************")

def test_method1(a):
    # The value of global var 'a' which is 10 is passed to parameter variable "a" which is localised
    print("Value of local variable 'a' is: " + str(a))
    a = 2
    print("New value of local 'a' is: " + str(a))

#To print the value of global variable 'a' whose value is 10
print("Value of global variable 'a' is: " + str(a))
# Global Variable 'a' called whose value is 10 in the method test_method1.
# This value of global variable is passed in local variable a defined as a parameter variable
test_method1(a) # This will take the global variable "a's" value and that is 10
# Value of global variable remains unchanged to 10
print("Did the value of global 'a' change? " + str(a))


print("*****************************************")

def test_method2(a):
    # The value of global var 'a' which is 10 is passed to parameter variable a which is localised
    print("Value of local variable 'a' inside the method is: " + str(a))
    # Value of local variable changed to 2. This "a" is a localised variable now
    a = 2
    b = 4
    c = a+b
    # The value of local var 'a' which is changed to 2 is printed
    print("New value of local variable 'c' is: ", a+b)

#To print the value of global variable 'a' whose value is 10
print("Value of global variable 'a' is: " + str(a))
# Global Variable 'a' called whose value is 10 in the method test_method1.
# This value of global variable is passed as a value in  parameter variable of the method
test_method2(a)
# Value of global variable remains unchanged to 10. This is called after test_method2(a)
print("Did the value of global 'a' change? " + str(a))



print("*****************************************")

"""Changing the value of GLOBAL VARIABLE"""
a = 20

def test_method2():
    # Called the global variable a
    global a
    print("Value of 'a' inside the method is: " + str(a))

    a = 2
    b = 8
    c = a+b
    print("New value of 'c' inside the method is changed to: " + str(a))

print("Value of global variable 'a' is: " + str(a))
test_method2()
# Value of Global variable changed
print("Did the value of global 'a' change? " + str(a))
# Variable c is localised variable of method test_method2. it is not a Global Variable
# Below print command show unresolved reference as variable c is called out method test_method2
# print(c)
# print(b)
print(a)
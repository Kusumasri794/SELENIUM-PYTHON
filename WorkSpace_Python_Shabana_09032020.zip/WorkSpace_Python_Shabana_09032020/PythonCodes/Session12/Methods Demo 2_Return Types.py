"""
1) A group of code statements which can perform some specific task
2) Methods are reusable and can be called when needed in the code
3) Return statement is used to return the value. In other words it holds the value
which can be used in other portions of the code
4) Number of parameter variable defined in method should be equal to number of parameter
returned in return statement. RETURN STATEMENT SHOULD BE THE LAST LINE OF THE CODE>
5) Method name can have alphabets (in capital or small) and can have underscore(_)
6) Methods can have camel casing
7) Methods, class, function, module should have docstring. docstring contains, parameters
of method, return . We should define what the method does in a docstring
8) Unlike other languages, python does not require us to define parameter type i.e.
python is not strongly type i.e. no strong data type.
9) Since python does not require parameter type, we can pass any parameter value and since
python supports dynamic binding, the parameter value will be accepted. BUT WE SHOULD BE CAREFUL
about what parameter type we are passing

"""
# Docstring
def multiply(a,b):
    """
    This is a function to get multiplied value with two parameters passed. Pass integer value in parameters
    :param a:
    :param b:
    :return: Not a retur type function
    """
    c = a*b
    print('The multiplied value is '+str(c))

# Call the Multiply function
multiply(12,12)

# FUNCTION WITH RETURN STATEMENT
def divide(a,b):
    """
    This function divides two integer value
    :param a: can be of integer value
    :param b: can be of integer value
    :return: returns the division between two numbers which is a float value
    """
    return a/b

# Call the divide function
d = divide(10,5)
print("The value of the divide function is "+str(d))


def modulo(a,b,c):
    """
    :param a: can be of integer value
    :param b: can be of integer value
    :param c: can be of integer value
    :return: a string value
    """
    d = (a%b)%c
    e = str(d)
    return e

# Call the Modulo function
f = modulo(10,5,2)
print("The value of the modulo function is "+f)


# Addition of two numbers
def sum_Nums( n1, n2):
    """
    Get sum of two numbers
    :param n1:
    :param n2:
    :return:
    """
    return n1 + n2

# Putting the return of sum_nums function in sum1 variable. Parameter value passed are integers
sum1 = sum_Nums(2, 8)
# Print the value of variable sum1
print(sum1)


# Putting the return of sum_nums function in sum2 variable.Parameter value passed are integers
sum2 =  sum_Nums(3, 3)
# Print the value of variable sum1
print(sum2)


# Putting the return of sum_nums function in string_var1 variable.Parameter value passed are Strings
string_var1 = sum_Nums('one', 'two')
# Printing the value of the variable string_var1 which will be concatenation of two string
print(string_var1)


# Number of parameter vaues passed is not matching against the return statement.
# So will show UNEXPECTED STATEMENT in the parameter passed if we hover mouse
# sum3 = sum_Nums(10,20,30)
# Print the value of variable sum3. Printing shows error in console --> TypeError: sum_Nums() takes 2 positional arguments but 3 were given
# print(sum3)


# Putting the return of sum_Nums function in string_var2 variable.Parameter value passed are String and integer
# string_var2 = sum_Nums('one', 2)
# Printing the value of the variable string_var2 which will show error in console
# Cannot add String to a integer
# print(string_var2) # TypeError: can only concatenate str (not "int") to str

print("**************************Subtraction function*************************************")

# Subtraction function
def sub_num(n1,n2):
    """
    A docstring. Get subtraction of two numbers
    :param n1:
    :param n2:
    :return:
    """
    return n2-n1

# Calling Subtraction method
sub1 = sub_num(30, 40)
# Print the variable sub1
print(sub1)

# Calling Subtraction method
# sub2 = sub_num("Fifty", "Fourty")
# Print the variable sub1
# print(sub2)  # Caunsupported operand type(s) for -: 'str' and 'str'




print("***************************************************************")

# To create a function to find city is present in a LIST
def isPresent(city):
    # A LIST of cities
    l = ['sfo', 'nyc', 'la']
    if city in l:
        return True
    else:
        return False

# Calling the method isPresent to find if BOSTON is present in the list.
# Return will be either TRUE of FALSE
# If city is present in the LIST, will show TRUE otherwise FALSE
# Return the value of isPresent method to variable x
x = isPresent('boston')
# Printing x and the result is false
print(x)


# Return the value of isPresent method to variable y
y = isPresent("nyc")
# Printing y and the result is true
print(y)
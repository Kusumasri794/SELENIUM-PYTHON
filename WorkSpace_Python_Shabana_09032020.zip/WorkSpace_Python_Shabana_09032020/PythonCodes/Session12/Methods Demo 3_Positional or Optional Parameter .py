"""
Positional Parameters
They are like optional parameters
And can be assigned a default value, if no value is provided from outside
"""

# n1 and n2 are non-optional parameters
def sum_nums(n1, n2):
    """
    Get sum of two numbers
    :param n1:
    :param n2:
    :return:
    """
    return n1 + n2

sum1 = sum_nums(4, 12)
print(sum1)

print("*******************************************")

# n1 and n2 are positional/optional parameters. n1 and n2 are defined with default values
# We do not pass any parameter value when the method is called
def sub_nums(n1 = 2, n2 = 4):
    """
    Get subtraction of two numbers
    :param n1:
    :param n2:
    :return:
    """
    return n2 - n1

# Parameter value not passed ; so will take the default value/optional values where is n1 = 2 and n2 = 4
sub1 = sub_nums()
# Will print 2
print(sub1)

print("*******************************************")

# p1 and p2 are positional optional parameters. p1 and p2 are defined with default values
# We do pass parameter variable and their value when the method is called.
# Parameter value defined when the method is called will take precedence
def mul_nums(p1 = 2, p2 = 4):
    """
    Get subtraction of two numbers
    :param p1:
    :param p2:
    :return:
    """
    return p2 * p1

# Parameter variable and their values passed in the function called; so this will have precedence
# Tha value of 20 for p1 will take precedence than the default value of p1 defined as 2
# Tha value of 40 for p2 will take precedence than the default value of p2 defined as 4
mul1 = mul_nums(p1 = 20, p2 = 40)
# Will print 800
print(mul1)

# Interchange the position of p2 and p1 in the called method. It does not matter
# Tha value of 10 for p1 will take precedence than the default value of p1 defined as 2
# Tha value of 30 for p2 will take precedence than the default value of p2 defined as 4
mul2 = mul_nums(p2 = 30, p1 = 10)
# Will print 300
print(mul2)


# Only one Parameter variable and its values passed in the function called;
# Tha default value of 2 for p1 will be taken
# Tha value of 100 for p2 will take precedence than the default value of p2 defined as 4
mul3 = mul_nums(p2 = 100)
# Will print 200
print(mul3)


# Only one Parameter variable and its values passed in the function called;
# Tha default value of 4 for p2 will be taken
# Tha value of 100 for p1 will take precedence than the default value of p1 defined as 2
mul4 = mul_nums(p1 = 100)
# Will print 400
print(mul4)


print("*******************************************")

# A typical case of non-optional parameter and positional/optional parameter
def div_num(q1, q2 = 20):
    """
    Division containing one non-optional and one optional parameter
    :param q1:
    :param q2:
    :return:
    """
    return q2/q1

# Parameter value 10 assigned to q1 and q2 will take the default value 20
div1 = div_num(10)
# Will print 2.0
print(div1)


# Parameter value 10 assigned to q1 and q2 will take the value 40 in the div method called below
div2 =div_num(10, q2 = 40)
# Will print 4.0
print(div2)



def Add(q1, q2, q3 = 40):
    """
    Division containing one non-optional and one optional parameter
    :param q1:
    :param q2:
    :return:
    """
    return q1+q2+q3

# When default value are not defined for parameters, maintain the sequent of it when passing values. Otherwise syntax error will come
# add1 = Add(q3 = 100,10,30)
# print(add1)

add2 = Add(100, 200, q3 = 100)
print(add2)

def Add(q1=10, q2=20, q3 = 40):
    """
    Division containing one non-optional and one optional parameter
    :param q1:
    :param q2:
    :return:
    """
    return q1+q2+q3

add3 = Add(q3 = 100, q2 = 200, q1 = 1000)
print(add3)
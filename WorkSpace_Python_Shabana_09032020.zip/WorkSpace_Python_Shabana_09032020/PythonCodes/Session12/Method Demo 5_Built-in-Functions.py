"""
Some built-in functions
max(): It takes any number of arguments and returns the largest one.

min(): It takes any number of arguments and returns the smallest one.

abs(): It returns the absolute value of the number, that number's distance from 0.
It always returns a positive value and it only takes a single number.

type(): It returns the type of the data it receives as an argument.

BUILT-IN FUNCTION URL -->https://docs.python.org/3/library/functions.html#abs
"""

# '*' represent multiple arguments in the largest_num method and the parameter variable is args
# Used max() in-built function
def largest_num(*args):
    print(max(args))

# Calling the largest_num method
largest_num(-20, -10, 0, 10, 100,200)

print("**********************************")

def largest_num1(*args):
    return(max(args))

# Calling the largest_num method and the returned value is put to variable a
# Used max() in-built function
a = largest_num1(-20, -10, 0, 10, 100,300)
print(a)

print("**********************************")

# Used min() in-built function
def smallest_num(*args):
    print(min(args))

# Calling the smallest_num method
smallest_num(-20, -10, 0, 10, 100)

print("**********************************")

def abs_function(a):
    print(abs(a))

# Prints 20 as +20 is 20 units from 0
abs_function(-20.0)
# Prints 20 as -20 is 20 units from 0
abs_function(20)

print("**********************************")

print(type(99))
print(type(99.9))
print(type("99.9"))
l = [1, 2, 3]
print(type(l))
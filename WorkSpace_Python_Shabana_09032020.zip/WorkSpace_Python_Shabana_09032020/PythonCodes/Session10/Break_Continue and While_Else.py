"""
1) Break can be used with the WHILE loop
2) Break will break the loop .
3) After breaking the while loop the codes outside of While lop would be executed after BREAK

"""

a = 0
while a<=10:
    print("value of a is ",a) # 0 ,1,2,3,4 ,5,6,7
    a = a+1; #1,2,3,4,5,6,7,8
    if(a==8):
        print("Codes will be executed as value of a is 8")
        break
        print("These codes after BREAK will never be executed for any value of a defined by a<=10")
    print("This will be printed until the value of a is 7. The moment value of a is 8 defined by a = a+1, this line will not be printed ")
print("After breaking the loop, this line will be printed")


print("**********************************************************************")

# To get the car for servicing only if the brand is SUZUKI

listVar = ["Suzuki", "Honda", "Fiat", "Hummer"]
lenList = len(listVar)
x = 0
while(x<lenList):
    y = listVar[x]
    if y=="Hummer":
        print("Take ", y, "for servicing")
        break
        print (y)
    x+=1
print(y) # Honda


print("**********************************************************************")

"""
1) CONTINUE can be used with the WHILE loop
2) CONTINUE will continue the loop, it continues with the loop
3) CONTINUE after finishing the loop will execute the line outside the WHILE looop

"""

b =1
while b<=10:
    print("value of b is ",b) #1,2,3,4,5,6,7,8,9,10
    b = b+1; #2,3,4,5,6,7,8,9,10,11
    if(b==8):
        print("Codes will be executed as value of b is 8")
        continue
        print("These codes after CONTINUE will never be executed for any value of b defined by b<=10")
    print("This will be printed for all value of b except 8 (i.e. when value of b = b+1 equals 8) ")
print("After looping is over, this line will be printed")


print("**********************************************************************")

"""
1) ELSE used with WHILE loop
2) ELSE part will be executed whether the condition in WHILE is TRUE or FALSE
3) ELSE part will not execute only when BREAK is used with WHILE
"""

# ELSE in WHILE without BREAK
c = 0
while c<=10:
    print("value of c is ",c) #0,1,2,3,4,5,6,7,8,9,10
    c = c+1; # 1,2,3,4,5,6,7,8,9,1,11
    print("This will be printed as the code is part of body of WHILE")
else:
    print("This part of ELSE will be printed irrespective of the condition in WHILE is TRUE or FALSE")

print("**********************************************************************")


# ELSE in WHILE with BREAK
d =0
while d<=10:
    print("value of d is ",d) #0,1,2,3,4,5,6,7
    d = d+1; #1,2,3,4,5,6,7,8
    if(d==8):
        print("Codes will be executed as value of d is 8")
        break
        print("These codes after BREAK will never be executed for any value of a defined by d<=10")
    print("This will be printed as the code is part of body of WHILE")
else:
    print("This part of ELSE will be never be printed as BREAK is present")
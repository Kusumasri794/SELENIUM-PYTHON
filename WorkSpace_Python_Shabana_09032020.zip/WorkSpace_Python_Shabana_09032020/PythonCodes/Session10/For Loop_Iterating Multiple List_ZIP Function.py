"""
1) For iterating with multiple list at same time, We can use the ZIP function with FOR loop
2) Number of list should be equal to number of iterator variables
3) IF list have uneven items, then the shorter list is considered for iterating

"""

"""To iterate over two list have uneven items - iterating will happen only three times as l1 is a shorter list containing three items"""
l1 = [1,2,3]
l2 = [6,7,8,9,10,20]
l3 = zip(l1,l2)
print(type(l3))
print(l3)

# Looking at the number items in a particular list , the FOR loop will run
# We can understand that list l1 has less items, so the FOR loop will run three times only
# Number of iterative variable is equal to number of lists
for a,b in zip(l1, l2):
    print(a) # list l1 --> 1,2,3
    print(b) # list l2 --> 6,7,8

print("*"*40)
"""To iterate over two list have even items"""
l3 = [1,2,3]
l4 = [10,20,30]
for a1,b1 in zip(l3, l4):
    if(a1>b1):
        print (a1)
    else:
        print(b1) # 10,20,30

print("*"*40)
"""To iterate over three list have odd items"""
l5 = [1,2,3,4,5]
l6 = [10,20,30,40]
l7 = [100,200,300,400]
for a2,b2,c2 in zip(l5,l6,l7):
    print(a2)
    print(b2)
    print(c2)

print("*"*40)
# Zip function works over tuple
"""To iterate over two tuple have odd items"""
tup1 = (12,14,16)
tup2 = (120,14,160,180)
for a3,b3 in zip(tup1, tup2):
    print(a3)
    print(b3)
    if(a3%2 == 0):
        print(a3, "is an even number" )
    else:
        print(a3, "is an odd number")


print("*"*40)
# Zip function works over dictionary
"""To iterate over two tuple have odd items"""
dict1 = {"one":1, "two":2, "three":3}
dict2 = {"name":"Kaushik","Age": 45}
for a4,b4 in zip(dict1,dict2):
    print(a4,"-",dict1[a4])
    print(b4,"-",dict2[b4])


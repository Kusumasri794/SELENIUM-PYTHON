"""
1) FOR loop is used to execute statements repeatedly
2) Conditions are used to stop the execution of loops
3) Iterable items are Range, Strings, List, Tuple, Dictionary
"""

"""Range Function"""

# Below line will be printed in console as it is
print (range(1,100))

a = range(1,100)
# Below line will be printed in console as "range(1,100)"
print(type(a))
print(a)

# Below line will be printed as the RANGE is casted with LIST
a1 = list(range(0,10))
print(a1)
print(list(range(0,10)))

# Range Function --. The end argument is defined
print(list(range(10)))

print("*"*40)

# Range can be used in FOR loop
# The first argument of RANGE is inclusive and the second argument is exclusive
"""To print the first hundred numbers"""
for b in range(1, 101):
    # Will print from 1 till 100
    print(b)

print("*"*40)

"""To print alternate numbers between 1 till 100"""
for c in range(1,101,3): #1,3,5,7,9
    # TO print 1,3,5,7....97,99 ..the third argument of range is 2--> steps of 2
    print(c)


print("*"*40)


"""To print addition of first hundred numbers"""
# 1+2+3+4+....+100 = ? sum
sum = 0
for d in range(1,101):
    #print(d,",", end='')
    print("Value of d is ",d) #1,2 ,3 ,4, 5, 6....100
    sum = sum+d #  1 = 0+1 , sum = 1+2 = 3, sum = 3+3 = 6 , sum = 6+4 = 10 sum = 10+5 = 15, sum = 15+6 = 21.......sum = sum+100
    print("Summation value is ", sum) # 1,3, 6, 10, 15, 21 ...sum
print("Final value of Summation value is ", sum) # 1,3, 6, 10, 15, 21 ...sum


print("*"*40)


"""To print multiplication of first hundred numbers"""
# 1*2*3*4...*100 =? (mul)
mul = 1
for e in range(1,101):
    #print(d,",", end='')
    print("Value of e is ",e)
    mul  = mul*e
    print("Multiplication value is ", mul)
print("Final Multiplication value is ", mul)

print("*"*40)


"""To print from String"""
my_string = "Hi! We are learning python"
for f in my_string:
    # Will iterate through each character in a string
    print(f)

print("*"*40)

"""To print a replaced character from a String i.e replace a by A in the String"""
my_string1 = "abcabc"
for g in my_string1:
    if(g=='a'):
        print('A', end='') #AbcAbc
    else:
        print(g, end = '')
print()

print("*"*40)

"""To work with LIST--> To print all items in the LIST"""
cars = ['BMW', 'Suzuki', 'Audi']
for h in cars:
    # To print value in the car LIST one by one
    # print(h)
    # To print the character at first index of individual items i.e. W in BMW, U in Suzuki, U in Audi
    # print(h[1])
    # To print the character from firsy index to last of individual items
    print(h[1:])


print("*"*40)

"""To work with LIST--> To multiple by 100 all items in the LIST"""
nums = [1, 2, 3]
for i in nums:
    # To print the mulplied number
    print(i*100)


print("*"*40)

"""To work with DICTIONARY -> To print the value of the keys present in Dictionary for each iteration (First way)"""
model = {"Audi":"550i" , "Suzuki":"1000cc"}
for j in model: # j is the KEY
    # To print the value of the keys present in Dictionary for each iteration
    print(j +" "+str(model[j]))


print("*"*40)

"""To work with DICTIONARY -> To print the value of the keys present in Dictionary for each iteration (Second way)"""
model1 = {"Audi":"550i" , "Suzuki":"1000cc"}
for k,l in model1.items():
    # To print the keys-value in each iteration
    print(k," ",l) # Key - value



print("*"*40)

"""To work with Tuple"""
nums2 = (1, 2, 3)
for i in nums2:
    # To print all items in a Tuple
    print(i)




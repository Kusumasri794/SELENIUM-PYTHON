"""
Order of precedence or hierarchy for boolean operators:
1. not
2. and
3. or

not>and>or

a) The highest hierarchy based boolean operator will be compiler first in a expression.
b) If we have an expression with same boolean operator, then compilation will be done left to right as it normally happens.
c) If an expression has parenthesis, the operation in the parenthesis will be dealt first. Operation inside parenthesis
will be dealt based on the hierarchy of boolean operators used inside the parenthesis

"""

bool_output = True or not False and False
# Analysis of above based on Boolean Precedence
# not False --> True
# True or True and False
# True and False --> False
# True or False
# True
print(bool_output)

bool_output_1 = (10 == 10 or not 10 > 10) and 10 > 10
# Analysis of above based on Boolean Precedence
# (10 == 10 or not 10 > 10)
# not 10 > 10 --> True
# (10 == 10 or True)
# 10 == 10  --> True
#(True or True) --> True
# True and 10 > 10
#  10 > 10 --> False
# True and False --> False
print(bool_output_1)


bool_output_2 = 10 == 10 and 10 > 10 and 10 > 10
print(bool_output_2)
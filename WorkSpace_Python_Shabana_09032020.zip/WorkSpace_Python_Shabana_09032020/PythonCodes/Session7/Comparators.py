"""
Comparative Operators:
== --> Value Equality
!= --> Not equal to
< --> Less than
> --> Greater than
<= --> Less than OR equal to
>= --> Greater than OR equal to


Result will be boolean TRUE or FALSE
"""

# Equality Operator
bool_one = 10 == 11
print(bool_one) #False

# No Equal to Operator
not_equal = 10 != 11
print(not_equal)

# Less than Operator
less_than = 10 < 11
print(less_than)

# Greater than Operator
greater_than = 1.0 > 9
print(greater_than)

# Less than OR equal to Operator
lt_eq = 10 <= 10
print(lt_eq)

# Greater than OR equal to Operator
gt_eq = 10 >= 11 - 1
print (gt_eq)


# NOTE -> String are compared by taking UNICODE VALUE of each character.
# Apply EQUALITY SIGN and NOT EQUAL TO SIGN for String comparison
str_cmp1 = "hi! how about you" == "hi! how about you "
print(str_cmp1)

str_cmp2 = "hi!how about you" != "hi!how about you"
print(str_cmp2)

#Other Comparitibve operators for string
str1 = "Hi!"
str2 = "Hi!"
bool_Value = str1>str2
print(bool_Value)

bool_value1 = str1>=str2
print(bool_value1)
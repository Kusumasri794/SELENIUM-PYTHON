# test_class3.py file and test_class4.py file as part of the TEST SUITE
# Test Suite is a collection of TEST CASES

# 1) First Import the class files
import unittest
from unitTestPackage.test_class3 import TestClass3
from unitTestPackage.test_class4 import TestClass4


# 2) Get all tests as part of the suite
tc1 = unittest.TestLoader().loadTestsFromTestCase(TestClass3)
tc2  = unittest.TestLoader().loadTestsFromTestCase(TestClass4)

# 3) Create the TEST SUITE
smokeTest = unittest.TestSuite([tc1, tc2])

# 4) Use the runner
unittest.TextTestRunner(verbosity=2).run(smokeTest)


import unittest


class TestClass2(unittest.TestCase):


    # Test Fixture at Test Case level
    # TEst Fixture can be defined from setUp level and tearDown level
    #  setUp level and tearDown level are nothing but methods.
    # setUp level and tearDown level should be created once in the class file
    # setUp method will run before each test case
    # tearDown method will run after each test case.
    # if there are three test cases, setUp and tearDown method will run three times;but before and after each test case
    # We can give the setUPO and tearDown process anywhere

    def setUp(self):
        print("*"*20)
        print("This will run before each test case")
        print("*" * 20)

    def tearDown(self):
        print("*" * 20)
        print("This will run after each test case")
        print("*" * 20)


    def test_methodA(self):
        print("This is the first test case 'test_methodA' in the class file TestClass2")

    def test_methodB(self):
        print("This is the second  test case 'test_methodB' in the class file TestClass2")




# We need to create an object
if __name__ == '__main__':
    unittest.main(verbosity=2)

import unittest


class TestClass3(unittest.TestCase):

    # Test Fixture at Class level
    # TEst Fixture can be defined from setUpClass level and tearDownClass level
    #  setUpClass level and tearDownClass level are nothing but methods.
    # setUpClass level and tearDownClass level should be created once in the class file
    # setUpClass method will run before the class file
    # tearDownClass method will run after the class file
    # For text fixture at class level, we need to use the decorator @classmethod before the setUpClass level method and before the tearDownClass level method
    # We can give the setUpClass and tearDownClass process anywhere

    @classmethod
    def setUpClass(self):
        print("*" * 20)
        print("This will run before the class file 'TestClass3'.")
        print("*" * 20)


    def setUp(self):
        print("*"*20)
        print("This will run before each test case - TestClass3")
        print("*" * 20)

    def tearDown(self):
        print("*" * 20)
        print("This will run after each test case - TestClass3")
        print("*" * 20)


    def test_methodA(self):
        print("This is the first test case 'test_methodA' in the class file TestClass3")

    def test_methodB(self):
        print("This is the second  test case 'test_methodB' in the class file TestClass3")

    @classmethod
    def tearDownClass(self):
        print("*" * 20)
        print("This will run after the class file 'TestClass3'.")
        print("*" * 20)


# We need to create an object
if __name__ == '__main__':
    unittest.main(verbosity=2)
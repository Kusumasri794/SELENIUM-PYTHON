# We need to import the unittest package in order to work with it
import unittest

# The class " TestClass1" has to inherit the TestCase CLASS of unit test framework
class TestClass1(unittest.TestCase):
    # Create the Test Case
    # It should a function.
    # The function name should start with the term "test"
    # It the test case function name does not start with the word "test" , unit test framework, will not recognise it as a TEST CASE
    # We can have "n" number of ytest cases in a class file , but each test case should be a function and should have the term / word "test:.
    # The test cases will run based on alphabetical order
    def test_methodA(self):
        print("This is the first test case 'test_methodA' in the class file TestClass1")

    def test_methodB(self):
        print("This is the second  test case 'test_methodB' in the class file TestClass1")

# We need to create an object
# The below is the first way to create an object
#t = TestClass1()
# The second way to create an object of the class file is as below:
if __name__ == '__main__':
    unittest.main(verbosity=2)

# You only have 3 different levels of verbosity:
#
# 0 (quiet): you just get the total numbers of tests executed and the global result
# 1 (default): you get the same plus a dot for every successful test or a F for every failure
# 2 (verbose): you get the help string of every test and the result

# Ways to run:
# 1)Class level running "TestClass1" --> place  the cursor at the class level so that it blinks
# 2)Test  case  level running either from "test_methodA" or "test_methodB" --> place  the cursor at the Test case  level so that it blinks
# 3)Running from the OBJECT LEVEL


# We can run from command prompt of windows:
    # For that we need to do environment variable settings.
    # Take the path until the project. Do not take the path of the package or python files inside packages
    # If we take the path of the package or python files inside packages, it will give errors
    # Our Project is --> PythonCodes. Take the path "C:\Users\lenovo\Desktop\WorkSpace_Python_09032020\PythonCodes"
    # PUT THE ABOVE PATH IN PYTHONPATH EXISTING VARIABLE OF SYSTEM VARIABLE
    # CROSS VERIFY THAT IN THE EXISTING PATH VARIAABLE , WE HAVE %PYTHONPATH SET.
# Open the command prompt in admin mode and change the directory to the project "PythonCodes"

# To run the test_class1.py from unitTestPackage package --> fire the command:
#     python unitTestPackage/test_class1.py
# If we have PYTHON 2 in our system, then run the below command:
#      python3 unitTestPackage/test_class1.py


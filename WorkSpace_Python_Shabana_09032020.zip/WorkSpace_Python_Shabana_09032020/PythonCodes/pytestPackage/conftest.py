"""
1 pytest framework gives a procedure where we can keep the common SET UP and TEAR DOWN process at test case level
or SET UP and TEAR DOWN process at module(python file) in a file called as "CONFTEST"
2. CONFTEST is a python file which will have commenon set up and tear down at test case level or module level


"""

"""
Let's say that the set up and tear down process for test_demo_class4.py and test_demo_class5.py python files are same.

We create a "conftest" python file for it.

Scoping for yield fixure--> https://docs.pytest.org/en/latest/fixture.html
"""

import pytest

# USe the decorator to make it as Test Fixture for Set up and tear down
# Fixture to run before the test case level and after the test case level
@pytest.yield_fixture()
def SetUp():
    print("Run before each test method")
    yield
    print("Run after each test method")


# Fixture to run bfroe the module or after the module
# In scope session > module > class, in terms of hierarchy
# The fixture "browser" is read in OneTimeSetUp ficture which work one time before and after the session
@pytest.yield_fixture(scope="session")
def OneTimeSetUp(browser):
    print("Run one time before the sesison")
    if browser == "firefox":
        print("Open the firefox browser")
    else:
        print("Open the Chrome browser")
    yield
    print("Run one time after the session")
    if browser == "firefox":
        print("Close the firefox browser")
    else:
        print("Close the Chrome browser")

# To add option--> the option/argument will be added. The argument is "browser".
# in this method, we can declare what arguments/options we want to add.
# We can add more than one argument and these argument can be passed in command line prompt.
def pytest_addoption(parser):
    # First option for browser
    parser.addoption("--browser")
    # Second option for osType
    parser.addoption("--osType", help = "Type of Operating System")

# Then we need to get the value of the argument . If the value of the argument "browser" is "firefox", this value has to be returned so that the pytest  understand it.
# Based on the argument , create a fixture
# Read these fixtures inside another fixture  -  will read it in OneTimeSetUp fixture which is scoped at session level
# Define the same scope as defined for ONE TIME SETUP fixture
@pytest.fixture(scope = "session")
def browser(request):
    # Return the value of the option called browser so that pytest understands it
    return request.config.getoption("--browser")

# Read these fixtures inside another fixture  -  will read it in OneTimeSetUp fixture which is scoped at session level
# Define the same scope as defined for ONE TIME SETUP fixture
@pytest.fixture(scope = "session")
def osType(request):
    # Return the value of the option called osType so that pytest understands it
    return request.config.getoption("--osType")
"""
Pytest Naming Conventions:

When using pytest, it is very important to follow naming conventions.

If we don't follow naming conventions, then pytest will not pick up tests from the file.

1)File names should start or end with “test”, as in test_example.py or example_test.py
2)Class name should start with “Test”, as in TestExample
3)Test case method names should start with “test_”, as in test_example

You can refer to the official documentation for more details:
http://pytest.readthedocs.io/en/reorganize-docs/new-docs/user/naming_conventions.html

NOTE: Install pytest with the PIP: pip install pytest

"""

# Start creating the test case with the class file
# Not compulsory to create a class file
# We can have "n" number of test cases in a python file or class file

"""
Run 1) From inside the package: pytestPackage
a) py.test test_demo_class1.py - there is no print out 
b) py.test -v -s test_demo_class1.py  -> To define verbosity by flag -v and print out by flag -s

Run 2) From inside the project: PythonCodes
a) py.test pytestPackage/test_demo_class1.py - there is no print out 
b) py.test -v -s pytestPackage/test_demo_class1.py  -> To define verbosity by flag -v and print out by flag -s

"""

import pytest

def test_methodA():
    print("Running test case test_methodA of test_demo_class1 python file/module")

def test_methodB():
    print("Running test case test_methodB of test_demo_class1 python file/module")




# Set and tear down at test case level
# The setup and tear down method can have any name
# Set up and tear down has to be created once in a python file/class file
# Set up and tear down will run as many times as the number of test cases.
# Set up will run before the test case and tear down will run after the test case
# Set up and tear down will be part of Test Fixture

"""
Run 1) From inside the package: pytestPackage
a) py.test test_demo_class3.py - there is no print out
b) py.test -v -s test_demo_class3.py  -> To define verbosity by flag -v and print out by flag -s

Run 2) From inside the project: PythonCodes
a) py.test pytestPackage/test_demo_class3.py - there is no print out
b) py.test -v -s pytestPackage/test_demo_class3.py  -> To define verbosity by flag -v and print out by flag -s

"""

import pytest


# USe the decorator to make it as Test Fixture for Set up and tear down
@pytest.yield_fixture()
def SetUp():
    print("*"*10)
    print("This will run before the test case")
    yield
    # After YIELD keyword , whatever we write down , will be part of tear down process at the TEST CASE METHOD level
    print("*" * 10)
    print("This will run after the test case")


# Define the Set up method name with the test case as an argument of TEST CASE method
def test_methodA(SetUp):
    print("Running test case test_methodA of test_demo_class3 python file/module")

def test_methodB(SetUp):
    print("Running test case test_methodB of test_demo_class3 python file/module")
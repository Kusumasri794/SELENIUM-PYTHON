# Actually it runs from top to down i.e. compilation is from top to down
# For running it in the order in which we want to run, we need to first download the ordering package.
# Fire the command from command line prompt --> pip install pytest-ordering
# After installation of the packega, use the fixture for each test case method --> @pytest.mark.run(order = 1)
# pytest ordering documentation --> https://pytest-ordering.readthedocs.io/en/develop/
# Using conftest2.py.. Before using it change conftest2.py to conftest.py


import pytest


# Run order will be A, B, C, D, E, F

@pytest.mark.run(order = 1)
def test_methodA(OneTimeSetUp,SetUp):
    print("Running test case test_methodA of test_run_order_demo python file/module")

@pytest.mark.run(order = 2)
def test_methodC(OneTimeSetUp,SetUp):
    print("Running test case test_methodC of test_run_order_demo python file/module")

@pytest.mark.run(order = 4)
def test_methodD(OneTimeSetUp,SetUp):
    print("Running test case test_methodD of test_run_order_demo python file/module")

@pytest.mark.run(order = 5)
def test_methodE(OneTimeSetUp,SetUp):
    print("Running test case test_methodE of test_run_order_demo python file/module")

@pytest.mark.run(order = 6)
def test_methodF(OneTimeSetUp, SetUp):
    print("Running test case test_methodF of test_run_order_demo python file/module")

@pytest.mark.run(order = 3)
def test_methodB(OneTimeSetUp,SetUp):
    print("Running test case test_methodB of test_run_order_demo python file/module")
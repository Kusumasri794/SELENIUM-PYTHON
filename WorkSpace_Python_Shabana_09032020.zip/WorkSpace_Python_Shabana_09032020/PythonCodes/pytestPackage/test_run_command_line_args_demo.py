# Based on the comand line argument value the code will run.

# Now let's say , we will run the below test cases methods on a specific browser. Now browser is taken as a hypothetical analysis
# We want to run the below test cases on firefox as well as in chrome browser. At session level, we have one tiem set up and one time tear down
#In conftest, one time set up function ,  We need to create codes  so that we can work the firefox browser as well as with chrome browser and run the below test cases
# Whether we want to run the below test cases on Firefox or chrome , it will be decided by the argument value that we pass on the command prompt
# For doing the above, we need to add option . The option/argument will be added. The argument is "browser".
# Then we need to get the value of the argument . If the value of the argument "browser" is "firefox", this value has to be returned so that the pytest  understand it.


"""
With argument as browser and value as firefox, open the command line prompt and fire the command:

py.test -v -s test_run_command_line_args_demo.py --browser firefox


With argument as browser and value as chrome, open the command line prompt and fire the command:

py.test -v -s test_run_command_line_args_demo.py --browser chrome

"""

"""
1)For getting HTML reports , download and install the package: pip install pytest-html

2) Open the command line prompt and fire the command :
# Will create the report in the current module
py.test -v -s test_run_command_line_args_demo.py --browser chrome --html=report.html

# Will create the report in the a differnt path :
py.test -v -s test_run_command_line_args_demo.py --browser chrome --html=c:/Desktop/report.html
"""



def test_command_line_args_methodA(OneTimeSetUp,SetUp):
    print("Running test case test_methodA of test_run_command_line_args_demo python file/module")
    assert 3==4

def test_command_line_args_methodB(OneTimeSetUp,SetUp):
    print("Running test case test_methodB of test_run_command_line_args_demo python file/module")
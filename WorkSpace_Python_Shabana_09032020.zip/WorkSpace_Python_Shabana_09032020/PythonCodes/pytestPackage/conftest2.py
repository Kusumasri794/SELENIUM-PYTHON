"""
1 pytest framework gives a procedure where we can keep the common SET UP and TEAR DOWN process at test case level
or SET UP and TEAR DOWN process at module(python file) in a file called as "CONFTEST"
2. CONFTEST is a python file which will have commenon set up and tear down at test case level or module level


"""

"""
Let's say that the set up and tear down process for test_demo_class4.py and test_demo_class5.py python files are same.

We create a "conftest" python file for it.

Scoping for yield fixure--> https://docs.pytest.org/en/latest/fixture.html
"""

import pytest

# USe the decorator to make it as Test Fixture for Set up and tear down
# Fixture to run before the test case level and after the test case level
@pytest.yield_fixture()
def SetUp():
    print("Run before each test method")
    yield
    print("Run after each test method")


# Fixture to run bfroe the module or after the module
@pytest.yield_fixture(scope="module")
def OneTimeSetUp():
    print("Run one time before the module")
    yield
    print("Run one time after the module")
"""
Usage of while loop for Strings, List, Tuple and Dictionary
"""

# String usage - Run the while loop as the number of characters in the string
str1 = "Hi! Learning Python"
# To get the number of characters in the string variable
lenStr = len(str1)
print("Length of the String:",lenStr)
# Let the variable represent the index number
a = 0
while(a<lenStr):
    print(str1[a])
    a+=1


print("*"*10)
# List Usage - Run the while loop as the number of items in the LIST
list1 = ["Mickey Mouse", "Donald Duck", "Minnie Mouse"]
# To get the number of items in the list variable
lenList = len(list1)
print("Length of the List:",lenList)
# Let the variable represent the index number
b = 0
while(b<lenList):
    print(list1[b])
    b+=1

print("*"*10)
# Dictionary Usage - Run the while loop as the number of KEY-VALUE in the DICTIONARY
dict1 = {"Name":"Sam", "Age":26, "Address": "Bangalore"}
# To get the number of KEY-VALUEpairs in the dictionary variable
lenDict = len(dict1)
print("Length of the dictionaryt:",lenDict)
x = dict1["Name"]
print(x)
y = dict1.items()
print(y)


# z1,z2 = dict1.keys(),dict1.values()
# print(z1,z2)
y=1
z = len(dict1)
print(z)
while y<=z:
    print(dict1.keys())
    print(dict1.values())
    t = dict1.get("Name")
    print(t)
    break
    y +=1



print("*"*10)
# Tupe Usage - Run the while loop as the number of items in the TUPLE
tup1 = (10,20,30)
# To get the number of items in the tuple variable
lenTuple = len(tup1)
print("Length of the Tuple:",lenTuple)
# Let the variable represent the index number
w = 0
while(w<lenTuple):
    print(tup1[w])
    w+=1





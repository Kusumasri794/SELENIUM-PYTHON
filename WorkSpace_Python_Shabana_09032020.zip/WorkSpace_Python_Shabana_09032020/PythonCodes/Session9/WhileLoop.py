"""
1) While loop is used to execute statements/snippets of codes repeatedly inside the while body
2) Conditions are used to stop the execution of loops or continue the loop execution
3) Iterable items are Strings, List, Tuple, Dictionary - while loops can be used to iterate over strings, list, tuple, dictionary

Working Behaviour:

1) The WHILE loop will have boolean arguments:
a If the boolean arguments id TRUE, the body of WHILE loop will get executed
b) If the boolean argument is FALSE, the WHIlE loop body does not get executed.

NOTE: Important to understand that we should not have infinite loopes . Infinite loops take system resorces like memory space and hangs the system. So we need to
get the desired results from the loop and stop it when required. Stopping a loop will be dependent on :
a) Boolean argument,
b)initial value and
c)increment / decrement sentence

SYNTAX:

initital value
while (argument - boolean):
    # Body of while
    increment or decrement sentence

"""

# To print out number in reverse order from 100 to 1
a = 100 # Initial value
while a>=1:  # Conditional Statement
    print(a)
    a = a-1  # Increment/Decrement statement

print("*"*20)

# Infinite looping
# b = 100 # Initial value
# while b<101:  # Conditional Statement bad as the boolean result always remain TRUE
#     print(b)
#     b = b-1  # Increment/Decrement statement


print("*"*20)

# Infinite looping
# c = 100 # Initial value
# while c>=1:  # Conditional Statement
#     print(c)
#     c = c+1  # Increment / Decrement statement wrong


print("*"*20)

# Abrupt stoppage without getting the desired result
d = 101 # Initial value which is wrong
while d>=100:  # Conditional Statement
    print(d)
    d = d-1  # Increment / Decrement

print("*"*20)
e = 100 # Initial value
while e>0:  # Conditional Statement changed but gives the desired result
    print(e)
    e = e-1  # Increment/Decrement statement


print("*"*20)
# To execute multiple of 5 until 200
# The number should be divisible by 5
f = 1
while(f<=200):
    if(f%5 == 0):
        print(f,"is a multiple of 5")
    f+=1 # Compound statement --> f+=1 --> f = f+1

print("*"*20)
# To execute all number from 1000 to 1 which are divisible by 2 and 5
g = 1000
while(g>0):
    if((g%2 ==0) and (g%5 ==0)):
        print(g, "is a multiple of 2 and 5")
    g -= 1  # Compound statement --> g-=1 --> g = g-1







from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class Xpath():
    def CustomisedXpath(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://www.google.com/")
        time.sleep(10)
        # Type on Google Edit box - Customised XPATH
        # Compound Class Value are not supported by CLASSNAME locating strategy - will show NO SUCH ELEMENT EXCEPTION
        #driver.find_element(By.CLASS_NAME, "gLFyf gsfi").send_keys("Selenium")

        # driver.find_element(By.XPATH, "//*[@class = 'gLFyf gsfi']").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//input[@name = 'q']").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//input[@type = 'text']").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//input[@spellcheck = 'false']").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//div[@class = 'a4bIc']/input").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//div[@class = 'a4bIc']/input[1]").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//div[@class = 'SDkEP']/div[2]/input").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//div[@class = 'SDkEP']/div[2]/input[1]").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//div[@class = 'RNNXgb']/div/div[2]/input").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//form[@id='tsf']/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]").send_keys("Selenium")
        # driver.find_element(By.XPATH, "//div[@id='viewport']/div[3]/form[1]/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]").send_keys("Selenium")

        # Full XPath
        driver.find_element(By.XPATH,"html/body[1]/div[1]/div[3]/form[1]/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]").send_keys("Selenium")

        time.sleep(5)

        # 1') USe KEYS class to get links pertaining to the Keyword  - Using the Keys class RETURN FUCNTIOn tot be utilised on the Google Edit box only
        driver.find_element(By.XPATH, "//*[@class = 'gLFyf gsfi']").send_keys(Keys.ENTER)

        #2) Click on Google Search Button
        # addressGoogleButton = driver.find_element(By.XPATH,"//*[@id='tsf']/div[2]/div[1]/div[3]/center/input[1]")
        # addressGoogleButton.click()


        time.sleep(10)

        # Close the browser
        driver.quit()

x1 = Xpath()
x1.CustomisedXpath()
class Some_Test_Class():
    def __init__(self, value):
        self.value = value

    def sumNumber(self, a, b):
        return a+b+self.value


# s1 = Some_Test_Class(10)
# a = s1.sumNumber(10,20)
# print(a)

import pytest
from pytestPackage1.someTestClass import Some_Test_Class


"""
1)IF we have "n" number of test cases with their methods and all of them wants to use the OneTimeSetUp & SetUp procedures, it is cumbersome so 
we can use the fixture at class level 

2) The fixture will be @pytest.mark.usefixtures("OneTimeSetUp", "SetUp")

3) Using the above fixture will make the OneTimeSetUp & SetUp procedures available to all test case methods

4) In the conftest file change the scope to class for ONETIMESETUP and the BROWSER , OSTYPE fixtures

4) no need to create objects of the class to run the file. Run it from command line

py.test -v -s test_class_Demo.py --browser firefox
"""

"""
q) How to use test class to wrap methods under one class
b) Learn about autouse keywords in fixtures
c) Assert the result to create a real test scenario

1)We can create an object of Some_Test_Class class inside the method test_MethodA and test_MethodB of Test_Class. For this 
we need to import "Some_Test_Class".
2) IF we have "n" number oif test case methods and in each test case method, we need to create objects of Some_Test_Class
, it is done as below in line number 37,38,42,43. This is cumbersonme  and it is a good behaviour to use create A FIXTURE.
This fixture will make the instance of Some_Test_Class class available to all  test case methods . The scope of this fixture 
is inside the class and wherever we use. the class

@pytest.fixture(autouse = True)


ASSETTION in PYETEST can be used automatically without using the self argument.

"""



@pytest.mark.usefixtures("OneTimeSetUp", "SetUp")
class Test_Class():

    @pytest.fixture(autouse = True)
    def classSetUp(self):
        self.abc = Some_Test_Class(10)

    def test_MethodA(self):
        # self.abc = Some_Test_Class(10)
        # self.abc.sumNumber(10,20)
        print("Running the first test case.")
        result = self.abc.sumNumber(10,20)
        print(result)
        assert result==40
        print("printing after assertion")



    def test_MethodB(self):
        # self.abc = Some_Test_Class(10)
        # self.abc.sumNumber(10, 20)
        print("Running the second test case.")
        result1 = self.abc.sumNumber(20,20)
        print(result1)
        assert result1 == 40
        print("printing after assertion")
"""
1) Frame is a hiiden componenet and cannot be seent with eyes like we see edit box, button ,etc.
2) Frame is a web page embedded inside another web page.
3) They are created by iframe.
4) If we want to work with elements/control/UI present inside the frame, we need to switch to the frame from the web page
5) By default , Selenium will have focus on te web page which Selenium opens. In order to work with elements inside a
frame, we need to switch focus of Selenium from web page in which Selenium is active to the frame. If we want to work with elements
present in web page again, we again need to switch focus from frame to web page.
6) Three ways to switch to the frame:
    a) By the address of the frame - we can get address by any of ghe eight different locating strategies.
    b) By the id attribute or name attribute present in the HTML script of the frame.
    c) By the index number of the frame. Index number starts with zero

"""
from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.action_chains import ActionChains

class FramesActionsChain():
    def WorkingActionChainFrames(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://jqueryui.com/draggable/")
        time.sleep(10)
        #  no such element: Unable to locate element: {"method":"xpath","selector":"//*[@id='draggable']"} for line 37
        # No such element crops up : a) locator value is not correct, b) Desyncronization between script and application and c) when the element is inside frame

        # Switch to frame by the address
        # addressFrame = driver.find_element(By.XPATH, "//*[@id='content']/iframe")
        # driver.switch_to.frame(addressFrame)

        # Switch to frame by the index number
        # First find out how many frames in th webpage
        listOfFrames = driver.find_elements(By.TAG_NAME, "iframe")
        print("Number of frames in the main web oage is", len(listOfFrames))
        # driver.switch_to.frame(0)
        # If we have multiple frames in a web page, then how to drag to specific frame?
        indexVariableFrame = 0
        while indexVariableFrame<len(listOfFrames):
            expectedSource = "https://jqueryui.com/resources/demos/draggable/default.html"
            actualSource = driver.find_element(By.XPATH, "//*[@id='content']/iframe").get_attribute("src")
            print(actualSource)
            if actualSource==expectedSource:
                driver.switch_to.frame(indexVariableFrame)
                time.sleep(3)
            indexVariableFrame = indexVariableFrame+1
        time.sleep(7)

        # Address of DRAG ME AROUND element
        # Move the DRAG ME AROUND element within the boundary
        addressDragElement = driver.find_element(By.XPATH, "//*[@id='draggable']")
        act1 = ActionChains(driver)
        act1.drag_and_drop_by_offset(addressDragElement, 25,25 )
        act1.perform()
        time.sleep(10)

        # Move focus from frame to main page to click on DROPPABLE LINK
        driver.switch_to.default_content()

        # Click on droppable
        driver.find_element(By.CSS_SELECTOR, "#sidebar > aside:nth-child(1) > ul > li:nth-child(2) > a").click()

        time.sleep(10)

        # To drag and drop to speicific area , we need to switch to the frame first
        addFrameDroppable = driver.find_element(By.CSS_SELECTOR, "#content > iframe")
        driver.switch_to.frame(addFrameDroppable)

        # Addres of the Drag Element
        addDragElement = driver.find_element(By.XPATH, "//*[@id='draggable']")
        addDropArea = driver.find_element(By.CSS_SELECTOR, "#droppable")
        # USe Actions Chians class to simulate the movement from Drag to Drop Area
        act2 = ActionChains(driver)
        act2.drag_and_drop(addDragElement, addDropArea)
        time.sleep(10)

        # Move focus from frame to main page
        driver.switch_to.default_content()
        time.sleep(5)

        # Close the browser
        driver.quit()



f1 = FramesActionsChain()
f1.WorkingActionChainFrames()
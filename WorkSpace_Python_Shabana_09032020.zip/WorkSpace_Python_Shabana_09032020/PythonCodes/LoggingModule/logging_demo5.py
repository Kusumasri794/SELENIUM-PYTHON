"""
Uses custom_logger5.py file
"""

import logging
import LoggingModule.custom_logger5 as cl

class LoggingDemo5():

    logger = cl.customLogger(logging.DEBUG)

    def method1(self):
        self.logger.debug('debug message')
        self.logger.info('info message')
        self.logger.warning("Warning message")
        self.logger.error('error message')
        self.logger.critical('critical message')

    def method2(self):
        m2Log = cl.customLogger(logging.INFO)
        m2Log.debug('debug message of method2')
        m2Log.info('info message of method2')
        m2Log.warning('warn message of method2')
        m2Log.error('error message of method2')
        m2Log.critical('critical message of method2')

    def method3(self):
        m3Log = cl.customLogger(logging.INFO)
        m3Log.debug('debug message')
        m3Log.info('info message')
        m3Log.warn('warn message')
        m3Log.error('error message')
        m3Log.critical('critical message')

demo = LoggingDemo5()
demo.method1()
demo.method2()
demo.method3()
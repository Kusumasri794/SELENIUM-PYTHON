"""
Logging Format
https://docs.python.org/3/library/logging.html#logrecord-attributes
https://docs.python.org/3/library/time.html#time.strftime

Format argument:
1) TO change the format of message :format='%(levelname)s: %(message)s'
2) To show Date Time in ascending order with pre-fixed format of log: format = '%(asctime)s:

Date format argument:
1) To have our own format of time: datefmt='%m/%d/%Y %I:%M:%S %p'
%m - month
%d - Date
%Y - Year
%I - Hour in 12 hour format
%H - Hour in 24 hour format
%M - Minutes
%S - Seconds
%p  - for AM or PM




"""
import logging


# logging.basicConfig(format='%(asctime)s: %(levelname)s: %(message)s',level=logging.DEBUG)
# logging.basicConfig(format='%(asctime)s',datefmt='%m/%d/%Y %I:%M:%S %p',level=logging.DEBUG)
# logging.basicConfig(format='%(asctime)s: %(levelname)s',datefmt='%m/%d/%Y %I:%M:%S %p',level=logging.DEBUG)
# logging.basicConfig(format='%(asctime)s: %(levelname)s: %(message)s',datefmt='%m/%d/%Y %I:%M:%S %p',level=logging.DEBUG)
logging.basicConfig(filename = "test1.log" ,format='%(asctime)s: %(levelname)s: %(message)s',datefmt='%m/%d/%Y %I:%M:%S %p',level=logging.DEBUG)
logging.warning("warning message")
logging.info("info message")
logging.error("error message")
"""
Logger Demo

1) The configuration for logging is kept in an external file called as "logging.conf"
"""
import logging
# To support third party configuration file
import logging.config

class LoggerDemoConf():

    def testLog(self):
        # create logger - calling the external logging configuration file
        logging.config.fileConfig('logging.conf')
        logger = logging.getLogger(LoggerDemoConf.__name__)

        # logging messages
        logger.debug('debug message')
        logger.info('info message')
        logger.warning("Warning message")
        logger.error('error message')
        logger.critical('critical message')

demo = LoggerDemoConf()
demo.testLog()
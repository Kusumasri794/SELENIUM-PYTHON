"""
Logger Demo:

Agenda - To print log information in CONsole
"""
import logging

class LoggerDemoConsole():

    def testLog(self):
        # 1) create logger - In getLogger method define the name of the log
        # logger = logging.getLogger('sample_log')
        #Below line will take name of the CLASS
        logger = logging.getLogger(LoggerDemoConsole.__name__)
        # After name, set the level of logger. Logger looks at the message and create log record object from tne message string
        logger.setLevel(logging.INFO)

        # 2) Create console handler and set level to info - Once the logger creates log record object, it will pass it to handlesr
        # Streamhandler writes to CONSOLE
        consoleHandler = logging.StreamHandler()
        # Set the level of console
        # consoleHandler.setLevel(logging.DEBUG)
        consoleHandler.setLevel(logging.INFO)

        # 3) create formatter - Then the handler passes the log record object to the formatter
        # %(name)s - from where the message is coming . Coming from sample_log
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: %(message)s',
                    datefmt='%m/%d/%Y %I:%M:%S %p')

        # 4) add formatter to console handler
        consoleHandler.setFormatter(formatter)

        # 5) add console handler to logger - console handler is responsible for the final message
        logger.addHandler(consoleHandler)

        # logging messages
        logger.debug('debug message')
        logger.info('info message')
        logger.warning("Warning message")
        logger.error('error message')
        logger.critical('critical message')

demo = LoggerDemoConsole()
demo.testLog()
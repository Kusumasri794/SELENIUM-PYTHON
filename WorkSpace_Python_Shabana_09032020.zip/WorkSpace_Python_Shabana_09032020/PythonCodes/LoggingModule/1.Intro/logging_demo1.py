"""
Logging Demo 1
1) Logging Levels are kinds of information we want to write. They are:
DEBUG = Used for detailed information ; for debugging
INFO = Any information which is good like click; acts as confirmation that things are working as expected
WARNING = May happen in future ; some problem occuring in future
ERROR  = Functionality not working or exceptions
CRITICAL = Serious error which makes the app to stop running

2) CRITICAL has the highest hierarchy. By default the logging level is set to WARNING ;
so warning, error and critical will be printed in console .

3) A module called LOGGING is provided by PYTHON

4) baseconfig() is a method in logging having filename where log file can be kept and level can be set
"""




import logging

# By default the logging level is set to warning
# Logging level have function and also variables with the same name
"""
This will not be printed out as by default warning is the level set . Since warning is the level set by default, 
we will get print out for line 22 & 23 which are for warning and critical
"""

# logging.debug("Debugging the application")
# logging.warning("Warning Message")
# logging.critical("Critical massage")




print("************************************************************************************")

""" 
1) For changing the logging level, we can use one of the functions called as baseconfig() . This one of the ways to change the logging level.
Also , we can change the place where we wan to get the logging information. In the above code the log information came in console.
If we want to get the log information in a file , we have to define the path of the file in the baseconfig() function.

2)If the file name is only given , then the log will be generated in that file and this file will be created in the current package

3) Ensure the extension of filename should be log

"""

logging.basicConfig(filename="test.log", level=logging.DEBUG)
logging.warning("warning message")
logging.info("info message")
logging.error("error message")
logging.debug("Debugging the application")
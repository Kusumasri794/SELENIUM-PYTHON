"""
1) Exceptions are errors
2) We should handle exceptions in our code to make sure the code is working the way
we want and is handling all the unwanted issues
3) Link to 3.8.2 built-in exceptions - https://docs.python.org/3/library/exceptions.html
4) In python we have try...except block to handle exceptions
"""
"""
The below code without try..except block will show 'ZeroDivisionError' error. This will not
allow lines below the to execute and no results will be see in console. So we use try....
catch block. The error will be handled and the 'except' block will get executed and the codes
below it
"""

def ArithmaticExpression1():
    a = 10
    b = 20
    c = 2
    d = (a + b) / c
    print(d)

ArithmaticExpression1()

print("************************************************")

# def ArithmaticExpression2():
#     a1 = 10
#     b1 = 20
#     c1 = 0
#     d1 = (a1 + b1) / c1
#     print(d1)
#     print("Important codes")
#
# ArithmaticExpression2()

print("************************************************")

def exceptionHandling():
    try:
        a = 10
        b = 20
        c = 0
        d = (a + b) / c
        print(d)
    except:
        print("In the except block")
    print("Important codes")

exceptionHandling()

print("************************************************")

def exceptionHandling4():
    try:
        a = 10
        b = 20
        c = 2
        d = (a + b) / c
        print(d)
    except:
        print("In the except block")
    print("Important codes")

exceptionHandling4()





print("***************************************************")

"""
Another way to carry out exceptional handling:
The below code without try..except block will show 'TypeError' error. This will not
allow lines below the to execute and no results will be see in console. So we use try....
catch block. The error will be handled and the 'except' block with the print message
'Can't add string to integer'will get executed and the codes below it
"""
def exceptionHandling1():
    try:
        a = 10
        b = 20
        c = 0
        d = (a + b) / c
        print(d)

        e = 10
        f = "Hello"
        g = (e+f)/g
        print(g)
    except ZeroDivisionError:
        print("Zero Division error handled")
    except TypeError:
        print("Type error handled")

exceptionHandling1()



"""
1) Mouse movements, left click, right click (context click), are possible with Selenium using the Actions Chain class.
2) Keys can also simulated using the Actions chain class.
3) Simple classes and methods for clicking or typing cannot be used for simulation purpose and so we need to simulate
using the Actions Chain class.
4) For the simulation to work , it is advisible not to touch the mouse or keypad when the script is running.
5) Action chain class wiccl always find he element at the middle portion of the element.
6) The element has to be visible in the viewport of the browser for the Action chain class to work. Can throw
otherwise no such element error.
7 Action Chain class belongs to selenium.webdriver.common.action_chains package
8) To perform the simulation, use the perform() method. Otherwise simulation will not happen.


"""
from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.action_chains import ActionChains

class AmericanGolf():
    def WorkingActionChain(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://www.americangolf.co.uk/")
        time.sleep(10)
        #Hover the mouse over GolfClubs menu button
        act1 = ActionChains(driver)
        #Address of the Golf Clubs
        addressGolfClubs = driver.find_element(By.LINK_TEXT, "Golf Clubs")
        act1.move_to_element(addressGolfClubs)
        act1.perform()
        # Pause on the hovered element - Golf Clubs
        act1.pause(5)
        time.sleep(6)
        #Simulate the click on the WEDGES Sub-menu button
        act2 = ActionChains(driver)
        addressWegdes = driver.find_element(By.XPATH, "//*[@id='CLUBS_1']/ul/li[2]/ul/li[2]/a")
        act2.move_to_element(addressWegdes).click()
        act2.perform()
        time.sleep(7)
        # Title of the Wedges page
        titlePage = driver.title
        print("Tile of the wedges page is",titlePage)
        # Price before moving the slider
        priceBeforeSliding = driver.find_element(By.XPATH, "//*[@id='secondary']/div[1]/div[7]/div/div/div[2]/div[1]").text
        print("Price before sliding",priceBeforeSliding)
        time.sleep(7)
        #Click on the Cookie statis bar close button
        # driver.find_element(By.XPATH, "//*[@id='wrapper']/div[2]/div[5]/div/div/div[1]/a").click()
        # When Cross button is not present in static bar of Cookie, then we have to scroll the browser and make the element visible
        # Get the left point slider's location - will give X and Y coordinate
        locateLeftPointSlider1 = driver.find_element(By.XPATH,"//*[@id='secondary']/div[1]/div[7]/div/div/div[1]/div/div/div[1]/div").location_once_scrolled_into_view
        print(locateLeftPointSlider1)
        locateLeftPointSlider2 = driver.find_element(By.XPATH,"//*[@id='secondary']/div[1]/div[7]/div/div/div[1]/div/div/div[1]/div").location
        print(locateLeftPointSlider2)
        # For scrolling the browser, we have to use method execute_script and execute_async_script
        # execute_async_script - want to execute asynchronius Javascript - AJAX based script
        # execute_script - want to execute synchronous Javascript
        driver.execute_script("window.scrollTo(0, 1700);", "")
        time.sleep(20)
        # Slide the slider from left to right in x-axis  -Simulation
        act3 = ActionChains(driver)
        addressLeftPointSlider = driver.find_element(By.XPATH, "//*[@id='secondary']/div[1]/div[7]/div/div/div[1]/div/div/div[1]/div")
        act3.drag_and_drop_by_offset(addressLeftPointSlider,25, 0)
        act3.perform()
        time.sleep(7)
        # Price after moving the slider
        priceAfterSliding = driver.find_element(By.XPATH,"//*[@id='secondary']/div[1]/div[7]/div/div/div[2]/div[1]").text
        print("Price after sliding", priceAfterSliding)
        time.sleep(20)
        driver.quit()

a1 = AmericanGolf()
a1.WorkingActionChain()

"""
1) IF ..ELSE is used to define conditional statement
2) We can have only the IF block. Not required to have the ELSE block.
3) IF block always followed by BOOLEAN ARGUMENT
4) But if we only have the IF block , need to understand that result will be thrown out, if the boolean expression in the
argument of IF is TRUE.
5) If there is an ELSE block, it should be preceded by the IF block. We cannot have only ELSE block.
6) We can have NESTED IF ELSE too; which is called as ELIF in PYTHON
7) Nested IF  ELSE is used, when we need to get result for more than two entities.

Working Behaviour:

a) If the argument of IF is boolean TRUE, the IF block body will be executed.
b If the argument of IF is boolean False, the IF block will be ignored by compiler. Then the control of the
compiler will move to ELSE block and execute the body of ELSE block

"""

# To print the highest of two numbers
# a = 100
# b = 600.12
# # Using the IF block only
# if (a>b):
#     print("a is the highest among two numbers and the value is "+str(a))
#     print("a is the highest among two numbers and the value is", a)
#
# # Using the IF ELSE block
# if (a > b):
#     print("a is the highest among two numbers and the value is", a)
# else:
#     print("b is the highest among two numbers and the value is", b)
#
# print("&"*30)
#
# # To check if a number is even and odd
# c = 21
# if (c%2 == 0) :
#     print("c is an even number and the value is ",c)
# else:
#     print("c is an odd number and the value is ", c)

print("&"*30)

# To pick the number from consol of python and then evaluate to even or odd
# print("Enter the number")
# # What ever value we throw out or pick up from console , that is in string format
# d = input()
# print(type(d))
# # Converting the value from string to int
# e = (int)(d)
# print(type(e))
# if (e%2 == 0) :
#     print("e is an even number and the value is ",e)
# else:
#     print("e is an odd number and the value is ", e)
#
# print("&"*30)
# # To issue Pan Card if the age is more than and equal to 18 and less than or eqaul to 85
# print("Enter the age in integer format")
# f = input()
# g = (int)(f)
# if (g>=18 and g <=85):
#     print("Issue the pan card ")
# else:
#     print("Do not issue the pan card ")
#
# print("&"*30)
# # Nested If Else Statement
# # To check the lowest of three numbers
# h = 13.19
# i = 13
# j = 122.0
#
# if(h<i and h<j):
#     print(" h is the lowest among three and the value is", h)
# elif (i<j):
#     print(" i is the lowest among three and the value is", i)
# else:
#     print(" j is the lowest among three and the value is", j)

# print("&"*30)
# # To check the is a number is prime
# print("Enter the number")
# k = input()
# l= (int)(k)
# if(l ==1 ):
#     print(l, "is not a prime number")
# elif(l==2):
#     print(l, "is a prime number")
# elif(l/1 ==l and l/l ==0 ):
#     print(l," is a prime number")
# else:
#     print(l," is not a prime number")



# To take input from the user
# num = int(input("Enter a number: "))

r = range(2,4)
print(type(r))
print(r)
s = list(r)
print(s)


num =2
# prime numbers are greater than 1
if num > 1:
    # check for factors
    for i in range(2, num):
        print(i)
        print(num)
        if (num % i) == 0: # 40
            print(num, "is not a prime number")
            print(i, "times", num // i, "is", num)
            break
    else:
        print(num, "is a prime number")

# if input number is less than
# or equal to 1, it is not prime
else:
    print(num, "is not a prime number")

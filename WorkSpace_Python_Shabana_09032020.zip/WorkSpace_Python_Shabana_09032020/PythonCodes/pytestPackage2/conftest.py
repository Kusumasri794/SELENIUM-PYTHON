
import pytest

# USe the decorator to make it as Test Fixture for Set up and tear down
# Fixture to run before the test case level and after the test case level
@pytest.yield_fixture()
def SetUp():
    print("Run before each test method")
    yield
    print("Run after each test method")


# Fixture to run before the module or after the module
# In scope session > module > class, in terms of hierarchy
# The fixture "browser" is read in OneTimeSetUp ficture which work one time before and after the session
@pytest.yield_fixture(scope="class")
def OneTimeSetUp(request,browser):
    print("Run one time before the class")
    if browser == "firefox":
        print("Open the firefox browser")
    else:
        print("Open the Chrome browser")

    # Pass the value to the object instance of Some_Test_Class
    value = 100
    # the class atrribute of Request is passed on with the value of 100 if it is not empty
    if request.cls is not None:
        request.cls.value = value

    #Return the value of 100 woth yield value
    yield value
    print("Run one time after the class")
    if browser == "firefox":
        print("Close the firefox browser")
    else:
        print("Close the Chrome browser")

# To add option--> the option/argument will be added. The argument is "browser".
# in this method, we can declare what arguments/options we want to add.
# We can add more than one argument and these argument can be passed in command line prompt.
def pytest_addoption(parser):
    # First option for browser
    parser.addoption("--browser")
    # Second option for osType
    parser.addoption("--osType", help = "Type of Operating System")

# Then we need to get the value of the argument . If the value of the argument "browser" is "firefox", this value has to be returned so that the pytest  understand it.
# Based on the argument , create a fixture
# Read these fixtures inside another fixture  -  will read it in OneTimeSetUp fixture which is scoped at session level
# Define the same scope as defined for ONE TIME SETUP fixture
@pytest.fixture(scope = "class")
def browser(request):
    # Return the value of the option called browser so that pytest understands it
    return request.config.getoption("--browser")

# Read these fixtures inside another fixture  -  will read it in OneTimeSetUp fixture which is scoped at session level
# Define the same scope as defined for ONE TIME SETUP fixture
@pytest.fixture(scope = "class")
def osType(request):
    # Return the value of the option called osType so that pytest understands it
    return request.config.getoption("--osType")
import pytest
from pytestPackage2.someTestClass import Some_Test_Class




@pytest.mark.usefixtures("OneTimeSetUp", "SetUp")
class Test_Class():

    @pytest.fixture(autouse = True)
    def classSetUp(self,OneTimeSetUp):
        self.abc = Some_Test_Class(self.value)

    def test_MethodA(self):
        print("Running the first test case.")
        result = self.abc.sumNumber(10,20)
        print(result)
        assert result==130
        print("printing after assertion")



    def test_MethodB(self):
        print("Running the second test case.")
        result1 = self.abc.sumNumber(20,20)
        print(result1)
        assert result1 == 130
        print("printing after assertion")
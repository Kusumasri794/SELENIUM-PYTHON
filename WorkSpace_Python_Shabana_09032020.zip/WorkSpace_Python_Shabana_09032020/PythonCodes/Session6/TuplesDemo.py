"""
Tuple"
1) Are like List but are immutable (It means you can't change them) - cannot remove,
    insert, pop, append
2) Allows duplication of data
3) Allows slicing and indexing
4) List is defined by square bracket
5) Tuple is defined by parenthesis
6) index() - index method to find value at a particular index number of a TUPLE
7) count() - count method to count number of value in a TUPLE
8) del  - to delete a tuple
9) MAx() - to find the maximun value in  a tuple
10) Min() - to find minimum value in  atuplr
11) cmp() - to compare two or more tuples
12) tuple(seq) - Converts a list into tuple.


"""

#3 LIST example
my_list = [1, 2, 3]
print(my_list)

my_list[0] = 0
print(my_list)

print("***************************")


# Tuple example
my_tuple = (1, 2, 3)
# To print the TUPLE
print(my_tuple)
# To print the value at index number 0 of the TUPLE
print(my_tuple[0])
# To slice values from index number 0 until last of the TUPLE
print(my_tuple[1:])
# To print the index number of the value 2 present in the tuple "my_tuple
print(my_tuple.index(2))

# To change the value of TUPLE at index number 0
# Compiler does show error but ruuning will show error in console
# We cannot change value in a TUPLE
#my_tuple[0] = 5
#print(my_tuple) # TypeError: 'tuple' object does not support item assignment --> TUPLES ARE IMMUTABLE


print("***************************")


# Tuple example
my_tuple1 = (1, 2, 3, 2, 2, 3, 4, 4, 5, 5 ,6,  1, 2)
# index      0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12

# To print the TUPLE
print(my_tuple1)
# To find index number of a particular value - using index() method
# At index 1
x = my_tuple1.index(1)
# To print index of value 1
print(x)  # Index number of the first item "1" from LHS
# To print out the index number of "1" which is second instance from LHS
y = my_tuple1.index(1,3) # The first agument is the item value, the second argument is the index starting with 3; Starting from index 3 ,
# the interpretor will find out the second instance of "1" item
print(y)

print("***************************")

# To print index of value 3 - will get the index number for the first occurence of 3 from left
print(my_tuple1.index(3))
# To print the index number for  second occurence of value 3
print("Index number of second occurance of three is", my_tuple1.index(3,3,6))# first argument is ITEM VALUE, Secoind argument is index number included, thrird argument is index number excluded
# To print index of value 6
print(my_tuple1.index(6))

print("***************************")
# To count number of 3 in th tuple
print(my_tuple1.count(3))

print("***************************")

# Nested Tuple
car = ("BMW", "SUZUKI")
# Nesting the car tuple in Model TUPLE
Model = (1996, 2000, (car))
# To print the TUPLE Model
print (Model)
# To print value at index number 2 - i.e. values of CAR tuple
print(Model[2])
# To print index number of CAR tuple present as a ITEM in Model TUPLE
print(Model.index((car)))
# To print length of a tuple
print(len(Model))
print("***************************")
z1 = Model.index((car))
print(z1)

# To get the index of the ITEM which is in a NESTED TUPLE - OPTION 1
z2 = Model[2]
print(z2)
z3 = z2.index("BMW")
print(z3)
# To get the index of the ITEM which is in a NESTED TUPLE - OPTION 2
z4 = Model[2].index("BMW")
print(z4)



"""
To write a tuple containing a single value you have to include a comma, even though there is only one value −
"""

tup1 = (50,);
print(tup1)


"""
To delete a tuple
"""
tup2 = (1,2)
print(tup2)
#To delete tuple
del tup2
# To print after deleting tuple will show error in console result
#print (tup2) #NameError: name 'tup2' is not defined --> as the tuple id deleted



"""
max() returns the elements from the tuple with maximum value.
"""

tup3 = (1,2,3)
tup4 = (4,5,6)
tup5 = ("Cars", "Cooler")
tup6 = ("one", "two", "three")
print(max(tup3))
print(max(tup4))
print(max(tup5))
print(max(tup6))

#Two tuples defined like below:
tup6,tup7 = ("123", 'xyz','zara','abc'),(456,700,200)

# Max number will not be printed as max value between numbers and Strings cannot be found in tup6. We will get error
print(tup6)
print (max(tup6))
print ("Max value element : ", max(tup6))
print ("Max value element : ", max(tup7))

# Two tuples defined like below:
tup8,tup9 = ('123', 'xyz','zara','abc'),(456,700,200)
print ("Max value element : ", max(tup8))
print ("Max value element : ", max(tup9))



"""
min() returns the elements from the tuple with minimum value.
"""

# Two tuples defined like below:
tup10, tup11 = (123, 'xyz', 'zara', 'abc'), (456, 700, 200)

# Min number will not be printed as min value between numbers and Strings cannot be found in tup10. We will get error
#print ("min value element : ", min(tup10))
print ("min value element : ", min(tup11))

# Two tuples defined like below:
tup12, tup13, tup14 = ('123', 'xyz', 'zara', 'abc'), (456, 700, 200),(12,13,14)
print ("min value element : ", min(tup12))
print ("min value element : ", min(tup13))

# """
# Need to define the cmp() and tuple() method
# """
z1 = tup13>tup14  # comparison between tuples
print(z1)

list_example = [12,13,14]
print(list_example)
tuple_example = tuple(list_example)
print(tuple_example)

list_example1 = list(tuple_example)
print(list_example1)


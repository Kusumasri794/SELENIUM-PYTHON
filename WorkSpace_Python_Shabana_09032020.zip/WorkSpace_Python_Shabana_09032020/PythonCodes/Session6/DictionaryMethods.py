"""
Dictionary Methods
keys() - To print all the keys in a dictionary
values() - To print all the values of the key in a dictionary
items() - To print items(keys and its values) in a dictionary
copy() - To copy a dictionary into a new dictionary
clear() - To clear a dictionary permanently
pop() - To remove a key with its value from the dictionary
"""

# Dictionary of CAR
car = {'make': 'bmw', 'model': '550i', 'year': 2016}
# Dictionary of CARS
cars = {'bmw': {'model': '550i', 'year': 2016}, 'benz': {'model': 'E350', 'year': 2015}}

# Tp print out the class to which the car variable belongs to
print(type(car))
# To print all keys of CAR
print(car.keys())
# To print all values of CAR
print(car.values())
# To print the dictionary
print(car)


print("*"*30)
# To print all keys of CARS
print(cars.keys())

# To print all vales of all keys of CARS
print(cars.values())

print("*"*30)

# To print all items present in CAR dictionary
print(car.items())

# To print all items present in CARS dictionary
print(cars.items())

print("*"*30)

# To pop up the key called model in the dictionary CAR - permanent removal
x = car.pop('model')
# To print the value of the popped key -->model
print(x)
# To print the CAR dictionary after popping the key with its value
print(car)


print("*"*30)

# To copy a dictionary to a new year
print(car)
copy_dict = car.copy()
#To print copy_dict
print(copy_dict)

print("*"*30)

# To clear a dictionary permanently
animal = {'crocodile':'amphibian', 'lion':'land'}
print(animal.keys())
print(animal.values())
print(animal.items())
# To put the cleared dictionary in a variable y
# y = animal.clear()
#To print variable y which will print NONE
# print(y)
# To clear the dictionaey
animal.clear()
# To print the dictionary after clearing - will print --> {}
print(animal)

print("*"*30)

cars.pop('bmw')
print(cars)
print("*"*30)
for k in cars.keys():
    print(k)
    for l in cars.values():
        print(l)
        for m in l.keys():
            #print(m)
            if m == "model":
                print(cars[k][m])
                # cars.pop(m)



# To del a kaye -value pair from nested dictionary - use del function and not the pop function
del cars['benz']['model']
print(cars)

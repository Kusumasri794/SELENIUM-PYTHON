"""
https://docs.python.org/3/library/

IMPORTANT - PACKAGE name should not have spaces; otherwise IMPORT will not happen
"""
import math
from math import sqrt

"""
import the package 'ModuleExternal' and the 'car' module from it as car. Then we can use
'car.info(make, model)'
"""

# import ModuleExternal.car as car

"""
Another way to import the package 'ModuleExternal' and the 'car' module
Then we can use 'info(make, model)'.
"""
# from ModuleExternal import car

"""
Another way to import the package 'ModuleExternal' and the 'car' module
Then we can use 'info(make, model)'. This is the better way
"""
from ModuleExternal.car import info


"""
1) The 'Module External' package contains our 'car.py' python file.
2) 'car.py' file contains 'info' function.
3) 'car.py' becomes our user defined MODULE
"""

class ModulesDemo():

    def builtin_modules(self):
        print(math.sqrt(100))
        print(sqrt(100))

    # Usage of user defined module, where a method 'car_description()' is defined.
    # Defined two local variables 'make1' and 'model1'
    def car_description(self):
        make1 = "bmw"
        model1 = "550i"


        """
        Call the 'info' function from the module 'car' present in 'ModuleExternal' package.
        This is for 'import ModuleExternal.car as car'
        """
        # car.info(make1, model1)


        """
        Call the 'info' function from the module 'car' present in 'ModuleExternal' package.
        This is for 'from ModuleExternal import car'
        """
        # car.info(make1, model1)



        """
        Call the 'info' function from the module 'car' present in 'ModuleExternal' package.
        This is for 'from ModuleExternal.car import info'
        """
        info(make1, model1)


m = ModulesDemo()
m.builtin_modules()
m.car_description()
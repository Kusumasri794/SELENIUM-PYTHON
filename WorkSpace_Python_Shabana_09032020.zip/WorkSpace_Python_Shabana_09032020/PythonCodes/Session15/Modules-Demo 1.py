"""
https://docs.python.org/3/library/
BUILT-IN Modules
"""

"""To find the square root by creating a class and a method inside the class"""

# 'import' keyword used to import the built-in modules
import math


class ModulesDemo():
    def builtin_modules(self, x):
        # Since 'import math ' is used , below we need to define math.sqrt()
        print(math.sqrt(x))

m = ModulesDemo()
m.builtin_modules(100)

# 'from' keyword and 'import' keyword is used
# this will specifically import only 'sqrt' function from 'math' module
from math import sqrt

"""
We should use 'from math import sqrt' rather than 'import math' as 'import math'
takes lot of memory space and computation becomes slower. Explicitly using
'from math import sqrt' willimport only 'sqrt' function from 'math' modules and
memory usage is less.

"""
from math import sqrt

class ModulesDemo1():
    def builtin_modules1(self, x):

        # Since we use 'from math import sqrt', below we need to define only the function 'sqrt()'
        print(sqrt(x))


m1 = ModulesDemo1()
m1.builtin_modules1(121)
"""
Overriding method in the child class

"""
class Car(object):

    def __init__(self):
        print("You just created the car instance")

    def drive(self):
        print("Car started...")

    def stop(self):
        print("Car stopped")

class BMW(Car):

    def __init__(self):
        Car.__init__(self)
        print("You just created the BMW instance")

    # Step 1
    # Drive method present in car class is overridden in the BMW class
    def drive(self):
        # Step 5
        # Want to get the drive method from car class apart from overriding it
        super(BMW, self).drive()
        # Step 2
        # Instead of 'car started...we will see that 'You are driving a BMW, Enjoy...' will be printed
        print("You are driving a BMW, Enjoy...")
    # Step 3
    # BMW class has its own method called headsup_display method
    def headsup_display(self):
        print("This is a unique feature")

# c = Car()
# c.drive()
# c.stop()

b = BMW()
b.drive()
# b.stop()
# Step 4
# Calling up the headsup_display with the b reference variable of BMW class
b.headsup_display()

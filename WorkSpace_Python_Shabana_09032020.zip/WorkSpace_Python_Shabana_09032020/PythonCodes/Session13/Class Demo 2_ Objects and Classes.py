"""
Object Oriented Programming:
1) Class are blueprint or templates that define the OBJECT
"""
"""Example 1 - Class with methods and does not inherit any class"""
class className:
    # Defining method in a class. The first parameter in a method inside class is a SELF parameter
    def createName(self, name):

        """
        self is a temporary placeholder for the Object. If we have an OBJECT name APPLES,
        it is going to throw APPLES instead of self
        self.namePerson is the Object's name  or attribute of the OBJECT
        """
        self.hi = name

    def displayName(self):
        return self.hi

    def saying(self):
        print("Hello ", self.hi)

# To check if the class was created correctly, we print
print(className)

# To use methods inside the class , we need to create objects. We can create 'n' number of OBJECTS
# 'first' and 'second' are reference variable pointing towards the object of className class
first = className()
second = className()
'''
createName has two parameters :self and name
1) self refers back to the OBJECT first so we do not need to pass value
2) name parameter value is defined as 'kaushik'
So what it does is in  self.hi = name defined in createName method, it makes
first.hi  = kaushik
'''
first.createName('Kaushik')
print(first.displayName())
first.saying()


second.createName('Rohit')
print(second.displayName())
second.saying()


print("**********************************************************")

"""
Example 2 - Class Car inheriting the OBJECT class
1) Car class INHERITS the OBJECT class
2) OBJECT IS A SUPER CLASS IN PYTHON
"""
class Car(object): # object super class is inherited by the Car class
    # 'init' is like CONSTRUCTOR in java; which initialises OBJECTS
    def __init__(self, make, model="550i"):

        """
        Self is the OBJECT; 'make' is the Object's make or ATTRIBUTE of the
        object made equal to the parameter variable 'make' defined in 'init' method
        """
        self.make = make
        self.model = model

# c1 is the object or instance of class car
c1 = Car('bmw')
# Printing the attribute MAKE of the class Car
print(c1.make)
# Printing the attribute MAKE of the class Car
print(c1.model)

c2 = Car('benz')
print(c2.make)
c2.model = "320D"
print(c2.model)
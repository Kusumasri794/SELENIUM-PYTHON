"""
1) Class is a concept which is actually used to create instances(creating instances means to create object).
2) Instances are nothing but  instances of the class and instances of the class is called as object
3) HUMAN Being  - Class. We can create instances of the human being i.e. nothing but object of human being
class.
    4) Subhash - Human Being , Suresh  - Human being --> But there is difference in the property value.
    Suresh and Subhash are NAMES. NAMES can be considered as variable of the HUMAN BEING class
    5) For e.g. Human being have hands, legs, lips, hair colour, skin colour - These are nothing but properties of the
    human being class and these properties are common between human beings.Hands, legs, lips, hair, skin colour
    are variables of HUMAN BEING CLAS
    6) Human being will perform certain common actions  - Walking, Talking, Running.
    7) First Instance of the Human Being class i.e. an object of human being class. THe first instance has to initialised .
    Initialisation is an important step for an OBJECT created.

    INITIALIZE the first instance by the properties of the HUMAN BEING class

    Properties of HUMAN BEING : name,hands, legs, lips, hair colour, skin colour  PLUS methods like Walking, Talking, Running.

    # First object of HUMAN BEING class
    h1 = HumanBeing()
    # We are inititalising the object as in Java
    name  = Subhash
    hands = 23cms
    legs = 50 cm
    lips = brown
    hair = black
    skin colour = fair
    Walking()
    Talking()
    Running()


    8) Second  Instance of the Human Being class i.e. second object of human being class. THe scond instance has to initialised .

    Initialisation is an important step for an OBJECT created.

    INITIALIZE the second instance by the properties of the HUMAN BEING class

    Properties of HUMAN BEING : name,hands, legs, lips, hair, skin colour  PLUS methods like Walking, Talking, Running.

    # Second object of HUMAN BEING class
    h2 = HumanBeing()
    # We are inititalising the object as done in java
    name  = Suresh
    hands = 25cms
    legs = 55 cm
    lips = pink
    hair = brown
    skin colour = wheatesh
    Walking()
    Talking()

9) We can create "n" number of objects in a class.
10) For creating class, we need to use the "class" keyword
11) User defined classes should inherit the Object class. Object is an in-built of python. and
is considered as super class/ parent class/Base class.
12) Every object has to be differentiated by the reference/instance variable and we can duplicate
reference variable

"""

class Car():
    # This init method acts as constructor
    # Constructor concept is not present in Python
    # What is a constructor ? Its a concept of Java and C#
    # Constructor is used to to initialise objects and  it does so by reducing the number of codes.
    # This INIT method is used to INITIALISE OBJECTS
    # Self argument in the INIT method points towarsd the objects
    # So any argument passed apart from SELF argument in INIT method, has to assigned to SELF argument. Otherwise that argument will not point towards the OBJECT
    def __init__(self,principalManufacturer, model, colour, price):
        self.principalManufacturer = principalManufacturer
        self.model = model
        self.colour = colour
        self.price = price

    # Methods of the car class
    def Starting(self):
        print(self.model+" starts by switching on the ignition and applying accelerator")
    def Stopping(self):
        print(self.model+" stops by applying brakes")


# Create the first object of the CAr class
# In the argument of the Car object pass the values of principalManufacturer, model, colour, price
# Values of principalManufacturer, model, colour, price are assigned to SELF argument
# SELF argument points towarsd the objects. Then objects will be initialised by these values
c1 = Car("Suzuki", "Brezza", "red", 1300000)
# Call the variables principalManufacturer, model, colour, price by the reference variable of the object
print(c1.principalManufacturer+" "+c1.model+" is priced at "+ str(c1.price)+" rupees")
print(c1.principalManufacturer+" "+c1.model+" colour is "+ c1.colour)
# call the method also by reference variable
c1.Starting()
c1.Stopping()

print("*"*20)

# Create the second object of the CAr class
c2 = Car("Honda", "City", "white", 2200000)
# Call the variables principalManufacturer, model, colour, price by the reference variable of the object
print(c2.principalManufacturer+" "+c2.model+" is priced at "+ str(c2.price)+" rupees")
print(c2.principalManufacturer+" "+c2.model+" colour is "+ c2.colour)
c2.Starting()
c2.Starting()
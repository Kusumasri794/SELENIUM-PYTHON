"""
Object Oriented Programming:
1) Member variable are always called with the CLASS name. Member variable value
will not change
2) Member variable called with instance of object--> their value can change
"""

class Car(object):

    # Wheels is a MEMBER VARIABLE or CLASS VARIABLE available to all methods in a class

    wheels = 4


    def __init__(self, make, model):
        self.make = make
        self.model = model

    def info(self):
        #z = 100
        print("Make of the car: " + self.make)
        print("Model of the car: " + self.model)



c1 = Car('bmw', '550i')
print(c1.make)
c1.info()
print(c1.wheels)
# Member variable called with instance of object--> their value can change
c1.wheels = 3
print(c1.wheels)
# For the object c1, we can call the member variable as below:
print(Car.wheels) #4

print("*"*30)

c2 = Car('benz', 'E350')
print(c2.make)
c2.info()
# For the object c2, we can call the member variable as below:
print(Car.wheels) #4
print(c2.wheels)
c2.wheels = 10
print(c2.wheels)
print(Car.wheels)

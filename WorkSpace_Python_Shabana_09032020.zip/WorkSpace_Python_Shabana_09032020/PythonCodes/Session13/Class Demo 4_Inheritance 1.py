"""
Inheritance:
1) Class which is inherited is called base class/super class/parent class
2) Class which inherits the base class is called as child class/sub class
"""

# The car class inherits the OBJECT class
# Object class is a super class in python
# Step 1
class Car(object):

    # 'init' method acts a constructor which initialises object of a class.
    # in 'init' method , we initialize the attributes of the object as soon as the object of class is created
    # 'init' method will initialize the car calss as soon as the object of car gets created
    # Step 2
    def __init__(self):
        print("You just created the car instance")
    # Step 4
    def drive(self):
        print("Car started...")
    # Step 5
    def stop(self):
        print("Car stopped")


# The class BMW  inherits the car class
# Step 8
class BMW(Car):
    # Step 9
    def __init__(self):
        """
        Step 13
        Line 30 shows warning if we hover mouse..says call to super constructor in class is missed
        To remove warning, line no. 36 is defined and because of line 36 , console shows 'You just created the car instance'
        """
        Car.__init__(self)
        print("You just created the BMW instance")

    # def drive(self):
    #     print("BMW started...")

# The 'init' method defined in CAR class gets initialised as the car object is created below
# Below line will print 'You just created the car instance'
# Step 3
c = Car()
c.drive() #will print 'Car started...'
# Step 6
c.drive()
c.stop() # will print 'Car stopped'
# # Step 7
c.stop()

print("*******************************************")

# Creating an object of BMW i.e. b is the object of BMW class
# Step 10
b = BMW()
# BMW should have the drive method and stop method coming from CAR class
# Step 11
b.drive()
# Step 12
b.stop()

class Animal():

    def __init__(self,tail, legs, colour, animalType, animalName):
        self.tail = tail
        self.legs = legs
        self.colour = colour
        self.animalType = animalType
        self.animalName = animalName
    def Eating(self, eatingType):
        self.eatingType = eatingType
        print(self.animalName+ self.eatingType)
    def Running(self):
        print(self.animalName + " can run")


a1 = Animal(1,4,"brown","carnivorous", "Lion")
print(a1.animalName+" is a "+a1.animalType+" animal")
print(a1.animalName+" has "+str(a1.legs)+" legs and "+str(a1.tail)+" tails")
print(a1.animalName+"is "+a1.colour+" in colour")
a1.Running()
a1.Eating(" eats meat")

print("*"*20)
a2 = Animal(1,4,"grey","herbivorous", "Deer")
print(a2.animalName+" is a "+a2.animalType+" animal")
print(a2.animalName+" has "+str(a2.legs)+" legs and "+str(a2.tail)+" tails")
print(a2.animalName+"is "+a2.colour+" in colour")
a2.Running()
a2.Eating(" eat green leaves")

from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

class RediffMail():
    def WorkingRediffForm(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://register.rediff.com/register/register.php?FormName=user_details")
        time.sleep(10)
        # Type in the full name edit box
        driver.find_element(By.CSS_SELECTOR, "#tblcrtac > tbody > tr:nth-child(3) > td:nth-child(3) > input[type=text]").click()
        driver.find_element(By.CSS_SELECTOR,"#tblcrtac > tbody > tr:nth-child(3) > td:nth-child(3) > input[type=text]").send_keys("Kaushik Mukherjee")
        time.sleep(5)
        # Type in Chooose a Rediffmail ID
        driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[7]/td[3]/input[1]").click()
        driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[7]/td[3]/input[1]").send_keys("kaushikmukherjee319")
        time.sleep(5)
        # Click on CHECK AVAILABILITY button
        driver.find_element(By.CLASS_NAME, "btn_checkavail").click()
        #ExpectedTExt on choosing an RediffmailID
        _expectedText = "Sorry, the ID that you are looking for is taken."
        _actuaText = driver.find_element(By.XPATH, "//*[@id='check_availability']/font[1]/b").text
        if _actuaText==_expectedText:
            # ReType in Chooose a Rediffmail ID
            driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[7]/td[3]/input[1]").click()
            driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[7]/td[3]/input[1]").send_keys("kaushikmukherjee319")
            # Click on CHECK AVAILABILITY button
            driver.find_element(By.CLASS_NAME, "btn_checkavail").click()
        #Type in the password field
        driver.find_element(By.CSS_SELECTOR, "#tblcrtac > tbody > tr:nth-child(10) > td:nth-child(3) > input[type=password]").click()
        driver.find_element(By.CSS_SELECTOR,"#tblcrtac > tbody > tr:nth-child(10) > td:nth-child(3) > input[type=password]").send_keys("test@1234")
        time.sleep(5)
        #Type in the Conformation Password field
        driver.find_element(By.CSS_SELECTOR, "#tblcrtac > tbody > tr:nth-child(12) > td:nth-child(3) > input[type=password]").click()
        driver.find_element(By.CSS_SELECTOR,"#tblcrtac > tbody > tr:nth-child(12) > td:nth-child(3) > input[type=password]").send_keys("test@1234")
        time.sleep(5)
        #Check the checkbox button - IF no alternate ID is present
        driver.find_element(By.CLASS_NAME,"nomargin").click()
        # Number of OPTIONS in the drop down  - Select a Security Question
        addressSecurityQuestion = driver.find_element(By.XPATH, "//*[@id='div_hintQS']/table/tbody/tr[2]/td[3]/select")
        sq  = Select(addressSecurityQuestion)
        listOptions = sq.options
        numOption = len(listOptions)
        indexOptions = 0
        while indexOptions<numOption:
            print(listOptions[indexOptions].text)
            indexOptions+=1
        #Choose the Option from the drop down - Security Question  -   Created by Select HTML TAG
        sq.select_by_value("What is the name of your first school?")
        time.sleep(5)
        sq.select_by_index(2)
        time.sleep(5)
        sq.select_by_visible_text("What is your favourite food?")
        time.sleep(5)
        # Type on Enter an Answer
        driver.find_element(By.CSS_SELECTOR, "#div_hintQS > table > tbody > tr:nth-child(4) > td:nth-child(3) > input[type=password]").click()
        driver.find_element(By.CSS_SELECTOR,"#div_hintQS > table > tbody > tr:nth-child(4) > td:nth-child(3) > input[type=password]").send_keys("Masala Dosa")
        time.sleep(5)
        #Type on Mother's name
        driver.find_element(By.XPATH, "//*[@id='div_hintQS']/table/tbody/tr[6]/td[3]/input").click()
        driver.find_element(By.XPATH, "//*[@id='div_hintQS']/table/tbody/tr[6]/td[3]/input").send_keys("Sukla")
        time.sleep(5)
        # Click the drop down for mobile number - created by DIV tag
        driver.find_element(By.CSS_SELECTOR, "#div_mob > table > tbody > tr > td:nth-child(3) > div:nth-child(2)").click()
        time.sleep(5)
        # Choose USA in Mobile
        driver.find_element(By.XPATH, "//*[@id='country_id']/ul/li[2]").click()
        time.sleep(5)
        #Type the mobile Number
        driver.find_element(By.XPATH, "//*[@id='mobno']").click()
        driver.find_element(By.XPATH, "//*[@id='mobno']").send_keys("12345")
        # Choose the day Option from the Drop Down
        addressDay = driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[22]/td[3]/select[1]")
        sq1 = Select(addressDay)
        sq1.select_by_index(2)
        time.sleep(5)
        # Choose the month Option from the Drop Down
        addressMonth = driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[22]/td[3]/select[2]")
        sq2 = Select(addressMonth)
        sq2.select_by_visible_text("MAR")
        time.sleep(5)
        # Choose the year Option from the Drop Down
        addressYear = driver.find_element(By.XPATH, "//*[@id='tblcrtac']/tbody/tr[22]/td[3]/select[3]")
        sq3 = Select(addressYear)
        sq3.select_by_value("2018")
        time.sleep(5)
        # Choose the female radio button
        driver.find_element(By.CSS_SELECTOR, "#tblcrtac > tbody > tr:nth-child(25) > td:nth-child(3) > input[type=radio]:nth-child(2)").click()
        time.sleep(5)
        # Choose the country Option from the Drop Down
        addressCountry = driver.find_element(By.ID, "country")
        sq4 = Select(addressCountry)
        sq4.select_by_visible_text("India")
        time.sleep(5)
        # Choose the city Option from the Drop Down
        addressCity = driver.find_element(By.XPATH, "//*[@id='div_city']/table/tbody/tr[1]/td[3]/select")
        sq5 = Select(addressCity)
        sq5.select_by_index(9)
        time.sleep(5)

r1 = RediffMail()
r1.WorkingRediffForm()
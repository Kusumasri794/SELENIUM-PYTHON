from selenium import webdriver
import time
import os

# webdriver class method -->https://www.selenium.dev/selenium/docs/api/py/webdriver_remote/selenium.webdriver.remote.webdriver.html?highlight=max#selenium.webdriver.remote.webdriver.WebDriver.maximize_window
# webelement class method --> https://www.selenium.dev/selenium/docs/api/py/webdriver_remote/selenium.webdriver.remote.webelement.html?highlight=webelement

# IF the Zoom level is not set to 100%, exception will be thrown --> selenium.common.exceptions.SessionNotCreatedException: Message: Unexpected error launching Internet Explorer. Browser zoom level was set to 125%. It should be set to 100%
# If protocol is not used with the navigation method , we will get exception -->selenium.common.exceptions.InvalidArgumentException: Message: Specified URL (www.google.com) is not valid.
class IEOperation():
    def GoogleSearch(self):
        # Location of IEDriverServer to work wih IE Browser
        driverLocation = "C:\\driver\\IEDriverServer.exe"
        # Create the Environment variable for the system to understand where the IEDriverServer is kept
        os.environ["webdriver.ie.driver"] = driverLocation
        # Use the firefox method of Webdriver class to open and control the Firefox browser
        driver = webdriver.Ie()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("http://www.google.com")
        # Find the Element  - Google edit box. The below is the address of the edit box. Addresses are kept in WebElement class
        addressEditBox = driver.find_element_by_name("q")
        # Type on the edit box
        addressEditBox.send_keys("Pycharm")
        # Wait for 5 seconds
        time.sleep(5)
        # Click on Google search button
        driver.find_element_by_name("btnK").submit()
        # Wait for 5 seconds
        time.sleep(5)
        #Close the application
        driver.quit()

i1 = IEOperation()
i1.GoogleSearch()
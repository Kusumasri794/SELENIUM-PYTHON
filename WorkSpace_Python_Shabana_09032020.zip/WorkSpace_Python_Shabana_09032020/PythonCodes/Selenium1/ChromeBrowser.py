from selenium import webdriver
import time
import os


class ChromeOperation():
    def GoogleSearch(self):
        # Location of Chromedriver to work wih Chrome Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the Chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("http://www.google.com")
        # Find the Element  - Google edit box. The below is the address of the edit box. Addresses are kept in WebElement class
        addressEditBox = driver.find_element_by_name("q")
        # Type on the edit box
        addressEditBox.send_keys("Pycharm")
        # Wait for 5 seconds
        time.sleep(5)
        # Click on Google search button
        driver.find_element_by_name("btnK").submit()
        # Wait for 5 seconds
        time.sleep(5)
        #Close the application
        driver.quit()

f1 = ChromeOperation()
f1.GoogleSearch()
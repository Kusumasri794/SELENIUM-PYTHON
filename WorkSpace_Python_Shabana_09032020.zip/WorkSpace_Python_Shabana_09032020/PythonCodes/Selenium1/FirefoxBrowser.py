from selenium.webdriver import Firefox
from selenium import webdriver
import time
import os
from selenium.webdriver.common import by
from selenium.webdriver.common.keys import Keys

# webdriver class method -->https://www.selenium.dev/selenium/docs/api/py/webdriver_remote/selenium.webdriver.remote.webdriver.html?highlight=max#selenium.webdriver.remote.webdriver.WebDriver.maximize_window
# webelement class method --> https://www.selenium.dev/selenium/docs/api/py/webdriver_remote/selenium.webdriver.remote.webelement.html?highlight=webelement
class FirefoxOperation():
    def GoogleSearch(self):
        # Location of Geckodriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\geckodriver.exe"
        # Create the Environment variable for the system to understand where the Geckodriver is kept
        os.environ["webdriver.gecko.driver"] = driverLocation
        # Use the firefox method of Webdriver class to open and control the Firefox browser
        driver = webdriver.Firefox()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("http://www.google.com")
        # Find the Element  - Google edit box. The below is the address of the edit box. Addresses are kept in WebElement class
        addressEditBox = driver.find_element_by_name("q")
        # Type on the edit box
        addressEditBox.send_keys("Pycharm")
        # Wait for 5 seconds
        time.sleep(5)
        # Click on Google search button
        driver.find_element_by_name("btnK").submit()
        # Wait for 5 seconds
        time.sleep(5)
        #Close the application
        driver.quit()

f1 = FirefoxOperation()
f1.GoogleSearch()
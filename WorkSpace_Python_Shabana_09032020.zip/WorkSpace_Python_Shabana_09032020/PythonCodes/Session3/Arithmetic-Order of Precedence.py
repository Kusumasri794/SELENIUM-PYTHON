"""

Arithmatic Operators --> +, -, *, /, %

Note: The precedence or hierarchy comes into effect if we have an expression consisting of combination of these operators.

Hierarchy behaviour: Higher the hierarchy/precedence  --> compilation will be done first

NOTE: Compilation happens from left to right and followed by top to down. But when hierarchy/precedence comes into effect, compilation is based on hierarchy.

Rule of hierarchy/precedence among mathematical /Arithmetic operators:
1) Division,floor Division, Modulo and Multiplication is greater in hierarchy than Addition and Subtraction
2) Division,floor Division, Modulo and Multiplication are at same hierarchy level. When operators have same hierarchy level, compilation will happen from left to right
3) Addition and Subtraction are at same hierarchy level.
4) Bracket/parenthesis  is at the highest level of hierarchy and their computation will be done first


"""

a = 10 + 20 - 40 / 2 * 20
#  1st step --> 40 / 2 * 20 ==> 400.0
# 2nd Step --> 10 + 20 - 400.0 = -370.0
print(a)

b = 10 + 20 - 40 * 2 / 20
# 1st Step --> 40 * 2 / 20 = 4.0
# 2nd Step -->10 + 20 -4.0 = 26.0
print(b)

c = 10 + 20 - 40 * 2 / 20 // 3

c1 = 40 * 2 / 20 // 3
print(c1)
# 1St Step --> 40 * 2 / 20 // 3 --> 1.0

c2 =  10 + 20 - 1.0
# @nd Step -->  10 + 20 - 1.3 = 29.0
print(c)

"""
Floor division - floating point divided by integer will fetch floating point where
the quotient will be followed by a decimal value equal to zero
"""
d = 10.0//3
print(d)

"""
Floor division - integer divided by integer will fetch integer where
the quotient will not be followed by a decimal value
"""
e = 10//3
print(e)

f = 20 + 2 - 40 + (20 / 2 +2)
# 1st Step --> (20 / 2 +2) --> 20/2 = 10.0  ==? 10.0+2 = 12.0
# 2nd Step --> 20 + 2 - 40 + 12.0 - -6.0
print(f)
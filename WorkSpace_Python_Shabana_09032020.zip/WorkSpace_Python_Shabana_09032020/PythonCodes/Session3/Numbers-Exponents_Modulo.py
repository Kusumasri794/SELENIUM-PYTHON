"""
1 Modulo is represented by the % sign
2) Modulo will divide the number but the result will be the remainder

3) Exponentiation in Python means to the powwer
4) Exponentiation uses the ** symbol
num = 10** 2 --> 10 to the power of 2


"""

# Modulo Expression

a = 20
b = 40
c =42
d= 41.5


mod1 = b % a
print(mod1)

mod2 = c % a
print(mod2)

mod3 = d % a
print(mod3)

print("*"*30)

# Exponentiation Expression
exp1 = 10**2
print(exp1)

exp2 = 10.5 **3
print(exp2)


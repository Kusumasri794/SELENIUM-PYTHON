"""
1) The integer numbers (e.g. 2, 4, 20) have type int, the ones with a fractional
part (e.g. 5.0, 1.6) have type float.
2) In addition to int and float, Python supports other types of numbers, such as
Decimal and Fraction. Python also has built-in support for complex numbers, and
uses the j or J suffix to indicate the imaginary part (e.g. 3+5j).

"""

# A variable int_num is a integer as the value 10 is without any decimal
int_num = 10
print(type(int_num))
# A variable float_num is a float as the value 20.0 is with a decimal part
float_num = 20.0
float_num1 = 12 #int class

print(int_num)
print(float_num)

print("*************Ways to print out results******************")
# Way 1
print(float_num)
# Way 2
# print("The value of the float variable is "float_num)
print("The value of the float variable is ",float_num)
# Way 3
# "+" in the below code is not addition operator.
# Whenever there is a string format and we use "+" before or after the string value --> "+" will act as concatenation operator
# Concatenation means COMBINING
# In Python, the concatenation operator should have string before and after the "+" sign.
#print("The value of the float variable is "+float_num)
# Whenever there is another format in expressions where concatenation operator is used, convert that another format to STRING fomat
# Converting another format to string format requires us to use  --> str() function
print("The value of the float variable is "+ str(float_num))


complex_numbers1 = 3+5j
print(type(complex_numbers1))
complex_numbers = (3+5j)-(1+3j)
print(type(complex_numbers))
print(complex_numbers)

print("*********Separates the answers thrown in console*********")


"""
Arithmetic Operators:
NOTE: Addition (+), Subtraction(-), Multiplication(*), Division(/), Modulo(%)
1) Division (/) always returns a float. 

Note: To do floor division and get an integer result (discarding any fractional result) you can use the // operator; 

2) To calculate the remainder you can use modulo operator (%_
"""

# Variables a,b and c declared
a = 10
b = 20
c = 31
d = 34.3

#Addition
add = a + b # The resultant value will be an integer
print(add)

#Subtraction
sub = b - a # The resultant value will be an integer value
print(sub)

#Multiplication
multi = a * b # The resultant value will be an integer value
print(multi)

#Division
div_mychoice = b / a  #The resultant value will be an float value
print(type(div_mychoice))
print(div_mychoice)

#Floor Division
floor_div = c//a
print(floor_div) # #The resultant value will be an integer value

floor_div1 = d//a
print(floor_div1) # #The resultant value will be an float value


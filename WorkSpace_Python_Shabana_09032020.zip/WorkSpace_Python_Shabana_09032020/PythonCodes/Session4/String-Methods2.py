"""
String methods in python
"""

"""
Replace Method - To replace character or set of charecters
"""
# Replace all lower case instances of abc with upper case instances of ABC
a = "1abc2abc3abc4abc"
print(a.replace('abc', 'ABC'))


b = "Hi! How is Selenium training? Hurray"
# Replace all  instances of H with  instances of Z
print(b.replace('H','Z'))
# Replace from left two instances (count is 2) of H with  instances of Z
print(b.replace('H','Z',2))
# Replace from left four instances (count is 4) of H with  instances of Z -
# Only replace 3 instances of H with Z as the fourth H is not present in the String
print(b.replace('H','Z',4))
# Does not replace any H with Z as the count is 0
print(b.replace('H','Z',0))
# Replace all  instances of H with  instances of Z as the count is -1
print(b.replace('H','Z',-1))

print("*********Separates the answers thrown in console*********")

"""
Sub-Strings
1) Starting index is inclusive
2) Ending index is exclusive
"""

#To print character at index number 2
str_a = "Learning Python is interesting"[2]
print(str_a)  #a

# To print characters from  index number 2 until index number 6 ; including 2 and excluding 6
str_b = "Learning Python is not cumbersome"[2:6]
print(str_b)

# To print characters from  index number 10 until index number 17 ; including 10 and excluding 17 but steps of 3
# P = Index 10 will be included printed
# L  = First step
# A = Second step
# T = Third step will be printed
# F = First step
# O = Second step
# R = Third step and will be printed
# M - Index number 17 and will be excluded from printing
str_c = "Python is platform independent"[10:17:3]
print(str_c)

# To print charecter at index number 4
city = "New Delhi"
str_city = city[4]
print(str_city)

"""
Examples to show how boolean works in python
1) Boolean can be either true or false
2) Number zero in any form is false. Any form means empty object, empty string or NONE
3) Not zero means true. it can be a non-empty object, non-empty string, non NONE
4) Booleans are a subtype of integers. Integers have unlimited precision.
5) In numeric contexts (for example when used as the argument to an arithmetic operator),
they behave like the integers 0 and 1, respectively. The built-in function bool() can be
used to convert any value to a Boolean, if the value can be interpreted as a truth value

"""

a = True
print(type(a))
b = False

print(a)
print(b)

print("*********Separates the answers thrown in console*********")

# Number zero in any form is false. Any form means empty object, empty string or NONE
print(bool(0))
c = ""
print(bool(c))
print(bool())#None
print(bool(None))
print(bool(not True))

print("*********Separates the answers thrown in console*********")

# Not zero means true. it can be a non-empty object, non-empty string, non NONE
print(bool(1))
print(bool(2))
d = "Some Value"
print(bool(d))
print(bool(not None))
print(bool(not False))

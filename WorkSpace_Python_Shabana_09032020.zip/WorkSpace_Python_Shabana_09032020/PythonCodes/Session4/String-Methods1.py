"""
Examples to show available string methods in python
"""

# Accessing characters in a string - Characters fetching through index number
# First Approach to get character at index number
# Index starts from zero
a = "London"
b = a[2]
print(b) #n

first = "New York City"[4]
print(first)

print("*********Separates the answers thrown in console*********")

# Second Approach to get character at index number
city = "Sanfrancisco"
ft = city[8]
print(ft)


"""
    len() - Length method to find the length of the String
    lower() - To convert charaters of the String in lower case
    upper() - To convert charaters of the String in upper case
    str() - To convert any other format to String format
"""

#Lower case conversion
str_a = "This Is a Mixed Case for lower case conversion"
print(str_a.lower())

#Upper case conversion
str_b = "This Is a Mixed Case for upper case conversion"
print(str_b.upper())

#Length of the String
str_c = "Hi! We are learning Python"
print(len(str_c))
# print(str_c.len())# Cannot define lenght method like this

"""
 Concatenation operator to concatenate two string
"""
str_d = "Hi ! We are learning Selenium with Python"
e = 2
# In the below code a String caanot be concatenated by integer, so error
# print(str_d + 2)
print(str_d+str(2))


#Variable e of integer type needs to be converted to string
str_f = str(e)
print(str_d+str_f)
print(str_d+str(e))

# Concatenate Strings with empty string
print("Hello " + " " + " World !!!")
print(first + "-" + city)
"""
Examples to show how strings works in python

1) Sequence of characters
2) Contains a-z, 0-9, special characters
3) Strings can be defined in double or single quotes
"""

a = "This is a simple string"
b = 'Using single quotes'

print(a)
print(b)

# Using single quotes inside a String defined within double quotes
c = "Need to use ' single quotes' inside a string"
print(c)

# Using double quotes inside a String defined within single quotes
d = 'Need to use "double quotes" inside a string'
print(d)

# Using double quotes inside a String defined within double quotes - using preceded escape sequence
e = "Another way to handle \"quotes\""
print(e)

# Using single quotes inside a String defined within double quotes - using preceded escape sequence
f = 'Another way to handle \'quotes\''
print(f)


g = "This is a single\
 string \
multiline value"
print(g)
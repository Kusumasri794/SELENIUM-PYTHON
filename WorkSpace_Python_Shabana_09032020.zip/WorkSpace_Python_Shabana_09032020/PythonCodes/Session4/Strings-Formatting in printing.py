"""
Examples to show how string formatting works in python
"""

city = "Bangalore"
event = "magical show"
grading =5

# Using the concatenation operator to concatenate String variables
print("Welcome to " + city + " and enjoy the " + event + " and give " + str(grading) + " grading")

# Using %s to concatenate String variables
print("Welcome to %s" % city)
print("Welcome to %s and enjoy the %s and give %d star grading" % (city, event, grading))
"""t
String  - Slicing and Indexing
"""

a = "It is imperative Python has become an important language"
str_b = a
#To print character at 0 index
print(str_b[0])

# To print character at index number -1 -> to print "e" at the last of the string
# -1 is given to the last character in the string
print(str_b[-1])

# To print character at index number -2 -> to print "g" present at the second last position of the string
# -2 is given to the last character in the string
print(str_b[-2])
b  = len(str_b)
print("Length of the string variable is "+str(b))
print(str_b[(b-1)-1]) # print(str_b(55-1)
print(str_b[(b-1)-1:55])
print(str_b[-2:-1])
print(str_b[-2:(b-1)])
print(str_b[54])
print(str_b[54:55:1])
print(str_b[-2:(b-1):1])
print(str_b[(b-1)-1:55:1])
print(str_b[-2:-1:1])

print("*"*30)

# To print the whole string except the last character in the string in three ways:
print(str_b[0:55])
print(str_b[:55])
print(str_b[:-1])
print(str_b[0:55:1])
print(str_b[:55:1])
print(str_b[:-1:1])

print("*"*30)

# To print the whole string except the two last character in the string in three ways:
print(str_b[0:54])
print(str_b[:54])
print(str_b[:-2])
print(str_b[0:54:1])
print(str_b[:54:1])
print(str_b[:-2:])
print(str_b[:-2:1])

print("*"*30)

# To print the whole string except the two last character in the string in steps of 1:
print(str_b[0:54:1])
print(str_b[:54:1])
print(str_b[:-2:1])

print("*"*30)

# To print the whole string except the last character in the string in steps of 2:
print(str_b[0:55:2])
print(str_b[:55:2])
print(str_b[:-1:2])
print(str_b[0:len(a)-1:2])
print(str_b[-56:-1:2])
print(str_b[0:(b-1):2])
print(str_b[(0-b):(b-1):2])

print("*"*30)

# To print the whole string:
print(str_b[:])
print(str_b[0:b])
print(str_b[::])
print(str_b[0:b:1])
print(str_b[0:])
print(str_b[-56:])
print(str_b[-56::])
print(str_b[0-b:])
print(str_b[0-b::])
print(str_b[-56:0:])

print("*"*30)

# To print the whole string in reverse order:
print(str_b[::-1])
print(str_b[::-2])
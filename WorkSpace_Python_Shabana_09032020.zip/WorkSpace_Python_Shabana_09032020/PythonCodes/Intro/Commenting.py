#Single Line Comment --> #



# Multi-line comment --> Highlight the codes and use CTRL+/
# Multi-line uncomment --> Highlight the codes and use CTRL+/
#
# This is
# a multi line
# comment
#


"""
Triple quotes are
also used
for multi line commenting

"""
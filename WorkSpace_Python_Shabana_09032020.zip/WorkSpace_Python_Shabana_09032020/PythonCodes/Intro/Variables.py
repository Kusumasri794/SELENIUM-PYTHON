



"""
For C# --> string str = "Hi!" --> string is a datatype in c#
For Java --> String str1 = "Welcome" --> String is a type/class.
1) In Python, variables are not declared with data type. In Python, everything is an object.
2) a = "nyc" --> Expression : a ia a reference variable/instance variable , pinpointing towards the object of String class and the value of "a' is "nyc"
3) What is an instance variable? Is a variable which pinpoints towards an OBJECT.
4) What is an object? Object is an instance of a class.
"""

"""
1) An object nyc is created of type string reference by the variable "a". Variable a is referencing the object nyc
2) Another object nyc is created of type string reference by the variable "b". Variable b is referencing the object nyc


"""


a="nyc" #Is the reference variable 'a' pin-pointing towards the object of the String class? We need to use the type function. Type function is used to show the class object to which the reference variable is pin-pointing
print("The reference variable a is pin-pointing towards the object of ",type(a), " class")
b="nyc"
print("The reference variable b is pin-pointing towards the object of ",type(b), " class")

"""
SYBMOL TABLE for line 22 and line 22
1) The reference count of the variables pointing towards object nyc is 2
2) A symbol table is created as below:
Symbol Tableconsists of the following columns:
Object Value | Reference Variables | Count of Reference
nyc                 a                       1
nyc                 b                       2

"""


"""
1) In Java/C#, duplicate variable name is not allowed. If we duplicate the variables name s, syntax error is thrown out out by the compiler.
2) In Python, we can have duplicate variable name.
How does Python support duplicate variable name? It supports because of the concept of SYMBOL TABLE

"""
a = 10;
"""
SYBMOL TABLE for line 22, line 24 and line 45  - change in symbol
1) The reference count of the variables pointing towards object nyc is 2
2) A symbol table is created as below:
Symbol Tableconsists of the following columns:
Object Value | Reference Variables | Count of Reference
nyc                 a                       1 --> Go to garbage collection
nyc                 b                       2 --> 2 will become 1
10                  a                       1

Because of the symbol table maintained in hindout, duplication of variables names is allowed.
"""
c = 20.3
print(type(c))

"""
SYBMOL TABLE for line 24,line 45 and line 58  - change in symbol

Symbol Tableconsists of the following columns:
Object Value | Reference Variables | Count of Reference
nyc                 b                       1 
10                  a                       1
20.3                c                       1


"""

c = "abc"


"""
SYBMOL TABLE for line 24,line 45 and line 58  - change in symbol

Symbol Table consists of the following columns:
Object Value | Reference Variables | Count of Reference
nyc                 b                       1 
10                  a                       1 
abc                 c                       2 -- variable c and b are pin-pointing to object of string class

b and c are two variable pointing to object of string class = count of reference is 2
a variable is pointing to object of integer class = count of reference is 1
"""

print(a)   #10
print(b) #nyc
print(c) #abc

#Another object 123 is created of type integer. The reference varible given is a

a=123

"""

Symbol Table consists of the following columns:
Object Value | Reference Variables | Count of Reference
nyc                 b                       1 
123                 a                       1 
abc                 c                       2 -- variable c and b are pin-pointing to object of string class

b and c are two variable pointing to object of string class = count of reference is 2
a variable is pointing to object of integer class = count of reference is 1
"""

print(a) #123

c="nyc"
d=c

"""

Symbol Table consists of the following columns:
Object Value | Reference Variables | Count of Reference
nyc                 b                       1 
123                 a                       1 
nyc                 c                       2 
nyc                 d                       3 -- variable b,c and d are pin-pointing to object of string class
d, b and c are three variable pointing to object of string class = count of reference is 3
a variable is pointing to object of integer class = count of reference is 1
"""

print(c==d) # "==" is the EQUALITY OPERATOR  --> The value in the LHS of EQUALITY and the value in the RHS of EQUALITY is checked and a BOOLEAN value is throwmn out. If both are equal TREU is thrown else false
print(d is c) # Is the value of d equal to the value of c? It throws out a boolean value. "is" is areservd keyword in python

# USed reserved keyword for other purpose apart from which it is meant to be used
# We will use the reserved keyword "is" to define it as a variable name
# is = 30  # Will show syntax error
z1= 100

def Addition():
    global z1; #100
    print (z1) #100
    a = 20  #20 --> The local variable valu s passed to global variable and now the value og global variable is 20
    print(a) #20
    print(z1) #100
    # b = 30
    # c = a+b

def Subtraction():
    global z1; #100
    print(z1)# 100
    x = 20
    y = z1-x # 80
    print(y)#80



    # print(c)

Addition()

print("*" *20)
print("********************************")

Subtraction()

# Declaring def ; a reserved keyword for variable name
# def = 12 --> syntax error





"""
This is our own module which does not exist in python built-ins
This is user defined module
"""

"Car here is the module which contains the info() function. Car module inside the ModuleExternal package"

def info(make, model):
    print("Make of the car: " + make)
    print("Model of the car: " + model)
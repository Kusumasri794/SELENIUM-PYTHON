"""
variables rules
"""

# We can import modules and packages
# Keyword is a module
import keyword
print(keyword.kwlist)


print("*********Separates the answers thrown in console*********")

# Instead of seperately defining the variables value, variables a, b, c are defined in single line
# The variables a, b, c are defined in a single line as they have same values

a = b = c = d = 10
"""
Line no. 21 will print value of a and the cursor remains in the same line as the end
parameter value is empty. Value of b will be printed along with the value of a . After printing
the value ob , then the cursor moves toa new line

By default if the end parameter is not defined in print method, the cursor would move to
a new line after printing
"""

print(a,end='@')
print(b)
print(c)
print(d)
# There is no variable e defined, so error will be thrown out
#print(e)

print("*********Separates the answers thrown in console*********")

"""
The values of the variables x,y,z are different and can be defined as shown below
"""
x, y, z = 10, 20, 30
print(x)
print(y)
print(z)

print("*********Variable Rules*********")

_var = 20
print(_var)

# @var1 = 90

#  3var2 = 34

var4 = 80
print(var4)

var5_ = 40

from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By

class Links():
    def WorkingLinks(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Firefox browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://www.bbc.com/")
        time.sleep(15)
        # Address of LATEST BUSINESS NEWS area - Webelement
        addressNewsArea = driver.find_element(By.XPATH, "//*[@id='page']/section[7]/div/div/div[2]")
        # Find number of links from the area
        listLinks = addressNewsArea.find_elements(By.TAG_NAME, "a")
        numLinks = len(listLinks)
        print("Number of links in the area",numLinks)
        _varIndexLinks = 0
        while _varIndexLinks<numLinks:
            # Click on link
            listLinks[_varIndexLinks].click() # At this point cache memory got lost. So got Stale element reference exception
            time.sleep(10)
            # Title of the page
            titlePage = driver.title
            print("The title of the page is", titlePage)
            time.sleep(5)
            driver.get("https://www.bbc.com/")
            #Recreation of cache memory after coming back to BBC website
            addressNewsArea = driver.find_element(By.XPATH, "//*[@id='page']/section[7]/div/div/div[2]")
            listLinks = addressNewsArea.find_elements(By.TAG_NAME, "a")
            time.sleep(10)
            _varIndexLinks+=1


l1 = Links()
l1.WorkingLinks()
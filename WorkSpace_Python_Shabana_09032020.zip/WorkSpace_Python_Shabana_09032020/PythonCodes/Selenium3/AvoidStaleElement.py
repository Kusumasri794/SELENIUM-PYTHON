from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
class Links():


    def isElementPresent(self,xPathValue):
        print(driver)
        self.xPathValue = xPathValue
        time.sleep(20)
        allElement = driver.find_elements(By.XPATH, self.xPathValue)
        numOfLinksHavingSameXpathValue = len(allElement)
        # If the number of links having same xpath is more than 0, that means element is existing
        # If the number of links having same xpath is equal to 0, that means element is not existing
        if (numOfLinksHavingSameXpathValue == 0):
            print("Element not existing")
            return False
        else:
            print("Element is existing")
            return True

    def WorkingLinks(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        print(driver)
        # Use the Chrome method of Webdriver class to open and control the Firefox browser

        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://www.bbc.com/")
        time.sleep(15)

        a = "//*[@id='page']/section[7]/div/div/div[2]/div/ul/li["
        b = "]/a"

        c = 1
        # d = a+(str(c))+b
        # print(d)
        # while c <= 5:
        #     driver.find_element(By.XPATH, a+(str(c))+b).click()
        #     time.sleep(5)
        #     titlePage = driver.title
        #     print(titlePage)
        #     time.sleep(5)
        #     driver.get("http://www.bbc.com")
        #     time.sleep(5)
        #     c += 1
        while (self.isElementPresent(a + (str(c)) + b)):
            driver.find_element(By.XPATH, a+(str(c))+b).click()
            time.sleep(5)
            titlePage = driver.title
            print(titlePage)
            time.sleep(5)
            driver.get("http://www.bbc.com")
            time.sleep(5)
            c += 1
        # Time period before the browser is closed
        time.sleep(10)

        # Close the browser
        driver.quit()

l1 = Links()
l1.WorkingLinks()
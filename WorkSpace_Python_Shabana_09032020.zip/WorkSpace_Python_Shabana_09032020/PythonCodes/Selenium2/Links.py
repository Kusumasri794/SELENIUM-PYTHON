from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By

class Links():
    def WorkingLinks(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Firefox browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://www.bbc.com/")
        time.sleep(15)
        # Title of the webpage
        titlepage = driver.title
        print("The title of the page is",titlepage)
        # Number of links in BBC
        listLinks = driver.find_elements(By.TAG_NAME, "a")
        print(type(listLinks))
        numOfLinks = len(listLinks)
        print("The number of links in BBC website are ",numOfLinks)
        # Print out text of all links
        i = 0 # variable i rrepresents the index number variable
        while i<numOfLinks:
            #Getting the text of links
            linkText = listLinks[i].text
            # Getting the Display property
            boolValue = listLinks[i].is_displayed()
            print("The text present in",i,"index is ",linkText, "and the display property is",boolValue)
            # To print out attribute value for ID, CLASS and NAME
            idAttr = listLinks[i].get_attribute("id")
            classAttr = listLinks[i].get_attribute("class")
            nameAttr = listLinks[i].get_attribute("name")
            print("ID: ",idAttr,"--CLASS:",classAttr,"--NAME:",nameAttr)
            i = i+1
        time.sleep(15)
        driver.quit()

l1 = Links()
l1.WorkingLinks()
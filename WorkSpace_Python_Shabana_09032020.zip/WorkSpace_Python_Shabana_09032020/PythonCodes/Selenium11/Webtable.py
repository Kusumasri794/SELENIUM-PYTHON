from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class Webtable():
    def WebtableXpath(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://money.rediff.com/gainers/bse/daily/groupa?src=gain_lose")
        time.sleep(7)
        # 1)Get the text from first column only row from the heading
        str1 = driver.find_element(By.XPATH, "//*[@id='leftcontainer']/table/thead/tr/th[1]").text
        print("Text from first column only row from the heading",str1)

        print("***************************************")
        # 2)Get the text from last column only row from the heading
        str2 = driver.find_element(By.XPATH, "//*[@id='leftcontainer']/table/thead/tr/th[5]").text
        print("Text from fifth/last column only row from the heading", str2)

        print("***************************************")
        # 3) Get the text from all column only row from the heading - highlighting the full row of the heading - ColumnWise
        str3 = driver.find_element(By.XPATH, "//*[@id='leftcontainer']/table/thead/tr").text
        print("Text from all column column only row from the heading", str3)

        print("***************************************")
        # 4) Get the text from first column only row from the heading - highlighting the full row of the heading
        str4 = driver.find_element(By.XPATH, "//*[@id='leftcontainer']/table/thead/tr/th").text
        print("Text from first column column only row from the heading", str4)

        print("***************************************")
        # 5) Get the text from all column only row from the heading - highlighting the full row of the heading - Column Wise
        str5 = driver.find_elements(By.XPATH, "//*[@id='leftcontainer']/table/thead/tr/th")
        x1 = 0
        while x1<len(str5):
           headingText = str5[x1].text
           print(headingText)
           x1 = x1+1

        print("***************************************")
        # 6) Get the text from second column of first row from the body
        str6 = driver.find_element(By.XPATH, "//*[@id='leftcontainer']/table/tbody/tr[1]/td[2]").text
        print("Text from second column of first row from the heading", str6)

        print("***************************************")
        # 7) Get the text  from all column first row from the body  -ColumnWise
        str7 = driver.find_element(By.XPATH, "//*[@id='leftcontainer']/table/tbody/tr[1]").text
        print("Text from all column first row from the body ", str7)

        print("***************************************")
        # 8) Get the text  from all column first row from the body  -Row-wise
        str8 = driver.find_elements(By.XPATH, "//*[@id='leftcontainer']/table/tbody/tr[1]/td")
        x2 = 0
        while x2 < len(str8):
            headingText1 = str8[x2].text
            print(headingText1)
            x2 = x2 + 1

        print("***************************************")
        # 9)Get the text from all rows first column of the body
        str9 = driver.find_elements(By.XPATH, "//*[@id='leftcontainer']/table/tbody/tr/td[1]")
        x3 = 0
        while x3 < len(str9):
            headingText1 = str9[x3].text
            print(headingText1)
            x3 = x3 + 1

        print("***************************************")
        # 10)Get the text from all rows second column of the body
        str10 = driver.find_elements(By.XPATH, "//*[@id='leftcontainer']/table/tbody/tr/td[2]")
        x4 = 0
        while x4 < len(str10):
            headingText2 = str10[x4].text
            print(headingText2)
            x4 = x4 + 1

        print("***************************************")
        # 11)Get the text from all rows all column of the body - find elements - Row-wise
        str11 = driver.find_elements(By.XPATH, "//*[@id='leftcontainer']/table/tbody/tr/td")
        x5 = 0
        while x5 < len(str11):
            headingText3 = str11[x5].text
            print(headingText3)
            x5 = x5 + 1

        print("***************************************")
        # 12)Get the text from all rows all column of the body - find elements - Column -wise
        str12 = driver.find_elements(By.XPATH, "//*[@id='leftcontainer']/table/tbody/tr")
        x6 = 0
        while x6 < len(str11):
            headingText4 = str12[x6].text
            print(headingText4)
            x6 = x6 + 1

        time.sleep(5)
        # Close the browser
        driver.quit()



w1 = Webtable()
w1.WebtableXpath()
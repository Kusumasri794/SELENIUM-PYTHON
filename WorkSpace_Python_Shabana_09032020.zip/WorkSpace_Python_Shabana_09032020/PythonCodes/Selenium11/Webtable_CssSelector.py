from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class Webtable():
    def WebtableCssSelector(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://money.rediff.com/gainers/bse/daily/groupa?src=gain_lose")
        time.sleep(7)

        # 1) Get the text from First row first column of the heading of the table
        str1 = driver.find_element(By.CSS_SELECTOR, "#leftcontainer > table > thead > tr > th:nth-child(1)").text
        print("Text from First row first column of the heading of the table is ", str1)

        print("**********************************")

        # 2) Get all data from the first row all column of the heading of the table - Row-wise
        str2 = driver.find_elements(By.CSS_SELECTOR, "#leftcontainer > table > thead > tr > th")
        x1 = 0
        while x1 < len(str2):
            headingText = str2[x1].text
            print(headingText)
            x1 = x1 + 1

        print("**********************************")

        # 3) Get all data from the first row all column of the heading of the table - Column-wise
        str3 = driver.find_element(By.CSS_SELECTOR, "#leftcontainer > table > thead > tr").text
        print(str3)

        print("**********************************")

        # 4) Get the text from First row first column of the body of the table
        str4 = driver.find_element(By.CSS_SELECTOR, "#leftcontainer > table > tbody > tr:nth-child(1) > td:nth-child(1)").text
        print(str4)

        print("**********************************")

        # 5) Data from all column of first row of the body of the table -  Row Wise
        str5 = driver.find_elements(By.CSS_SELECTOR, "#leftcontainer > table > tbody > tr:nth-child(1) > td")
        x2 = 0
        while x2 < len(str5):
            headingText = str5[x2].text
            print(headingText)
            x2 = x2 + 1

        print("**********************************")

        # 5) Data from all column of first row of the body of the table -  Column  Wise
        str6 = driver.find_element(By.CSS_SELECTOR, "#leftcontainer > table > tbody > tr:nth-child(1)").text
        print(str6)

        print("**********************************")
        # 6) Data from fifth column all rows of the body of the table - Row-wise
        str7 = driver.find_elements(By.CSS_SELECTOR, "#leftcontainer > table > tbody > tr > td:nth-child(5)")
        x3 = 0
        while x3 < len(str7):
            headingText = str7[x3].text
            print(headingText)
            x3 = x3 + 1



        print("**********************************")
        # 7) Data from all column all rows of the body of the table - Row-wise
        str8 = driver.find_elements(By.CSS_SELECTOR, "#leftcontainer > table > tbody > tr > td")
        x4 = 0
        while x4 < len(str8):
            headingText = str8[x4].text
            print(headingText)
            x4 = x4 + 1

        print("**********************************")
        # 8) Data from all column all rows of the body of the table - Column-wise
        str9 = driver.find_elements(By.CSS_SELECTOR, "#leftcontainer > table > tbody > tr")
        x5 = 0
        while x5 < len(str9):
            headingText = str9[x5].text
            print(headingText)
            x5 = x5 + 1

w1  = Webtable()
w1.WebtableCssSelector()
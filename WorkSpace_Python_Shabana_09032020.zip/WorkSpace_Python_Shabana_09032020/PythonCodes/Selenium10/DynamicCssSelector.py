from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class CssSelector():
    def CssRegularExpression(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://register.rediff.com/register/register.php?FormName=user_details")
        time.sleep(10)

        # Click on Terms and condition link  - text() function cannot be used for CssSelector
        # driver.find_element(By.CSS_SELECTOR, "a[text() = 'terms and conditions']").click()

        # Type in Full Name Edit box - Dynamic CssSelector with regular Expression
        # driver.find_element(By.CSS_SELECTOR, "input[name*= 'name']").send_keys("Kaushik")
        driver.find_element(By.CSS_SELECTOR, "input[name^= 'name']").send_keys("Kaushik")

        time.sleep(5)




x1 = CssSelector()
x1.CssRegularExpression()
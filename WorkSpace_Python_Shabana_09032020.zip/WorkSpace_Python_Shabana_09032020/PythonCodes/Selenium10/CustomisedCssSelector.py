from selenium import webdriver
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class CssSelector():
    def CustomisedCssSelector(self):
        # Location of Chromedriver to work wih Firefox Browser
        driverLocation = "C:\\driver\\chromedriver.exe"
        # Create the Environment variable for the system to understand where the chromedriver is kept
        os.environ["webdriver.chrome.driver"] = driverLocation
        # Use the Chrome method of Webdriver class to open and control the Chrome browser
        driver = webdriver.Chrome()
        # Maximize the Browser Window
        driver.maximize_window()
        # Navigate to URl
        driver.get("https://www.google.com/")

        time.sleep(5)

        # Typing in the Google Edit box
        # Partial CssSelector
        # Compound Class value
        #driver.find_element(By.CSS_SELECTOR, "*[class = 'gLFyf gsfi']").send_keys("Selenium")
        #driver.find_element(By.CSS_SELECTOR, "input[class = 'gLFyf gsfi']").send_keys("Selenium")
        # This format of using compund class values not supported by CssSelector --> no such element: Unable to locate element: {"method":"css selector","selector":".gLFyf gsfi"}
        #driver.find_element(By.CSS_SELECTOR, ".gLFyf gsfi").send_keys("Selenium")
        #driver.find_element(By.CSS_SELECTOR, ".gLFyf").send_keys("Selenium")

        # driver.find_element(By.CSS_SELECTOR, "div[class = 'a4bIc']>input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, "div[class = 'a4bIc'] input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, "div.a4bIc>input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, "div.a4bIc input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, "*.a4bIc input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, "div.a4bIc input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, ".a4bIc>input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, ".a4bIc input:nth-child(3)").send_keys("Selenium")

        # driver.find_element(By.CSS_SELECTOR, "div[class = 'SDkEP']>div:nth-child(2)>input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR, "div[jsmodel = 'TMlYFc']>div:nth-child(2)>div:nth-child(1)>div:nth-child(2)>input:nth-child(3)").send_keys("Selenium")

        # driver.find_element(By.CSS_SELECTOR, "form[id = 'tsf']>div:nth-child(2)>div:nth-child(1)>div:nth-child(2)>div:nth-child(1)>div:nth-child(2)>input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR,"form#tsf>div:nth-child(2)>div:nth-child(1)>div:nth-child(2)>div:nth-child(1)>div:nth-child(2)>input:nth-child(3)").send_keys("Selenium")
        # driver.find_element(By.CSS_SELECTOR,"#tsf div:nth-child(2) div:nth-child(1) div:nth-child(2) div:nth-child(1) div:nth-child(2) input:nth-child(3)").send_keys("Selenium")

        # Absolute CssSelector
        driver.find_element(By.CSS_SELECTOR,"html>body:nth-child(2)>div:nth-child(4)>div:nth-child(4)>form:nth-child(3)>div:nth-child(2)>div:nth-child(1)>div:nth-child(2)>div:nth-child(1)>div:nth-child(2)>input:nth-child(3)").send_keys("Selenium")

        time.sleep(5)

        # USe KEYS class to get links pertaining to the Keyword  - Using the Keys class RETURN FUCNTIOn tot be utilised on the Google Edit box only
        driver.find_element(By.XPATH, "//*[@class = 'gLFyf gsfi']").send_keys(Keys.ENTER)

        time.sleep(5)

        # Close the browser
        driver.quit()


c1 = CssSelector()
c1.CustomisedCssSelector()
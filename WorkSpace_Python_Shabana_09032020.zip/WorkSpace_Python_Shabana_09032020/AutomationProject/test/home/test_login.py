from selenium import webdriver
import time
import os

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from page.home.loginPage import LoginPage
import unittest
import pytest


@pytest.mark.usefixtures("OneTimeSetUp", "SetUp")
class test_homeLogin(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetUp(self, OneTimeSetUp):
        self.lp = LoginPage(self.driver)

    @pytest.mark.run(order=1)
    def test_invalidLogin(self):
        self.lp.Login("selenium.testmay2017", "test")
        time.sleep(5)
        self.lp.verifyLoginFailed()

    @pytest.mark.run(order = 2)
    def test_validLogin(self):
        # # Click on the Rediffmail Link
        # loginLinkAddress = driver.find_element(By.LINK_TEXT, "Rediffmail")
        # loginLinkAddress.click()
        #
        # #Type on the Email address
        # emailEditAddress = driver.find_element(By.ID, "login1")
        # emailEditAddress.send_keys("selenium.testmay2017")
        #
        # # Type on the password field
        # passwordEditAddress = driver.find_element(By.ID, "password")
        # passwordEditAddress.send_keys("test@1234")
        #
        # # Click on the login button
        # logButtonAddress = driver.find_element(By.XPATH, "/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[2]/div[2]/input[2]")
        # logButtonAddress.click()

        # lp.ClickLoginLink()
        # lp.TypeEmailEdit("test@email.com")
        # lp.TypePasswordEdit("abcabc")
        # lp.ClickLoginButton()
        self.lp.Login("selenium.testmay2017", "test@1234" )

        time.sleep(5)

        # Verify that we are in Login Page by the user icon text called as TEST
        # try:
        #     logoutLinkAddress = driver.find_element(By.XPATH, "//a[text()='Logout']")
        #     if logoutLinkAddress is not None:
        #         print("We are in login page")
        # except (NoSuchElementException):
        #     print("We are not in login page")
        self.lp.verifyLoginSuccessful()



# t1 = test_homeLogin()
# t1.test_validLogin()

# if __name__ == '__main__':
#     unittest.main(verbosity=2)


from selenium import webdriver
import time
import os

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from page.Inbox.SendMail import SendMailPage
import unittest
import pytest


@pytest.mark.usefixtures("OneTimeSetUp", "SetUp")
class test_SendMail(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetUp(self, OneTimeSetUp):
        self.lp = SendMailPage(self.driver)


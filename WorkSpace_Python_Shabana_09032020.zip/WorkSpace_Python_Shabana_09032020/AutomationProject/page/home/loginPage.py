from selenium.webdriver.common.by import By
import time
from base.selenium_driver import SeleniuWebdriver
import logging
import utilities.custom_logger as cl
from utilities.testStatus import TestStatus

class LoginPage(SeleniuWebdriver):
    logger = cl.customLogger(logging.DEBUG)

    # For using same driver instance as created in tes_login.py file of home package of test package, we need to create a constructor here
    def __init__(self, driver):
        # The same driver instance has to be used by the super class "SeleniuWebdriver" as used by child class "LoginPage"
        # So use the super method called the INIT methods present in super class and pass the same instance of the driver as used by the child class
        super().__init__(driver)
        self.driver = driver


    # Keep the location values separatley, so that if changing tomorrow, it is easier to maintain
    # _rediffmailLink = "Rediffmail"
    _emailEdit = "login1"
    _passwordEdit = "password"
    _logButton = "/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[2]/div[2]/input[2]"



    # For POM, We need to define address of the element and then the action on the element

    # For address, create methods and these methods return the addresses of the elements -  - Since four element create four methods
    # def getRediffmailLinkAddress(self):
    #     return self.driver.find_element(By.LINK_TEXT, self._rediffmailLink)
    #
    # def getEmailEditAddress(self):
    #     return self.driver.find_element(By.ID, self._emailEdit)
    #
    # def getPasswordEditAddress(self):
    #     return self.driver.find_element(By.ID, self._passwordEdit)
    #
    # def getLogButtonAddress(self):
    #     return self.driver.find_element(By.XPATH, self._logButton)

    # Now create action of the element and for that create methods  - Since four element create four methods
    # def ClickRediffmailLink(self):
    #     self.clickElement(self._rediffmailLink, "link")


    def TypeEmailEdit(self, email):
        self.clearEditboxElement(self._emailEdit)
        self.sendKeys(email, self._emailEdit)

    def TypePasswordEdit(self, password):
        self.clearEditboxElement(self._passwordEdit)
        self.sendKeys(password, self._passwordEdit)

    def ClickLoginButton(self):
        self.clickElement(self._logButton, "xpath")

    def Login(self, email, password):
        # Click on the Rediffemail Link
        # loginLinkAddress = self.driver.find_element(By.LINK_TEXT, self._rediffmailLink)
        # loginLinkAddress.click()
        #
        # # Type on the Email address
        # emailEditAddress = self.driver.find_element(By.ID, self._emailEdit)
        # emailEditAddress.send_keys(username)
        #
        # # Type on the password field
        # passwordEditAddress = self.driver.find_element(By.ID, self._passwordEdit)
        # passwordEditAddress.send_keys(password)
        #
        # # Click on the login button
        # logButtonAddress = self.driver.find_element(By.XPATH, self._logButton)
        # logButtonAddress.click()

        # Click on the Login Link
        # self.ClickRediffmailLink()


        # Type on the Email address
        self.TypeEmailEdit(email)

        # Type on the password field
        self.TypePasswordEdit(password)


        # Click on the login button
        self.ClickLoginButton()

    def verifyLoginSuccessful(self):
        #To check if the logout element is present .If present will throw TRUE
        result1 = self.isElementPresent("//a[text()='Logou']", "xpath")
        print(result1) # will give either true or false i.e. boolean value
        TestStatus.mark(result1, "Logout is not existing")
        # assert result1 == False
        result2 = self.isElementPresent("/html/body/div[4]/div[1]/div/div[2]/a[1]", "xpath")
        print(result2)  # will give either true or false i.e. boolean value
        TestStatus.markFinal("login Page Test case", result2, "Setting is not existing")
        # assert result2 == True
        print("Getting compiled")

    def verifyLoginFailed(self):
        result = self.isElementPresent("//*[@id='div_login_error']/b", "xpath")
        print(result)  # will give either true or false i.e. boolean value
        # assert result == True
        TestStatus.markFinal("login Page Test case", result, "Login error")
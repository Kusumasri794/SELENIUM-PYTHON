from base.selenium_driver import SeleniuWebdriver
import logging
import utilities.custom_logger as cl

class SendMailPage(SeleniuWebdriver):
    logger = cl.customLogger(logging.DEBUG)

    # For using same driver instance as created in tes_login.py file of home package of test package, we need to create a constructor here
    def __init__(self, driver):
        # The same driver instance has to be used by the super class "SeleniuWebdriver" as used by child class "LoginPage"
        # So use the super method called the INIT methods present in super class and pass the same instance of the driver as used by the child class
        super().__init__(driver)
        self.driver = driver

    # 1.Keep the addresses of the elements present in this page
    # 2. Actions that are performed for the elemnts in this page
    # 3. All validation methods

# User defined methods which will wrap in the existing method (text, getAttribute, find_element, send_keys) of Selenium Webdriver  - Wrapper methods
# All POM files should inherit the selenium_driver.py file - inherit the wrapper method


from selenium.webdriver.common.by import By
from traceback import print_stack
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
import logging
import utilities.custom_logger as cl


class SeleniuWebdriver():

    logger = cl.customLogger(logging.DEBUG)


    def __init__(self, driver):
        self.driver = driver

    def getByType(self, locatorType):
        locatorType = locatorType.lower()
        if locatorType == "id":
            return By.ID
        elif locatorType == "name":
            return By.NAME
        elif locatorType == "xpath":
            return By.XPATH
        elif locatorType == "css":
            return By.CSS_SELECTOR
        elif locatorType == "classname":
            return By.CLASS_NAME
        elif locatorType == "link":
            return By.LINK_TEXT
        else:
            self.logger.info("Locator type " + locatorType + " not correct/supported")
        return False

    def getElement(self, locator, locatorType="id"):
        element = None
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            element = self.driver.find_element(byType, locator)
            self.logger.info("Element Found with locator type: "+locatorType+ " and locator value as: "+locator)
        except:
            self.logger.info("Element not found with locator type: "+locatorType+ " and locator value as: "+locator)
        return element

    def isElementPresent(self, locator, locatorType="id"):
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            element = self.driver.find_element(byType, locator)
            if element is not None:
                self.logger.info("Element is present with locator type: "+locatorType+ " and locator value as: "+locator)
                return True
        except:
            self.logger.info("Element is not present with locator type: "+locatorType+ " and locator value as: "+locator)
            return False
        return False

    def clickElement(self,locator, locatorType="id"):
        element = self.getElement(locator, locatorType)
        element.click()

    def sendKeys(self,data, locator, locatorType="id"):
        element = self.getElement(locator, locatorType)
        element.send_keys(data)

    def clearEditboxElement(self,locator, locatorType="id"):
        element = self.getElement(locator, locatorType)
        element.clear()



    def waitForElement(self, locator, locatorType="id",
                       timeout=10, pollFrequency=0.5):
        element = None
        try:
            byType = self.getByType(locatorType)
            self.logger.info("Waiting for maximum :: " + str(timeout) +
                          " :: seconds for element to be clickable")
            wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=pollFrequency,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            element = wait.until(EC.element_to_be_clickable((byType, locator)))
            self.logger.info("Element appeared on the web page")
        except:
            self.logger.info("Element not appeared on the web page")
            # Origin of exception - traceback module, in-built module of selenium
            print_stack()
        return element